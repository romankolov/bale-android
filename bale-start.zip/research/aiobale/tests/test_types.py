from aiobale.types import (
    Message,
    Chat,
    MessageContent,
    TextMessage,
    DocumentMessage,
    QuotedMessage,
    Peer,
    IntValue,
)
from aiobale.types.responses import ContactResponse
from aiobale.types import InfoPeer
from aiobale.enums import ChatType, PeerType, TypingMode, GiftOpening, GiftOpenning


def test_message_quoted_reply_chat_attachment():
    chat = Chat(type=ChatType.GROUP, id=555)
    peer = Peer(type=PeerType.GROUP, id=555)
    quoted = QuotedMessage(
        message_id=IntValue(value=10),
        sender_id=20,
        date=1700000000000,
        content=MessageContent(text=TextMessage(value="original message")),
        peer=peer,
    )

    msg = Message(
        chat=chat,
        sender_id=30,
        date=1700000005000,
        message_id=11,
        content=MessageContent(text=TextMessage(value="reply")),
        quoted_replied_to=quoted,
    )

    assert msg.quoted_replied_to.chat is not None
    assert msg.quoted_replied_to.chat.id == 555
    assert msg.replied_to is not None
    assert msg.replied_to.message_id == 10
    assert msg.replied_to.chat.id == 555


def test_contact_response_fields():
    info_user = InfoPeer(id=1, access_hash=2, name="test_user")
    info_group = InfoPeer(id=10, access_hash=20, name="test_group")

    resp = ContactResponse(user=info_user, group=info_group)
    assert resp.user.name == "test_user"
    assert resp.group.name == "test_group"


def test_message_content_empty():
    content_empty = MessageContent.model_validate({"5": True})
    assert content_empty.empty is True

    content_text = MessageContent(text=TextMessage(value="test"))
    assert content_text.empty is False
    assert content_text.text.value == "test"


def test_enum_aliases():
    # TypingMode aliases
    assert TypingMode.VOICERECORDING == TypingMode.VOICERECODRING == 2
    assert TypingMode.CHOOSINGGIF == TypingMode.CHOSINGGIF == 9
    assert TypingMode.CHOOSINGEMOJI == TypingMode.CHOSINGEMOJI == 12

    # GiftOpening alias
    assert GiftOpening is GiftOpenning


def test_full_group_single_member_dict_normalization():
    from aiobale.types.responses import FullGroupResponse

    raw_payload = {
        "1": {
            "1": 987654,
            "3": "My Group",
            "10": 1,
            "17": {"1": 681691196, "2": 890123, "4": 1},
            "24": "👍",
        }
    }

    resp = FullGroupResponse.model_validate(raw_payload)
    assert resp.fullgroup is not None
    assert resp.fullgroup.title == "My Group"
    assert isinstance(resp.fullgroup.members, list)
    assert len(resp.fullgroup.members) == 1
    assert resp.fullgroup.members[0].id == 681691196
    assert resp.fullgroup.available_reactions == ["👍"]


def test_member_with_string_title_in_field_3():
    from aiobale.types.responses import FullGroupResponse

    raw_payload = {
        "1": {
            "1": 987654,
            "3": "My Group",
            "10": 5,
            "17": [
                {"1": 101, "2": 1, "3": 1700000000, "4": 1},
                {"1": 681691196, "2": 890, "3": "تبلیغات آزاد طلایی", "4": 0},
            ],
        }
    }

    resp = FullGroupResponse.model_validate(raw_payload)
    assert resp.fullgroup is not None
    assert len(resp.fullgroup.members) == 2
    
    admin_mem = resp.fullgroup.members[0]
    assert admin_mem.id == 101
    assert admin_mem.date == 1700000000
    assert admin_mem.is_admin is True

    special_mem = resp.fullgroup.members[1]
    assert special_mem.id == 681691196
    assert special_mem.date is None
    assert special_mem.title == "تبلیغات آزاد طلایی"
    assert special_mem.name == "تبلیغات آزاد طلایی"
    assert special_mem.is_admin is False


def test_document_message_with_dict_mime_type():
    from aiobale.types import DocumentMessage

    raw_doc = {
        "1": 123456,
        "2": 789012,
        "4": "test.pdf",
        "5": {"13": 7453017782211797357},
    }

    doc = DocumentMessage.model_validate(raw_doc)
    assert doc.file_id == 123456
    assert doc.name == "test.pdf"
    assert isinstance(doc.mime_type, dict)
    assert doc.mime_type == {"13": 7453017782211797357}


def test_message_data_tombstone_defaults():
    from aiobale.types.message_data import MessageData

    # Bale tombstone payload with missing date and content
    raw_msg_data = {
        "1": 2091967932,
        "2": -85382345123456,
        "16": {},
        "19": {},
    }

    msg_data = MessageData.model_validate(raw_msg_data)
    assert msg_data.sender_id == 2091967932
    assert msg_data.message_id == -85382345123456
    assert msg_data.date == 0
    assert msg_data.content is None


def test_document_message_sanitization_and_caption():
    from aiobale.types import DocumentMessage

    raw_doc = {
        "1": 123456,
        "2": 789012,
        "3": 1024,
        "4": "photo.jpg",
        "5": "image/jpeg",
        "8": {"1": "old caption"},
        "9": b"\x80\xff invalid utf-8",
        "10": "internal server metadata",
        "11": 99999,
    }

    doc = DocumentMessage.model_validate(raw_doc)
    assert doc.file_id == 123456
    assert doc.caption.content == "old caption"

    # Dump must not contain fields 9, 10, 11
    dumped = doc.model_dump(by_alias=True, exclude_none=True)
    assert "9" not in dumped
    assert "10" not in dumped
    assert "11" not in dumped

    # Test with_caption
    new_doc = doc.with_caption("Updated caption text")
    assert new_doc.caption.content == "Updated caption text"
    assert new_doc.file_id == 123456
    assert new_doc.access_hash == 789012
    new_dumped = new_doc.model_dump(by_alias=True, exclude_none=True)
    assert "9" not in new_dumped


def test_other_message_timestamp_only():
    from aiobale.types import OtherMessage

    raw = {"1": 1780652534717}
    msg = OtherMessage.model_validate(raw)
    assert msg.date == 1780652534717
    assert msg.message_id is None


def test_inline_keyboard_nested_dictionary():
    from aiobale.types import InlineKeyboardMarkup

    nested_dict = {
        "1": {
            "1": {
                "1": {
                    "1": {"1": "Bale Channel", "2": "https://ble.ir/channel"},
                    "2": {"1": "Click Here", "3": "btn_callback"},
                }
            }
        }
    }

    markup = InlineKeyboardMarkup.model_validate(nested_dict)
    assert len(markup.inline_keyboard) == 1
    assert len(markup.inline_keyboard[0]) == 2
    assert markup.inline_keyboard[0][0].text == "Bale Channel"
    assert markup.inline_keyboard[0][0].url == "https://ble.ir/channel"
    assert markup.inline_keyboard[0][1].text == "Click Here"
    assert markup.inline_keyboard[0][1].callback_data == "btn_callback"

