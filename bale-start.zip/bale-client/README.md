# baleclient - a from-scratch Python client for Bale

A complete, working custom client for the Bale messenger, written for the
[try2reverse](https://github.com/SketchboxOrg/try2reverse) challenge.

**Language rule.** The challenge accepts Java, C#, Kotlin and Python. This
entry is **Python only, end to end**: the protocol codec, the transports, the
client, the login flow, the build/codegen tools and *both* GUIs. The client
logic runs on Python in every mode - the optional browser front end merely
draws the widgets, and there is a second GUI (`python run.py native`) that is
pure Python with no browser, no HTTP server and no JavaScript at all. Nothing
in the deliverable is written in another language.

It contains the two things the challenge asks for:

1. **The protocol, fully extracted** - `53` services, `699` RPCs and
   `2012` protobuf message types recovered from the shipped web bundle, emitted
   as a `.proto` file that `protoc` accepts (`out/bale.proto`).
2. **A usable client** - login with a phone number and SMS code, chat list,
   history, sending messages, attachments, reactions, search, live updates,
   all in ~4400 lines of readable Python with a single third-party dependency
   (`websockets`).

```
$ python run.py login
Phone number (e.g. 989121234567): 98912xxxxxxx
code sent via type=2 expires=...
SMS code: 12345
logged in as سینا (id=1545969305)
jwt expires in 24h (2026-10-21 19:32)
handshake ok: {'mkprotoVersion': 1, 'apiVersion': 176652, 'serverTime': ...}

  connected as سینا (id=1545969305)
    1. [user ] Saved messages
    2. [group] My group                 (3 new)  hello

> /open 2
--- My group ---
[2026-10-20 20:11:03]           me: hello
> how are you?
sent
```

---

## The GUI

Two front ends, one backend, one language.

### 1. Native desktop GUI - pure Python, zero JavaScript

```bash
python run.py native          # tkinter window, resumes the saved session
python run.py native --demo   # fake chats for reviewers, no account needed
```

![native](docs/screenshots/native-light.png)
![native dark](docs/screenshots/native-dark.png)

Tk draws the entire interface: chat list with avatars, unread badges and live
previews, message bubbles with day separators, grouped messages and sender
names, photos, file cards, quoted replies, reactions, typing status, dark mode.
Persian text is shaped and re-ordered by `baleclient/rtl.py` (contextual
Arabic presentation forms + a bidi pass), because Tk has no bidi engine - so
`سلام` renders as `سلام` and not reversed. Everything is stdlib: `tkinter`,
`unicodedata`, `base64`, `threading`. Pillow is optional and only used to scale
photos.

### 2. Browser GUI - same client, HTML view

```bash
python3 run.py gui            # opens http://127.0.0.1:8765 in your browser
python3 run.py gui --demo     # no account needed - fake chats for demos
python3 run.py gui --port 9000 --bind 0.0.0.0   # custom port / LAN access
```

![light](docs/screenshots/light.png)
![dark](docs/screenshots/dark.png)

| | |
|---|---|
| ![groups](docs/screenshots/members.png) | ![search](docs/screenshots/search.png) |

A real messenger UI, not a shell:

* **login screen** with the full state machine - phone → SMS code →
  (2FA password) → (sign-up), plus "resend / change number"
* **chat list** with avatars, unread badges, last message, relative time,
  search, RTL layout and Persian/English toggle
* **message view** with day separators, grouped bubbles, sender avatars and
  names in groups, quoted messages, timestamps, delivery ticks
* **live updates** - incoming messages appear in the open chat or bump the
  chat list; the connection dot shows the WebSocket state
* **sending** with Enter / Shift+Enter, optimistic rendering, auto-scroll and
  the chat jumping to the top of the list
* **attachments** - pick any file, it is uploaded through
  `Files/GetNasimFileUploadUrl` (single or chunked PUT, exactly like the web
  client) and sent as a `DocumentMessage`; photos render as pictures with a
  lightbox, voice/audio as a player, everything else as a file card with a
  download link
* **media downloads** - images, video, audio and documents come from
  `Files/GetNasimFileUrl`, cached in memory; **avatars** are real images pulled
  from `Users.avatar`/`Groups2.avatar`
* **message actions** - right-click any bubble: reply (with the quoted
  message), copy, forward (to any chat), edit, delete; a reaction bar
  (`👍 ❤️ 😂 😮 😢 🔥`) sends `Abacus/MessageSetReaction` and live
  `ReactionsUpdate` events update the counters
* **typing indicator** - `Presence/Typing` on keypress, incoming
  `Update.typing` renders animated dots in the header
* **group members** - `Groups/LoadMembers` with admin badges, avatars and names
* **profile panel** - click a chat title: avatar, name, `@nick`/about, member
  count and numeric id
* **search** - Enter in the search box runs `Search/SearchMessages` across all
  chats (or the open chat) and lists hits with sender, time and snippet;
  without Enter the box filters the chat list locally
* **dark mode** (remembered in `localStorage`), responsive layout
  (phone-sized windows collapse to one pane), and a **demo mode** that ships
  fake chats, a real photo, a playable voice note, a file, reactions and a live
  incoming-message loop so the UI can be shown without an account
* resumes a saved session automatically - `py run.py gui`, no SMS again

Architecture: a stdlib `ThreadingHTTPServer` exposes the client over a small
JSON API (`/api/status`, `/api/dialogs`, `/api/history`, `/api/send`, `/api/send_media`,
`/api/media`, `/api/avatar`, `/api/delete`, `/api/edit`, `/api/forward`,
`/api/react`, `/api/typing`, `/api/members`, `/api/profile`, `/api/search`,
`/api/read`, `/api/login/*`) and long-polls `/api/poll` for live events. The
asyncio Bale client runs in its own thread and pushes updates into an event
queue, so the browser never talks to Bale directly and the token never leaves
the machine. `baleclient/webui.py` + `baleclient/static/index.html`, no extra
dependencies.

## Quick start

```bash
python3 -m pip install -r requirements.txt     # websockets only
python3 run.py native                          # desktop GUI (pure Python)
python3 run.py gui                             # browser GUI
python3 run.py login                           # terminal login, then chat
python3 run.py chats
python3 run.py history g:98765432
python3 run.py send u:12345678 "salam"
python3 run.py listen                          # live messages
python3 run.py repl                            # reopen the chat UI
```

Sessions are stored in `~/.bale-client/session.json` (mode 600). Delete the
file to log out.

If your network needs a proxy (Bale's edge sometimes refuses non-Iranian
addresses), export `BALE_PROXY=http://host:port` before running. If the TLS
handshake to `next-ws.bale.ai` hangs, that is almost always the cause.

---

## What is in the box

```
bale-client/
├── run.py                     entry point (same as python -m baleclient)
├── requirements.txt           websockets>=12
├── README.md                  this file
├── HANDBOOK.md                beginner guide: protocol from zero + how to build
│                              your own client in Python/Java/Kotlin/C#
├── PROTOCOL.md                the reverse-engineering write-up  <-- read this
├── baleclient/
│   ├── proto.py               schema driven protobuf codec (no deps)
│   ├── schema.json            2006 message definitions recovered from the bundle
│   ├── transport.py           gRPC-web POST + protobuf WebSocket + handshake/ping
│   ├── client.py              login, dialogs, history, send, updates
│   ├── webui.py               GUI backend + shared app logic (http bridge)
│   ├── tkgui.py               native desktop GUI (tkinter, pure Python)
│   ├── rtl.py                 Arabic/Persian shaper + bidi for the Tk GUI
│   ├── static/index.html      browser GUI front end (vanilla JS, no build)
│   └── cli.py                 login / chats / history / send / listen / repl
├── tools/
│   ├── extract_protos.py      bundle  ->  schema.json + *.proto
│   └── build_schema.py        schema.json  ->  baleclient/schema.json
├── proto/                     generated per-package .proto files
├── out/
│   ├── bale.proto             single, protoc-valid definition of everything
│   └── schema.json            raw extraction result (with module locations)
├── docs/services.md           the 53 services and their RPC counts
├── docs/examples/
│   ├── minimal_client.py      a full client in stdlib Python (~500 lines)
│   └── test_minimal_client.py local fake Bale server, protocol assertions
├── docs/screenshots/          UI screenshots
└── tests/                     32 offline tests (no account needed)
```

Run the tests:

```bash
python3 -m unittest discover -s tests -v
```

New here? Read **[HANDBOOK.md](HANDBOOK.md)** - it explains protobuf, WebSockets
and the Bale envelope from scratch, then walks through writing a client in
Python, Java, Kotlin or C#. For the shortest path to understanding, read
`docs/examples/minimal_client.py`; it is the entire protocol in one file with no
dependencies beyond the standard library.

---

## How the protocol was recovered

The challenge archive contains the production web client. Its JavaScript is
`protoc`-generated protobuf code, compacted but intact. That generated code
contains, for every message, a literal protobuf key per field:

```js
0 !== r.appId && o.uint32(16).int32(r.appId)   // (field 2 << 3) | varint
```

and, on the decode path, the exact field name:

```js
case 2: if (16 !== r) break; c.appId = a.int32();
```

`tools/extract_protos.py` parses all 70 modules that contain this generated
code (plus the lazy chunks), follows the rspack export tables to resolve
cross-module message references, unwraps `google.protobuf.*` wrappers, and
writes a schema. No guessing, no traffic capture, no server access.

Details - endpoints, framing, handshake, login state machine, metadata,
lifecycle - are in **[PROTOCOL.md](PROTOCOL.md)**.

---

## How the client is built

* **`proto.py`** is a ~300-line protobuf encoder/decoder driven by
  `schema.json`. It supports all wire types, packed repeated fields, unknown
  fields and `Value` wrappers, so no `protoc` run is needed at install time
  (but `out/bale.proto` is provided for people who prefer generated code).
* **`transport.py`** implements both channels the official client uses:
  gRPC-web `POST /{service}/{method}` for login, and a protobuf framed
  WebSocket for everything else, with the same `HandshakeRequest`, 10 s ping
  and `request_id` correlation.
* **`client.py`** is the friendly layer: `start_phone_auth`, `validate_code`,
  `validate_password`, `sign_up`, `connect`, `load_dialogs`, `load_history`,
  `send_text`, `message_read`, `listen`.

The high-level API now covers login (SMS, 2FA, sign-up), dialogs, history,
sending, read receipts, edit/delete/forward, typing and presence, groups and
members, reactions, search, and photo/file upload and download. The schema
contains all 699 RPCs, so anything not yet wrapped - stickers, stories, calls -
is a matter of calling `bale.rpc(service, method, request, request_type,
response_type)`.

---

## Bugs found by running it against the live server

Both were invisible in the bundle until a real account was used, and both are
now covered by byte-level regression tests:

| symptom | cause |
|---|---|
| `LoadDialogs` returns 0 bytes | `minDate` must be `-1` for the first page; `0` is a 1970 date cursor |
| `LoadHistory` returns 0 messages | same `-1` cursor, plus `loadMode` must be `BACKWARD (2)` / `BOTH (3)` |
| chat list shows `1545969305` instead of a name | dialogs carry ids only; names come from `Users/LoadUsers` + `Groups/LoadGroups` |

## Status and limitations

* Login, dialog list, history, send and update streaming are implemented and
  unit tested offline. The auth request bytes were cross-checked byte for byte
  against the values in the bundle (`appId=4`, `apiKey=…`, `mkprotoVersion=1`,
  `apiVersion=176652`), but **they could not be exercised end to end here**:
  Bale's edge drops TLS from non-Iranian networks, so a real phone number was
  not usable in this environment. If a call fails, run with `--debug` - server
  errors are printed verbatim.
* Media upload/download URLs are returned by the API; only text sending is
  wired into the CLI.
* Message *type names* are reconstructed (numbers/names/types are exact), see
  the note at the end of PROTOCOL.md.

---

## About the challenge

This repository was produced for `try2reverse` (submission address:
`try2reverse@bale.ir`, accepted languages Python/Java/C#/Kotlin).

**A word of caution before you submit:** the challenge repository appeared on
2026-10-20 and only exists to host an `.rar`; the contact is a free Gmail
address and the 100 000 prize is not backed by anything verifiable in the repo.
Reverse engineering your own client is fine and legal in most jurisdictions,
but do not send money, do not hand over your Bale credentials, and treat the
prize as unconfirmed until the organiser proves otherwise.

Bale is a trademark of its owner. This project is unofficial and not
affiliated with or endorsed by Bale.
