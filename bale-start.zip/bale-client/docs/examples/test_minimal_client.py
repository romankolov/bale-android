#!/usr/bin/env python3
"""
test_minimal_client.py - run minimal_client.py against a local fake Bale.

The fake server speaks the real protocol (handshake, ping, request/response,
update pushes) on 127.0.0.1, so the example client is exercised end to end
without an account, a phone number or an internet connection.

    python docs/examples/test_minimal_client.py
"""
from __future__ import annotations

import os
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from minimal_client import (MiniBale, build_ping, parse_frame, Reader,  # noqa: E402
                           field_text, put_bytes, put_int)

import asyncio  # noqa: E402

try:
    import websockets  # noqa: E402
except ImportError:  # pragma: no cover
    print("this test needs the 'websockets' package: pip install websockets")
    sys.exit(2)

PORT = 8799
received = {"handshake": None, "calls": [], "pings": 0}


async def handler(connection):
    """Answer exactly like Bale does: handshake first, then per-index responses."""
    try:
        await _handler(connection)
    except Exception:
        import traceback
        traceback.print_exc()


async def _handler(connection):
    async for raw in connection:
        frame = raw
        # peek at which of the three request kinds this is
        for number, wire, value in Reader(frame).fields():
            if number == 3 and wire == 2:                        # handshake
                received["handshake"] = True
                answer = (put_bytes(5, put_int(1, 1) + put_int(2, 176652)
                                    + put_int(3, 1750000000000)))
                await connection.send(answer)
            elif number == 2 and wire == 2:                       # ping -> pong
                received["pings"] += 1
                await connection.send(put_bytes(4, put_int(1, 7)))
            elif number == 1 and wire == 2:                       # request
                service = field_text(value, 1)
                method = field_text(value, 2)
                payload = b""
                index = 0
                for n2, w2, v2 in Reader(value).fields():
                    if n2 == 3 and w2 == 2:
                        payload = v2
                    elif n2 == 5 and w2 == 0:
                        index = v2
                received["calls"].append((service, method, payload))
                if method == "LoadDialogs":
                    # LoadDialogs_Response: field 3 = repeated Dialogs,
                    # Dialogs { 1: Peer{1:type,2:id}, 2: unreadCount }
                    dialog1 = (put_bytes(1, put_int(1, 1) + put_int(2, 111))
                               + put_int(2, 3))
                    dialog2 = (put_bytes(1, put_int(1, 1) + put_int(2, 222))
                               + put_int(2, 0))
                    # outer Response { 2: bytes result, 3: int64 index }
                    result = put_bytes(3, dialog1) + put_bytes(3, dialog2)
                    answer = put_bytes(1, put_bytes(2, result) + put_int(3, index))
                elif method == "SendMessage":
                    # push a live update first, then the answer: proves the client
                    # keeps waiting for the response with the right index
                    await connection.send(put_bytes(2, put_bytes(1, b"\x08\x01")))
                    answer = put_bytes(1, put_bytes(2, b"") + put_int(3, index))
                else:
                    answer = put_bytes(1, put_bytes(2, b"") + put_int(3, index))
                await connection.send(answer)


def serve():
    async def main():
        async with websockets.serve(handler, "127.0.0.1", PORT):
            await asyncio.Future()
    loop = asyncio.new_event_loop()
    threading.Thread(target=lambda: loop.run_until_complete(main()), daemon=True).start()
    time.sleep(0.7)


def main() -> int:
    serve()
    client = MiniBale(host="127.0.0.1", tls=False, port=PORT)

    print("1) connect + handshake")
    handshake = client.connect("fake.jwt.token")
    assert handshake["apiVersion"] == 176652, handshake
    print("   ->", handshake)

    print("2) LoadDialogs")
    dialogs = client.load_dialogs()
    peers = []
    for number, wire, value in Reader(dialogs).fields():
        if number == 3 and wire == 2:            # repeated Dialogs
            peer_id = 0
            for n2, w2, v2 in Reader(value).fields():
                if n2 == 1 and w2 == 2:          # Peer {1: type, 2: id}
                    for n3, w3, v3 in Reader(v2).fields():
                        if n3 == 2 and w3 == 0:
                            peer_id = v3
            peers.append(peer_id)
    print("   -> dialogs for peers:", peers)
    assert peers == [111, 222], peers

    print("3) SendMessage")
    result = client.send_text(1, 111, "salam from the minimal client")
    assert result == b""
    print("   -> sent, server answered")

    print("4) server saw:", [c[1] for c in received["calls"]])
    assert [c[1] for c in received["calls"]] == ["LoadDialogs", "SendMessage"]

    print("5) ping frame")
    client.ws.send(build_ping(5))
    frame = parse_frame(client.ws.recv())
    assert frame.get("pong") == 7, frame
    print("   -> pong", frame["pong"])

    client.ws.close()
    print("\nall protocol checks passed against a local server")
    return 0


if __name__ == "__main__":
    sys.exit(main())
