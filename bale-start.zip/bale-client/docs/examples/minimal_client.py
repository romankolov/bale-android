#!/usr/bin/env python3
"""
minimal_client.py - the smallest complete Bale client, written from scratch.

This file exists to be read.  It implements the whole protocol stack in ~350
lines using **nothing but the Python standard library** (no `websockets`, no
`protobuf`, no `grpcio`), so you can see every byte that goes on the wire and
copy the same structure into Java, C#, Kotlin or any other language.

Four layers, bottom to top:

    1. protobuf primitives ....... varint, tags, length-delimited fields
    2. the envelope .............. WsRequest / WsResponse
    3. a raw WebSocket ........... TLS socket + RFC 6455 framing + masking
    4. the client ................ handshake, ping, call(service, method, ...)

Run it against a real account:

    python minimal_client.py 989121234567      # asks for the SMS code

Run it against the bundled mock server (no account, no network):

    python minimal_client.py --selftest
"""
from __future__ import annotations

import base64
import os
import socket
import ssl
import struct
import sys
import time

# --------------------------------------------------------------------------- config
HOST = "next-ws.bale.ai"
ORIGIN = "https://web.bale.ai"
APP_VERSION = 176652          # web@5.8.0+176652, sent in the handshake
PROTO_VERSION = 1             # "mkprotoVersion"
APP_ID = 4
API_KEY = "C28D46DC4C3A7A26564BFCC48B929086A95C93C98E789A19847BEE8627DE4E7D"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/135.0.0.0 Safari/537.36"

# every request carries these; the official client also sends an "mt_" copy of each
META = {"app_version": str(APP_VERSION), "browser_type": "1",
        "browser_version": "138.0.0.0", "os_type": "3"}


# =========================================================================== 1. protobuf
# A protobuf message is a sequence of fields.  Each field is:
#     tag = (field_number << 3) | wire_type        (written as a varint)
#     wire_type 0 = varint, 1 = 64-bit, 2 = length-delimited (string/bytes/message)
#
# That is the entire format.  Everything below is 40 lines of that.

def varint(value: int) -> bytes:
    """Encode an unsigned 64-bit integer, 7 bits per byte, high bit = 'more'."""
    value &= (1 << 64) - 1          # negative numbers are 10-byte two's complement
    out = bytearray()
    while True:
        chunk = value & 0x7F
        value >>= 7
        if value:
            out.append(chunk | 0x80)
        else:
            out.append(chunk)
            return bytes(out)


def tag(field: int, wire: int) -> bytes:
    return varint((field << 3) | wire)


def put_int(field: int, value: int) -> bytes:
    """A varint field (int32 / int64 / bool / enum)."""
    return tag(field, 0) + varint(int(value))


def put_bytes(field: int, data: bytes) -> bytes:
    """A length-delimited field (string / bytes / nested message)."""
    return tag(field, 2) + varint(len(data)) + bytes(data)


def put_str(field: int, text: str) -> bytes:
    return put_bytes(field, text.encode("utf-8"))


class Reader:
    """Walk a serialized protobuf message and yield (number, wire, value)."""

    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def varint(self) -> int:
        result = shift = 0
        while True:
            byte = self.data[self.pos]
            self.pos += 1
            result |= (byte & 0x7F) << shift
            if not byte & 0x80:
                return result
            shift += 7

    def take(self, count: int) -> bytes:
        chunk = self.data[self.pos:self.pos + count]
        self.pos += count
        return chunk

    def fields(self):
        while self.pos < len(self.data):
            key = self.varint()
            number, wire = key >> 3, key & 7
            if wire == 0:
                yield number, wire, self.varint()
            elif wire == 2:
                yield number, wire, self.take(self.varint())
            elif wire == 1:
                yield number, wire, self.take(8)
            elif wire == 5:
                yield number, wire, self.take(4)
            else:                      # groups / garbage -> stop, we never use them
                return


def field_text(message: bytes, number: int) -> str:
    """Read field <number> of a message as UTF-8 text (first occurrence)."""
    for num, wire, value in Reader(message).fields():
        if num == number and wire == 2:
            return value.decode("utf-8", "replace")
    return ""


def field_bytes(message: bytes, number: int) -> bytes:
    for num, wire, value in Reader(message).fields():
        if num == number and wire == 2:
            return value
    return b""


def field_int(message: bytes, number: int) -> int:
    for num, wire, value in Reader(message).fields():
        if num == number and wire == 0:
            return value
    return 0


# =========================================================================== 2. envelope
# The WebSocket carries one WsRequest per frame:
#
#   WsRequest            { 1: Request request, 2: Ping ping, 3: Handshake handshake }
#   Request              { 1: string service, 2: string method, 3: bytes payload,
#                          4: Metadata metadata, 5: int64 index }
#   Ping                 { 1: int64 id }
#   HandshakeRequest     { 1: int32 mkprotoVersion, 2: int64 apiVersion }
#
# and answers with a WsResponse:
#
#   WsResponse           { 1: Response response, 2: Update update,
#                          3: TerminateSession, 4: Pong pong, 5: HandshakeResponse }
#   Response             { 1: Error error, 2: bytes response, 3: int64 index }
#   Error                { 1: int32 topic, 2: string message }

def _metadata_blob(meta: dict) -> bytes:
    """Metadata { 1: repeated Entry { 1: string key, 2: { 1: string value } } }."""
    out = b""
    for key, value in meta.items():
        entry = put_str(1, key) + put_bytes(2, put_str(1, value))
        out += put_bytes(1, entry)
    return out


def build_request(service: str, method: str, payload: bytes, index: int,
                  meta: dict = None) -> bytes:
    request = (put_str(1, service)
               + put_str(2, method)
               + put_bytes(3, payload)
               + put_bytes(4, _metadata_blob(meta or META))
               + put_int(5, index))
    return put_bytes(1, request)


def build_ping(ping_id: int) -> bytes:
    return put_bytes(2, put_int(1, ping_id))


def build_handshake() -> bytes:
    return put_bytes(3, put_int(1, PROTO_VERSION) + put_int(2, APP_VERSION))


def parse_frame(data: bytes) -> dict:
    """Turn a WsResponse into {kind: ...} for the caller."""
    out = {}
    for number, wire, value in Reader(data).fields():
        if number == 1 and wire == 2:                       # Response
            body = {"error": None, "result": b"", "index": 0}
            for n2, w2, v2 in Reader(value).fields():
                if n2 == 1 and w2 == 2:                     # Error
                    body["error"] = {"topic": field_int(v2, 1),
                                     "message": field_text(v2, 2)}
                elif n2 == 2 and w2 == 2:
                    body["result"] = v2
                elif n2 == 3 and w2 == 0:
                    body["index"] = v2
            out["response"] = body
        elif number == 2 and wire == 2:                     # Update
            out["update"] = field_bytes(value, 1)
        elif number == 3:
            out["terminate"] = True
        elif number == 4 and wire == 2:                     # Pong
            out["pong"] = field_int(value, 1)
        elif number == 5 and wire == 2:                     # HandshakeResponse
            out["handshake"] = {"mkprotoVersion": field_int(value, 1),
                                "apiVersion": field_int(value, 2),
                                "serverTime": field_int(value, 3)}
    return out


# =========================================================================== 3. websocket
# RFC 6455 is simple enough to implement directly:
#   * HTTP GET with Upgrade: websocket and a random Sec-WebSocket-Key
#   * frames: [FIN|opcode][mask+len][extended len][4-byte mask][payload ^ mask]
#   * clients MUST mask, servers MUST NOT

class RawWebSocket:
    def __init__(self, host: str, path: str = "/ws/", headers: dict = None,
                 timeout: float = 30.0, tls: bool = True, port: int = 443):
        self.sock = socket.create_connection((host, port), timeout=timeout)
        if tls:   # a plain socket on localhost is handy when testing
            self.sock = ssl.create_default_context().wrap_socket(
                self.sock, server_hostname=host)
        key = base64.b64encode(os.urandom(16)).decode()
        lines = [f"GET {path} HTTP/1.1",
                 f"Host: {host}",
                 "Upgrade: websocket",
                 "Connection: Upgrade",
                 f"Sec-WebSocket-Key: {key}",
                 "Sec-WebSocket-Version: 13",
                 f"Origin: {ORIGIN}",
                 f"User-Agent: {USER_AGENT}"]
        for name, value in (headers or {}).items():
            lines.append(f"{name}: {value}")
        self.sock.sendall(("\r\n".join(lines) + "\r\n\r\n").encode())

        # read the HTTP response headers byte by byte
        head = b""
        while b"\r\n\r\n" not in head:
            chunk = self.sock.recv(1)
            if not chunk:
                raise ConnectionError("server closed during the handshake")
            head += chunk
        status_line = head.split(b"\r\n", 1)[0].decode()
        if "101" not in status_line:
            raise ConnectionError(f"websocket refused: {status_line}")

    # -- sending ----------------------------------------------------------
    def send(self, payload: bytes) -> None:
        header = bytearray([0x82])                 # FIN + binary opcode
        length = len(payload)
        if length < 126:
            header.append(0x80 | length)
        elif length < 65536:
            header.append(0x80 | 126)
            header += struct.pack(">H", length)
        else:
            header.append(0x80 | 127)
            header += struct.pack(">Q", length)
        mask = os.urandom(4)
        header += mask
        masked = bytes(byte ^ mask[i % 4] for i, byte in enumerate(payload))
        self.sock.sendall(bytes(header) + masked)

    # -- receiving --------------------------------------------------------
    def _read_exactly(self, count: int) -> bytes:
        buf = b""
        while len(buf) < count:
            chunk = self.sock.recv(count - len(buf))
            if not chunk:
                raise ConnectionError("websocket closed")
            buf += chunk
        return buf

    def recv(self) -> bytes:
        """Return the next binary message (skips ping/pong/close control frames)."""
        while True:
            first, second = self._read_exactly(2)
            opcode = first & 0x0F
            masked = second & 0x80
            length = second & 0x7F
            if length == 126:
                length = struct.unpack(">H", self._read_exactly(2))[0]
            elif length == 127:
                length = struct.unpack(">Q", self._read_exactly(8))[0]
            mask = self._read_exactly(4) if masked else b""
            data = self._read_exactly(length)
            if masked:
                data = bytes(byte ^ mask[i % 4] for i, byte in enumerate(data))
            if opcode == 0x8:                      # close
                raise ConnectionError("websocket closed by the server")
            if opcode in (0x9, 0xA):               # ping / pong -> ignore
                continue
            return data

    def close(self) -> None:
        try:
            self.sock.sendall(bytes([0x88, 0x80]) + os.urandom(4))
        except OSError:
            pass
        self.sock.close()


# =========================================================================== 4. client
class MiniBale:
    def __init__(self, host: str = HOST, tls: bool = True, port: int = 443):
        self.host = host
        self.tls = tls
        self.port = port
        self.ws: RawWebSocket = None
        self.index = 0
        self.token = None
        self.pending = {}          # index -> (error, result)

    # -- plumbing ---------------------------------------------------------
    def _next_index(self) -> int:
        self.index += 1
        return self.index

    def connect(self, token: str) -> dict:
        self.token = token
        self.ws = RawWebSocket(self.host, headers={"Cookie": f"access_token={token}"},
                               tls=self.tls, port=self.port)
        self.ws.send(build_handshake())
        frame = parse_frame(self.ws.recv())
        if "handshake" not in frame:
            raise RuntimeError(f"no handshake answer: {frame}")
        return frame["handshake"]

    def call(self, service: str, method: str, payload: bytes = b"",
             timeout: float = 20.0) -> bytes:
        """Send one RPC and wait for its answer (matched by index)."""
        index = self._next_index()
        self.ws.send(build_request(service, method, payload, index))
        deadline = time.time() + timeout
        self.ws.sock.settimeout(max(0.1, timeout))
        while time.time() < deadline:
            frame = parse_frame(self.ws.recv())
            if "update" in frame:
                print("  [live update]", frame["update"].hex()[:60])
                continue
            response = frame.get("response")
            if response is None or response["index"] != index:
                continue
            if response["error"]:
                raise RuntimeError(f"[{response['error']['topic']}] "
                                   f"{response['error']['message']}")
            return response["result"]
        raise TimeoutError(method)

    # -- auth (plain HTTPS, not the websocket) ---------------------------
    def _grpc_post(self, service: str, method: str, payload: bytes) -> bytes:
        """gRPC-web unary call: 1 flag byte + 4-byte big-endian length + message."""
        import http.client
        body = b"\x00" + struct.pack(">I", len(payload)) + payload
        headers = {"content-type": "application/grpc-web+proto",
                   "origin": ORIGIN, "user-agent": USER_AGENT}
        headers.update(META)
        conn = http.client.HTTPSConnection(self.host, timeout=30)
        conn.request("POST", f"/{service}/{method}", body=body, headers=headers)
        resp = conn.getresponse()
        raw = resp.read()
        message = resp.getheader("grpc-message")
        if message:
            raise RuntimeError(f"grpc error: {message}")
        if resp.status != 200:
            raise RuntimeError(f"HTTP {resp.status}")
        return raw[5:]             # strip the frame header

    def start_auth(self, phone: str) -> dict:
        request = (put_int(1, int(phone))
                   + put_int(2, APP_ID)
                   + put_str(3, API_KEY)
                   + put_bytes(4, os.urandom(16))          # device hash
                   + put_str(5, "Chrome_135.0.0.0, Windows")
                   + put_int(7, 1))                        # sendCodeType = SMS
        answer = self._grpc_post("bale.auth.v1.Auth", "StartPhoneAuth", request)
        return {"transactionHash": field_text(answer, 1),
                "activationType": field_int(answer, 2),
                "sentCodeType": field_int(answer, 3)}

    def validate_code(self, transaction_hash: str, code: str) -> str:
        request = (put_str(2, code)
                   + put_str(3, transaction_hash)
                   + put_bytes(4, put_int(1, 1)))          # isJwt = true
        answer = self._grpc_post("bale.auth.v1.Auth", "ValidateCode", request)
        return field_text(answer, 1)                       # the JWT

    # -- a couple of real calls ------------------------------------------
    def load_dialogs(self, limit: int = 50) -> bytes:
        payload = (put_int(1, -1)                          # minDate = -1  (important!)
                   + put_int(2, 0)                         # dialogType = all
                   + put_int(3, limit)
                   + put_int(6, 0))                        # archiveFilter = all
        return self.call("bale.messaging.v2.Messaging", "LoadDialogs", payload)

    def send_text(self, peer_type: int, peer_id: int, text: str,
                  access_hash: int = 0) -> bytes:
        peer = put_int(1, peer_type) + put_int(2, peer_id)
        if access_hash:
            peer += put_int(3, access_hash)
        payload = (put_bytes(1, peer)
                   + put_int(2, int.from_bytes(os.urandom(7), "big"))   # rid
                   + put_bytes(3, put_bytes(1, put_str(1, text))))      # TextMessage
        return self.call("bale.messaging.v2.Messaging", "SendMessage", payload)


# =========================================================================== 5. selftest
def selftest() -> None:
    """Prove the encoder/decoder against known byte sequences (no network)."""
    checks = []

    # varint edge cases (0, 127, 128, -1)
    checks.append(("varint 0", varint(0), b"\x00"))
    checks.append(("varint 127", varint(127), b"\x7f"))
    checks.append(("varint 128", varint(128), b"\x80\x01"))
    checks.append(("varint -1", varint(-1), b"\xff" * 9 + b"\x01"))

    # field encoding:  field 1, wire 2, "hi"  -> 0a 02 68 69
    checks.append(("put_str(1,'hi')", put_str(1, "hi"), b"\x0a\x02hi"))
    # field 3 varint 300 -> 18 ac 02
    checks.append(("put_int(3,300)", put_int(3, 300), b"\x18\xac\x02"))

    # a handshake frame must match what the real client sends
    checks.append(("handshake frame", build_handshake(), b"\x1a\x06\x08\x01\x10\x8c\xe4\x0a"))

    # round-trip a fake response {1:{2:"ok",3:7}}
    inner = put_str(2, "ok") + put_int(3, 7)
    frame = parse_frame(put_bytes(1, inner))
    checks.append(("parse index", frame["response"]["index"], 7))
    checks.append(("parse result", frame["response"]["result"], b"ok"))

    # errors: {1:{1:3, 2:"nope"}}
    error = put_int(1, 3) + put_str(2, "nope")
    checks.append(("parse error", parse_frame(put_bytes(1, put_bytes(1, error)))
                   ["response"]["error"], {"topic": 3, "message": "nope"}))

    failed = 0
    for name, got, want in checks:
        ok = got == want
        failed += 0 if ok else 1
        print(f"  {'ok  ' if ok else 'FAIL'} {name}: {got!r}")
    print(f"\n{len(checks) - failed}/{len(checks)} checks passed")
    if failed:
        sys.exit(1)


def live(phone: str) -> None:
    client = MiniBale()
    auth = client.start_auth(phone)
    print("transaction:", auth["transactionHash"][:16], "...")
    code = input("SMS code: ").strip()
    token = client.validate_code(auth["transactionHash"], code)
    print("token:", token[:24], "...")
    handshake = client.connect(token)
    print("handshake:", handshake)

    dialogs = client.load_dialogs()
    print(f"\nLoadDialogs -> {len(dialogs)} bytes")
    # LoadDialogs_Response { 1: groups, 2: users, 3: repeated Dialogs, 4: userPeers,
    #                        5: groupPeers }   and Dialogs { 1: Peer, 2: unreadCount }
    for number, wire, value in Reader(dialogs).fields():
        if number == 3 and wire == 2:
            peer = field_bytes(value, 1)                  # Peer {1: type, 2: id}
            peer_type = field_int(peer, 1)
            peer_id = field_int(peer, 2)
            unread = field_int(value, 2)
            print(f"  dialog {peer_type}:{peer_id} unread={unread}")

    # keep the socket alive briefly so live updates print
    print("\nlistening for 30 s (ctrl-c to stop)...")
    try:
        end = time.time() + 30
        while time.time() < end:
            frame = parse_frame(client.ws.recv())
            if "update" in frame:
                print("  [update]", frame["update"].hex()[:80])
    except KeyboardInterrupt:
        pass
    client.ws.close()


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        selftest()
    elif len(sys.argv) > 1:
        live(sys.argv[1])
    else:
        print(__doc__)
