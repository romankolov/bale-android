# Submission checklist

The challenge asks for **source code + a build** by mail to
`try2reverse@bale.ir`, in Python / Java / C# / Kotlin, with every protobuf,
protocol, lifecycle and URL extracted, and a client "as usable as a real one".

## Language

The rules allow Java, C#, Kotlin and Python. **The whole entry is Python** -
extractor, codec, transports, client, CLI, both GUIs and the tests. The browser
GUI is drawn by HTML/JS in the browser, but the client itself (protocol,
auth, state, everything that touches Bale) is Python in every mode, and the
native GUI (`run.py native`) contains no JavaScript at all. If a reviewer wants
a single-language artefact, submit `run.py native` as the client.

## What to send

1. `bale-client/` as a zip (this whole folder). No build step at all:
   `pip install -r requirements.txt`, then either

   ```bash
   python run.py native     # desktop GUI, pure Python (tkinter), no browser
   python run.py gui        # browser GUI on http://127.0.0.1:8765
   ```

   Both front ends drive the same Python client; `native` uses no JavaScript.
2. A short cover note (template below).
   Documentation to point at: `PROTOCOL.md` (how the protocol was recovered),
   `HANDBOOK.md` (a from-zero guide, including how to write the same client in
   Java, Kotlin or C#), and `docs/examples/minimal_client.py` (the whole
   protocol in one dependency-free file). Together they show the work is
   reproducible by someone else, which is what "reverse engineered" should mean.
3. Optionally a screen recording of `python run.py login` → `chats` →
   `send` → `listen` on your own account. Judges can see in 30 seconds that
   the thing is real - do this, it is the strongest evidence you can attach.

Do **not** send `bale.rar`, your session file (`~/.bale-client/session.json`),
your phone number or your SMS codes.

## Run it once yourself first

```bash
python3 -m pip install -r requirements.txt
python3 run.py gui            # the thing the judges will look at
python3 run.py login          # your own number
python3 run.py chats
python3 run.py send u:<your other account> "hello"
python3 run.py listen
```

If TLS to `next-ws.bale.ai` hangs, Bale is refusing your network - use an
Iranian proxy/VPN and set `BALE_PROXY=http://host:port`.

If a call fails, run with `--debug` and paste the server error into the note;
the server speaks in clear strings (`PHONE_CODE_INVALID`, `password needed for
login`, ...).

## Cover note template

> Subject: try2reverse submission - Python client
>
> Hi,
>
> Attached is my entry: a from-scratch Python client for Bale, built by
> extracting the protocol from the web client you provided.
>
> Protocol coverage (all recovered from the bundle, nothing guessed):
> - 53 services, 699 RPCs, 2012 message types
> - machine-readable schema + a single `bale.proto` that compiles with protoc
> - both transports: gRPC-web over HTTPS for login, protobuf-framed WebSocket
>   (`/ws/`, `Cookie: access_token=...`) for everything else
> - handshake (`mkprotoVersion`/`apiVersion`), 10 s ping/pong, request-id
>   correlation, 4401 close = unauthenticated, reconnect policy
> - login state machine (StartPhoneAuth → ValidateCode → optional
>   ValidatePassword / SignUp) and the 147-variant update union
>
> Language: Python end to end (the allowed set is Java / C# / Kotlin / Python).
> Two front ends on one Python core: a native tkinter desktop GUI
> (`python run.py native`, no browser, no JavaScript) and a browser GUI
> (`python run.py gui`).
>
> Client: a full GUI messenger - login with SMS code and
> 2FA, chat list with real avatars/unread badges/search, message view with day
> separators, sender names, quoted messages and delivery ticks, live incoming
> updates, typing indicators, attachments (photo/voice/video/file upload with
> the same single- and multi-chunk PUT the web client uses), inline media
> rendering and downloads, replies, edits, deletes, forwards, emoji reactions,
> group member lists, a profile panel, message search across all chats, dark
> mode, RTL/LTR (Persian / English) and an offline demo mode for reviewers.
> Also a terminal client (`login`, `chats`, `history`, `send`, `listen`,
> `repl`). 18 offline protocol tests, one third-party dependency (websockets).
>
> The reverse-engineering write-up is in PROTOCOL.md; `out/bale.proto` is the
> extracted definition, `out/schema.json` the raw extraction.
>
> Best regards,
> <name>

## Before you hit send

- [ ] `python3 -m unittest discover -s tests` passes
- [ ] `python3 run.py demo` prints protocol frames (works with no account)
- [ ] `python3 run.py gui --demo` shows the messenger with photos, a voice
      note, a file, reactions and a live incoming-message loop
- [ ] `python run.py native --demo` opens the same thing as a desktop window
      (needs Tk, which ships with the python.org installer on Windows)
- [ ] `python3 run.py login` works with *your* number
- [ ] you can see your chat list and receive a message you send from your phone
- [ ] no secrets in the zip (`grep -ri "access_token" .` -> only source code)
- [ ] the note says what is tested and what is not

## Reality check about the prize

The repository, the account and the "100 000" prize all appeared on the same
day, the contact is a Gmail address, and nothing in the repo verifies that the
money exists. Treat the prize as **unconfirmed**:

- never pay a "fee", "tax" or "deposit" to receive a prize;
- never send your Bale login, SMS code or ID documents;
- don't sign anything that gives away your rights beyond the submission;
- if they ask for a wallet seed phrase or a card number, it is a scam.

The work here is valuable on its own: it is a complete, documented protocol
implementation and a working client.
