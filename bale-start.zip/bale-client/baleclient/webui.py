"""
baleclient.webui - the GUI: a local HTTP/SSE server that serves a chat web app
and bridges it to a live :class:`BaleClient`.

    python run.py gui            # real client, opens the browser
    python run.py gui --demo     # offline demo with fake data (no account)

Stdlib only (http.server + json + asyncio), so there is nothing extra to
install on top of the client itself.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import mimetypes
import os
import queue
import threading
import time
import traceback
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qs, urlparse

from .client import BaleClient, Chat, Message, Peer, _content_text, unwrap
from .transport import BaleRpcError, TransportError

# Inline SVG used as the demo photo (data URI: no external file, no PIL).
DEMO_PHOTO = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCAEOAeADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDx3bRtqbZRsr3+c+f9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsiHbRtqbZRso5w9kQ7aNtTbKNlHOHsibbRtqbZ7UbPauXnPQ9kQ7aNtTbPajZ7Uc4eyIdtG2ptntRs9qOcPZEO2jbU2z2o2e1HOHsiHbRtqbZ7UbPajnD2RDto21Ns9qNntRzh7Ih20bam2e1Gz2o5w9kQ7aNtTbPajZ7Uc4eyIdtG2ptntRs9qOcPZEO2jbU2z2o2e1HOHsiHbRtqbZ7UbPajnD2RDto21Ns9qNntRzh7Ih20bam2e1Gz2o5w9kQ7aNtTbPajZ7Uc4eyIdtG2ptntRs9qOcPZEO2jbU2z2o2e1HOHsiHbRtqbZ7UbPajnD2RDto21Ns9qNntRzh7Ih20bam2e1Gz2o5w9kQ7aNtTbPajZ7Uc4eyIdtG2ptntRs9qOcPZEO2jbU2z2o2e1HOHsiHbRtqbZ7UbPajnD2RDto21Ns9qNntRzh7Ih20bam2e1Gz2o5w9kQ7aNtTbPajZ7Uc4eyIdtG2ptntRs9qOcPZEO2jbU2z2o2e1HOHsiHbRtqbZ7UbPajnD2RDto21Ns9qNntRzh7Im20ban2UbK5Oc9D2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyINtG2p9lGyjnD2RBto21Pso2Uc4eyJtlGyptlGyuTnPR9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsiHZRsqbZRso5w9kQ7KNlTbKNlHOHsifbRtqbbRtrk5z0PZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Ih20bam20baOcPZEO2jbU22jbRzh7Im20ban20ba5ec9D2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyINtG2p9tG2jnD2RBto21Pto20c4eyJttG2pttG2uTnPQ9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsiHbRtqbbRto5w9kQ7aNtTbaNtHOHsifbRtqbYaNhrl5z0fZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Ih20bam2GjYaOcPZEO2jbU2w0bDRzh7Im20bam20ba5Oc9D2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezIdtG2pttG2jnD2ZDto21Nto20c4ezJ9lGyp9lGyuXnOu5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XINlGyp9lGyjnC5Bso2VPso2Uc4XJttG2p9lGyufmMrkG2jbU+yjZRzBcg20ban2UbKOYLkG2jbU+yjZRzBcg20ban2UbKOYLkG2jbU+yjZRzBcg20baLy6ttOtnuby4it7ePG6WZwiLk4GSeByQK821v45eHrBCumx3GpTbQylVMUec4ILMNwIHPCkdOeuOnD4aviHajFv8vv2OTFZhh8Ir15qP5/duz0nbRtr5g1/4seJ9e2L9t+wRJg7LDdFkjPJbJbv0zjgcZ5qjoXxF8S+HvLS11SWS3TYPs9x+9j2r0QBuVGOPlI4+gr2Vw7iHC7kr9v+CfPy4vwqqcqhJx76fkfVu2jbXkPhz482cypFr9i9vMWC/aLQbo8EnJKk7lAGOhYnngcCvTNE8U6J4kUHS9St7lypfylbEgUHBJQ4YDOOo7j1FeTicDicN/Fg0u/T7z28JmuExaXsaib7bP7jS20ban2UbK4+Y9C5Bto21Pso2UcwXINtG2p9lGyjmC5Bto21Pso2UcwXINtG2p9lGyjmC5Bto21Pso2UcwXINtG2p9lGyjmC5Bto21Pso2UcwXINtG2p9lGyjmC5Bto21Pso2UcwXINtG2p9lGyjmC5Bto21PsrQ0XQrzX9QjsrKPfK/JJ4VF7sx7Af/AFhkkChSuTKpGEXKTskZ1tZXF7OsFtBLPO+dscSlmOBk4A56CvSNH+DN5Nsk1W+jt0O1jFAN74/iUk4CkdMjcP6+keGPCWn+F7RI7eNXuiuJbplG+QnGRnsvA+Xpx3OSd6umNP8AmPlMbn1ST5cNou/X/gHE2Xwo8NWsRSW2nu2LZ3zTMCB6fJtGPwzzT7r4V+GLiB447KW3dsYlincsvPbcSPbkV2dFacq7Hk/2hir83tJfezyHVvgs4YtpOpKVLDEV2MFRjk71HJz22jg9eOfNNR0m90i6a2vraW3nX+GQYyMkZB6EZB5HBr6prM1zw/p/iGza2v7dZBtISQAb4iccq3Y8D645yKiVO+x6mDz6rTajX95fj/wT5e20ba6LxP4WvPC2oG2uRvifJhnUYWVf6Edx29wQTibK5m2nZn1lOrGpFTg7pkG2jbU+yjZS5i7kG2jbU+yjZRzBcg20ban2UbKOYLkG2jbU+yjZRzBcg20ban2UbKOYLk+2jbU+2jbXPzGPMQbaNtT7aNtHMHMQbaNtT7aNtHMHMQbaNtT7azNZ1/SvD0PnapqFtZoVZlE0gDOFGTtXqx5HABPI9aqPNN8sVdkzqRguabsi5to21414l/aBs4EeHw/YPcTBiv2i8G2LAIwQoO5gRnqVI44PIryjxL8Q/EXitHh1HUX+yMxb7LCBHFgkEAgfeAIGNxJGOvWvcwvD+LrWdT3F57/d/nY8DGcT4SheNP335bff/lc+ivEfxQ8MeGZJoLi/+0XkX3ra0XzHB3bSpP3QwwcgsDx9M+U+I/jzq15JNFolrDY2x4SaVfMm4bO7n5RkYGMNjnnpjyOivpMLkGFoazXO/Pb7v87ny2M4lxuIuoPkXlv9+/3WL2razqGvXjXmpXc11ctn55WztGScAdFGScAYAzxVGiivZjFRXLFWR4MpSm3KTu2FFFFUSFFFFAHa6H8V/FehuNupvew7izRX374MSMfePzgDg4DAZ+pz6rofx70S+cR6rZ3OmuzEeYp8+JVAyCSAGyTkYCntz1x860V5mJyfCYjWULPutP8Agfej18JnmNwukZ3XZ6/8FfJn2lo+vaX4gh87S9Qt7tAqswikBZAwyNy9VPB4IB4PpWltr4fgnltpo54JHimiYOkiMVZGByCCOhBr0Hw18aPEugokFzKmqWoYEi8JMoXJLASA5yc9W3YwMDHFfP4rhmrHXDz5vJ6P79vyPpcJxbTlaOJhy+a1X3b/AJn0/to215hoXx58OagirqcVzpc20sxZTNFnOAAyjcSRzyoHXnpn0rTtSsdXhafT722vIVbYZLeVZFDYBxlSecEce9fP4jCYjDO1aDX5ffsfSYbMMPilejNP8/u3JdtG2p9tG2uXmOrmINtG2p9tG2jmDmINtG2p9tG2jmDmINtG2p9tG2jmDmINtG2p9tG2jmDmINtG2p9tG2jmDmINtG2p9tG2jmDmINtG2p9tG2jmDmINte5fDjwxFo2jx30gje9vkWTzADlIyAVTJ/M4xz64BryLRNN/tXV7GyKyFJ5lR/LHzBc/MR9Bk/hX0Xd3dvp9pPd3c8VvaW8bSyzTOESNFGWZmPAAAJJPSurCx5m2fP59inGEaMXvqyaivNde/aC+GPhz7P8AbPGely+fu2/YHa8xtxnd5Ifb1GN2M84zg48v8QftteC7CO9TRtG1nU7uGTZCZVS3t5wGwW3lmdQVywzHnoCF5x69PA4ip8MGfJSrU47yPpqivhvXP24/FFxdo2ieGNGsrQRgNHfPLdOXyckOpjAGMcbT0PPOBm6R+2x48s/sMeoaXoN/DD5a3D+TJFNcKMbjuD7FdhnkJtBP3ccV1rJsU1ey+8y+uUr7n3tRXyZof7c+j3F26634Pv7K0EZKyWN4l05fIwCjLGAMZ53HoOOcjvtD/a8+F2rWjzXep3+kSLIUEF9YyM7DAO4GESLjkjkg8HjGCeeeXYqG9N/LX8i44ilLaR6t4v8ADMXijSXt8Rrdx/NbzOD8jdxx2IGD17HBwK+eNte66R8WfAeu/YV0/wAY6DNNf+WLe3+3RrM7PjanlEhw5JA2kBs8YzXmfjvTf7P8VaioWQRzP56s4+9vG449RuLD8K8nGUpU7OSsfVZBi781C91uv1OW20ban20ba4eY+l5iDbRtqfbRto5g5iDbRtqfbRto5g5iDbRtqfbRto5g5iDbRtqfbRto5g5ibZRsqfbRtrn5jLmINlGyuf8AE3xA8OeEo5v7R1OEXMXBtIWEk5YruA2DkZHQtgcjJGa8i8TftFTzxzQeHtM+z7uEu7xgzgFeSIxwGDHglmHHI5wPSwmV4vF2dKGnd6L/AIPyPOxeb4TC6VJ69lq/69T3meSK1glnnkSKCJS7ySMFVFAySSegA71514m+Nfhjw+7wW0r6rdBSQLMgxBsAqDITjBz1XdjByM8V85a94w13xO7HVtUubpCwfymfESsBgERjCg4zyB3PqaxK+mwnC0I+9iZ38lovv3/I+ZxfFdSXu4aNvN6v7tvzPTvE3xy8R607x6cU0mzZSmyHDykEAHMhHBByQVCkZ74BrzWeeW6nknnkeWaVi7yOxZnYnJJJ6knvUdFfSYfCUMNHlowUf66vd/M+axOMr4qXNXm5f10Wy+QUUUV0nMFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFT2V9dabcpdWdzNbXMedksLlHXIwcEcjgkfjUFFJpNWY02ndHq2g/HzxHpzqupxW2qQ7izFlEMuMYADKNoAPPKk9eemPT/AA/8cfC2s+XFdyTaXctsXbcrmMu3UB1yAoP8TbeDn1x8tUV42JyDBV9VHlflp+G34HtYXiDHUNHLmX97X8d/xPumyu7XUrZLqyuYbm2kzsmgkDo2Dg4I4PII/CrGyviHRfEWreHZ/O0rUbmzcsrsIZCFkKnI3L0YDJ4II5PrXpugftDa7YIserWNtqaKpHmKfIlZicgkgFcAZGAo7c9c/OYrhjE023QkpL7n/l+J9HheKcPUSVdOL+9f5/gfSOyjZXCaB8afCGuusbXz6dOzFVS/TywQBndvBKAdRywOR05GfQttfPV6FbDy5a0XF+aPoKGKpYiPNRkpLyINlGyp9tRzyxWsEs88qRQRKXeSRgqooGSSTwAB3rBSvojZytqxmyjZXL6n8UPB2k+V9o8QWT+bnb9mY3GMY6+WG29e+M846GuN1T9ojw9bJcLp+n395PG22MuFiilGcbt2SwGMkZXPQEDt30ctxlb4KT+6y+96HFWzXCUfjqr77v7ketbKNlfO2o/tHazLOp07R9Pt4NuClyzzMWyedylBjGOMfj6cTqPxX8Z6pAsM+v3KIrbwbYLA2cEfejCkjnpnH5V6lHhnGz+O0fV3/K/5nl1uKMHD4Ly9Fb87fkfXc8kVrBLPPIkUESl3kkYKqKBkkk9AB3rldS+J3g/SfK8/X7N/Nzt+zMbjGMdfLDY698Z5x0NfIl7fXWpXL3V7czXNzJjfNO5d2wMDJPJ4AH4VXr1aPClNfxajforfnc8utxbUf8Kml6u/5WPpLVP2hPD9slwthYX95NG22MuFiikGcbt2SwGORlc9MgduS1H9onWJZ1On6PYW8O3BS4Z5mLZPO5SnGMcY/GvGqK9OlkGBp/Yv6t/8MeXW4hx9T7dvRL/h/wATtbj4u+N7jyyPEl7bPG29ZLMrbSA4I+/GFbGCeM4rltV1fUNdv5tQ1W+ur+/mx5lzdzNLK+AFGWYknAAHPYCqdFerSoUqKtSio+iSPJq16tZ81WTk/N3CiiitTIKKKKACiiigAq3p2q3+kTtPp97c2czLsMlvK0bFcg4ypHGQOPaqlFJxUlZocZOLvF2Z2GnfFTxjpcLQwa9cujNvJuAs7ZwB96QMQOOmcfnXU2P7QfiSD7Ml1Zabcxx7RK3lukkoHU5DbQx9QuAT07V5NRXFVyzB1fjpL7rfkd1LNMZS+CrL77/mfQenftGWEs7DUNBubeHbkPbzrMxbI42sE4xnnP4V0unfHHwbewNJPd3Ni4baIri3YsRgfN+73DHOOueOlfK9FedV4bwM/hTj6P8AzuejS4mx8Pial6r/ACsfaVj418Nal9mFrr2mSSXO3yovtKCRi3RdhO4NzjBGc8Yrf2V8HVc07Vb/AEedp9OvrmznZdhktpWjYrkHGVI4yBx7V51XhNf8uqv3r/g/oejS4tl/y9pfc/8AgfqfcuyjZXyBp3xX8Z6XA0MGv3LozbybkLO2cAfekDEDjpnH511Vj+0P4lt/syXVlplzHHtEreW6SSgYychtoY+oXAJ6dq86rwxjIfA1L5/5r9T0aXFOEl8alH5f5P8AQ+ldlGyvFdO/aR0+WdhqOgXNvBtyHtp1mYtkcbWCDGM85/D06fTvjr4LvoGknvLmwcNtEVzbOWIwPm/d7hjnHXPHSvOq5Pj6XxUn8tfyuehSzrA1fhqr56fnYz/En7Qvh7TPLTRrebV5GwWbm3jUc5GWXcW4HG3GD14xXjmv/GHxhr7tu1V7GDcHWHT/ANyFIGPvA7yDycFiM/QY4Sivu8HkeCwusYcz7vV/5L5I+CxWdYzE6SnZdlp/wfvYUUUV655QUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAVuaB4x17wu6nSNVubVAxfylfMTMRtJMZypOMckdh6CsOioqU4VI8s0muz1LhUlTlzQdn5HZ6l8WfGmqwLDP4guURW3g2wWBs4I+9GFJHPTOPyrlL2/utTupLq9uZrq6kxvmnkLu2BgZY8ngAfhVeiopYajR/hQUfRJfkXVxFWt/Fm5erbCiiitjEKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/Z"

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")


# --------------------------------------------------------------------------- helpers
def _avatar_color(text: str) -> str:
    palette = ["#e17076", "#7bc862", "#65aadd", "#a695e7", "#ee7aae",
               "#faa774", "#6ec9cb", "#f2921d", "#8e9bd8", "#5fc88f"]
    return palette[sum(ord(c) for c in (text or "?")) % len(palette)]


def chat_json(chat: Chat) -> Dict[str, Any]:
    return {
        "peer": chat.peer.key,
        "type": chat.peer.type,
        "id": chat.peer.id,
        "title": chat.title or chat.peer.key,
        "unread": chat.unread,
        "date": chat.date,
        "preview": chat.last_text or "",
        "isGroup": chat.is_group,
        "color": _avatar_color(chat.title or chat.peer.key),
        "avatar": f"/api/avatar?peer={chat.peer.key}",
    }


def media_of(content: Any) -> Optional[Dict[str, Any]]:
    """Extract file metadata from a DocumentMessage (photos, files, voice...)."""
    if not isinstance(content, dict):
        return None
    doc = content.get("documentMessage")
    if not isinstance(doc, dict):
        return None
    ext = doc.get("ext") or {}
    kind = "document"
    for key, label in (("documentExPhoto", "photo"), ("documentExVideo", "video"),
                       ("documentExVoice", "voice"), ("documentExGif", "gif"),
                       ("documentExAudio", "audio")):
        if isinstance(ext.get(key), dict):
            kind = label
            break
    mime = doc.get("mimeType") or ""
    if kind == "document":
        if mime.startswith("image/"):
            kind = "photo"
        elif mime.startswith("video/"):
            kind = "video"
        elif mime.startswith("audio/"):
            kind = "audio"
    photo_ext = ext.get("documentExPhoto") or {}
    caption = ""
    if isinstance(doc.get("caption"), dict):
        caption = doc["caption"].get("text", "") or ""
    return {
        "kind": kind, "fileId": int(doc.get("fileId") or 0),
        "accessHash": int(doc.get("accessHash") or 0),
        "fileSize": int(doc.get("fileSize") or 0),
        "name": doc.get("name") or ("photo" if kind == "photo" else "file"),
        "mime": mime, "caption": caption,
        "w": int(photo_ext.get("w") or 0), "h": int(photo_ext.get("h") or 0),
    }


def message_json(msg: Message, my_id: Optional[int], names: Dict[int, str]) -> Dict[str, Any]:
    quoted = (msg.raw or {}).get("quotedMessage") or {}
    quoted_text = ""
    if isinstance(quoted, dict):
        content = quoted.get("message") or {}
        if isinstance(content, dict):
            for key in ("textMessage", "longTextMessage"):
                value = content.get(key)
                if isinstance(value, dict) and value.get("text"):
                    quoted_text = value["text"]
                    break
    raw = msg.raw or {}
    content = raw.get("message") or {}
    media = media_of(content)
    reactions = []
    for reaction in raw.get("reactions", []) or []:
        if isinstance(reaction, dict):
            code = reaction.get("code") or reaction.get("emoji") or reaction.get("reaction")
            count = reaction.get("count") or reaction.get("counts")
            if code:
                reactions.append({"code": str(code), "count": int(count or 1)})
    return {
        "id": f"{msg.peer.key}:{msg.rid}:{msg.date}",
        "peer": msg.peer.key,
        "sender": msg.sender_uid,
        "senderName": names.get(msg.sender_uid) or str(msg.sender_uid),
        "date": msg.date,
        "text": msg.text,
        "kind": msg.kind,
        "out": bool(my_id and msg.sender_uid == my_id),
        "quoted": quoted_text,
        "rid": msg.rid,
        "seq": int((raw.get("previousMessageId") or {}).get("seq", 0) or 0),
        "media": media,
        "reactions": reactions,
    }


# --------------------------------------------------------------------------- demo backend
class DemoBackend:
    """Fake transport used by ``run.py gui --demo`` - lets the UI be shown
    without an account (handy for screenshots and for judges)."""

    def __init__(self, client: BaleClient):
        self.client = client
        self.now = int(time.time() * 1000)
        self.on_event = None
        self.conversations = {
            "u:1545969305": ("سینا", [
                ("them", "سلام! کلاینت جدیدت آماده شد؟"),
                ("me", "آره، همین الان لاگین کردم 😄"),
                ("them", "عالیه، بفرست ببینم"),
                ("me", "این پیام از کلاینت خودمون میاد"),
                ("me", {"text": "", "media": {"kind": "photo", "fileId": 0, "accessHash": 0,
                        "fileSize": 0, "name": "sunset.jpg", "mime": "image/jpeg",
                        "caption": "غروب امروز 🌅", "w": 480, "h": 270},
                        "local": DEMO_PHOTO}),
                ("them", {"text": "", "media": {"kind": "voice", "fileId": 1002,
                        "accessHash": 0, "fileSize": 24044, "name": "voice-1.wav",
                        "mime": "audio/wav", "caption": "", "w": 0, "h": 0}}),
                ("them", {"text": "", "media": {"kind": "document", "fileId": 1001,
                        "accessHash": 0, "fileSize": 96, "name": "bale.proto.txt",
                        "mime": "text/plain", "caption": "لیست کامل متدها", "w": 0, "h": 0},
                        "reactions": [{"code": "👍", "count": 2}, {"code": "🔥", "count": 1}]}),
            ]),
            "g:255637216": ("Bale Devs", [
                ("them", "did anyone decode the update union yet?"),
                ("me", "147 variants, all of them in bale.proto"),
                ("them", "nice. can you send files?"),
            ]),
            "u:967099999": ("Saved Messages", [
                ("me", "ble.ir/join/CiX98k7Rmw"),
            ]),
            "g:1925235074": ("Family", [
                ("them", "زن دایی مرتضی به بله پیوست."),
                ("me", "welcome!"),
            ]),
        }
        self.cursor = {k: len(v[1]) for k, v in self.conversations.items()}
        self.media = {
            1001: (b"// bale.proto - extracted from the official web client\n"
                   b"// 2012 messages, 699 rpcs, 53 services\n"
                   b"syntax = \"proto3\";\npackage ai.bale;\n",
                   "text/plain; charset=utf-8", "bale.proto.txt"),
            1002: (self._beep(), "audio/wav", "voice-1.wav"),
        }

    @staticmethod
    def _beep() -> bytes:
        """A short 8 kHz tone so the demo voice bubble really plays."""
        import io, math, struct, wave
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000)
            frames = bytearray()
            for i in range(12000):
                fade = min(1.0, i / 800.0, (12000 - i) / 800.0)
                frames += struct.pack("<h", int(9000 * fade * math.sin(2 * math.pi * 440 * i / 8000)))
            w.writeframes(bytes(frames))
        return buf.getvalue()

    def media_blob(self, file_id: int):
        return self.media.get(int(file_id))

    # -- api used by the http layer ---------------------------------------
    def dialogs(self) -> List[Dict[str, Any]]:
        out = []
        for i, (key, (title, msgs)) in enumerate(self.conversations.items()):
            last = msgs[-1][1] if msgs else ""
            if isinstance(last, dict):
                m = last.get("media") or {}
                caption = m.get("caption") or ""
                kind = m.get("kind") or "document"
                icon = {"photo": "📷", "voice": "🎤", "audio": "🎵",
                        "video": "🎬", "gif": "🎞"}.get(kind, "📎")
                last = caption or f"{icon} {m.get('name') or kind}"
            out.append({
                "peer": key, "type": 2 if key.startswith("g:") else 1,
                "id": int(key.split(":")[1]), "title": title,
                "unread": 0 if i else 2, "date": self.now - i * 3_600_000,
                "preview": last, "isGroup": key.startswith("g:"),
                "color": _avatar_color(title),
            })
        return out

    def history(self, peer: str, limit: int = 40) -> List[Dict[str, Any]]:
        title, msgs = self.conversations.get(peer, ("", []))
        base = self.now - len(msgs) * 90_000
        out = []
        for i, (who, text) in enumerate(msgs):
            extra = {}
            if isinstance(text, dict):
                extra = text
                text = extra.get("text", "")
            out.append({
                "id": f"{peer}:{i}:{base + i * 90_000}",
                "peer": peer, "sender": 1 if who == "me" else 2,
                "senderName": "me" if who == "me" else title,
                "date": base + i * 90_000, "text": text, "kind": "text",
                "out": who == "me", "quoted": extra.get("quoted", ""),
                "media": extra.get("media"), "local": extra.get("local"),
                "reactions": extra.get("reactions", []), "rid": i,
            })
        return out[-limit:]

    def send(self, peer: str, text: str) -> Dict[str, Any]:
        title, msgs = self.conversations.setdefault(peer, (peer, []))
        msgs.append(("me", text))
        return {"ok": True}

    def start_typing(self, peer: str) -> None:
        pass

    def send_media(self, peer: str, name: str, caption: str = "") -> Dict[str, Any]:
        title, msgs = self.conversations.setdefault(peer, (peer, []))
        msgs.append(("me", caption or f"📎 {name}"))
        return {"ok": True}

    def delete(self, peer: str, dates: List[int]) -> Dict[str, Any]:
        return {"ok": True}

    def edit(self, peer: str, rid: int, text: str) -> Dict[str, Any]:
        return {"ok": True}

    def forward(self, src: str, dst: str, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {"ok": True}

    def profile(self, peer: str) -> Dict[str, Any]:
        title, msgs = self.conversations.get(peer, (peer, []))
        is_group = peer.startswith("g:")
        return {
            "peer": peer, "title": title, "isGroup": is_group,
            "subtitle": "group · 3 members" if is_group else "user",
            "about": ("کلاینت ساخته‌شده برای چالش try2reverse — همه‌ی پیام‌ها روی "
                      "پروتکل واقعی بله" if is_group else "با کلاینت سفارشی بله در ارتباط است"),
            "members": 3 if is_group else 0,
            "id": int(peer.split(":")[1]) if ":" in peer else 0,
        }

    def search(self, query: str) -> List[Dict[str, Any]]:
        q = query.lower()
        out = []
        for peer, (title, msgs) in self.conversations.items():
            for i, (who, text) in enumerate(msgs):
                if isinstance(text, dict):
                    text = text.get("text") or (text.get("media") or {}).get("caption") or ""
                if q in str(text).lower():
                    out.append({"peer": peer, "title": title, "text": text,
                                "senderName": "me" if who == "me" else title,
                                "date": self.now - (len(msgs) - i) * 90_000,
                                "out": who == "me"})
        return out[:40]

    def members(self, peer: str) -> List[Dict[str, Any]]:
        title = (self.conversations.get(peer) or ("", []))[0]
        return [{"uid": 1545969305, "name": title or "member", "isAdmin": True, "title": "owner"},
                {"uid": 967099999, "name": "Maryam", "isAdmin": False, "title": ""},
                {"uid": 112233, "name": "Ali", "isAdmin": False, "title": ""}]


# --------------------------------------------------------------------------- app
class WebApp:
    def __init__(self, client: BaleClient, demo: bool = False):
        self.client = client
        self.demo = demo
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.events: List[Dict[str, Any]] = []
        self.event_id = 0
        self.lock = threading.Lock()
        self.demo_backend = DemoBackend(client) if demo else None
        self.login_tx = ""
        self.activation = 0
        self.connected = False
        self.names: Dict[int, str] = {}
        self._avatar_cache: Dict[str, Optional[bytes]] = {}
        self._media_cache: Dict[str, Optional[bytes]] = {}

    # -- plumbing ----------------------------------------------------------
    def _run_loop(self) -> None:
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def start(self) -> None:
        self.thread.start()
        if self.demo:
            self.loop.call_soon_threadsafe(lambda: self.loop.create_task(self._demo_loop()))
        else:
            self.loop.call_soon_threadsafe(
                lambda: self.loop.create_task(self._auto_connect()))

    async def _auto_connect(self) -> None:
        """Resume a saved session without asking for an SMS code again."""
        token = self.client.token or self.client.state.get("token")
        if not token:
            return
        try:
            await self.client.connect(token)
            self.client.transport.update_callback = self._on_update
            self.connected = True
            self.client.transport.auto_reconnect = True
            print("[webui] resumed saved session")
        except Exception as exc:  # noqa: BLE001
            print(f"[webui] could not resume the saved session: {exc}")
            self.connected = False

    def call(self, coro, timeout: float = 60.0):
        fut = asyncio.run_coroutine_threadsafe(coro, self.loop)
        return fut.result(timeout)

    def push(self, kind: str, payload: Dict[str, Any]) -> None:
        with self.lock:
            self.event_id += 1
            self.events.append({"id": self.event_id, "type": kind, "data": payload})
            if len(self.events) > 500:
                self.events = self.events[-200:]

    def poll(self, since: int) -> Dict[str, Any]:
        with self.lock:
            items = [e for e in self.events if e["id"] > since]
            return {"events": items, "last": self.event_id}

    # -- demo --------------------------------------------------------------
    async def _demo_loop(self) -> None:
        await asyncio.sleep(6)
        idx = 0
        incoming = [
            ("u:1545969305", "این هم پیام زنده‌ی دمو 👋"),
            ("g:255637216", "the demo stream works - updates arrive over the websocket"),
            ("u:1545969305", "فایل پروتوی کامل رو هم فرستادم، چک کن"),
            ("g:255637216", "attachments, replies and forwards go through the same RPC layer"),
            ("u:1545969305", "دکمه‌ی پاسخ و ارجاع رو تست کردی؟"),
            ("g:255637216", "typing indicator is live from Presence/Typing"),
        ]
        while True:
            peer, text = incoming[idx % len(incoming)]
            idx += 1
            title, msgs = self.demo_backend.conversations[peer]
            self.push("typing", {"peer": peer, "uid": 2, "name": title, "type": 1})
            await asyncio.sleep(2.2)
            self.push("typing_stop", {"peer": peer, "uid": 2})
            msgs.append(("them", text))
            self.push("message", {
                "peer": peer, "text": text, "title": title,
                "senderName": title, "date": int(time.time() * 1000),
                "kind": "text", "out": False,
            })
            await asyncio.sleep(25)

    # -- auth --------------------------------------------------------------
    async def _do_login_start(self, phone: str) -> Dict[str, Any]:
        resp = await self.client.start_phone_auth(phone)
        self.login_tx = resp.get("transactionHash", "")
        self.activation = int(resp.get("activationType", 0) or 0)
        return {
            "status": "password" if self.activation == 1 else "code",
            "tx": self.login_tx,
            "sentCodeType": resp.get("sentCodeType"),
            "expires": unwrap(resp.get("codeExpirationDate")),
            "nextIn": unwrap(resp.get("nextSendCodeWaitTime")),
        }

    async def _do_login_code(self, code: str) -> Dict[str, Any]:
        result = await self.client.validate_code(self.login_tx, code)
        return await self._after_login(result)

    async def _do_login_password(self, password: str) -> Dict[str, Any]:
        result = await self.client.validate_password(self.login_tx, password)
        return await self._after_login(result)

    async def _do_signup(self, name: str) -> Dict[str, Any]:
        result = await self.client.sign_up(self.login_tx, name)
        return await self._after_login(result)

    async def _after_login(self, result: Dict[str, Any]) -> Dict[str, Any]:
        await self.client.connect()
        self.connected = True
        self.client.transport.update_callback = self._on_update
        self.push("status", {"connected": True})
        return {"status": "ok", "user": result.get("user") or self.client.me}

    TRANSLATIONS = {
        "fa": {"user": "کاربر", "group": "گروه", "bio": "", "members": "اعضا"},
        "en": {"user": "user", "group": "group", "bio": "", "members": "members"},
    }

    def t(self, key: str) -> str:
        lang = (self.client.state or {}).get("lang") or "fa"
        return self.TRANSLATIONS.get(lang, self.TRANSLATIONS["fa"]).get(key, key)

    # -- data --------------------------------------------------------------
    async def _dialogs(self) -> Dict[str, Any]:
        if self.demo:
            return {"chats": self.demo_backend.dialogs(), "me": {"id": 1, "name": "Demo"}}
        chats = await self.client.load_dialogs(limit=80)
        self._remember_names()
        return {"chats": [chat_json(c) for c in chats], "me": self.client.me}

    def _remember_names(self) -> None:
        for uid, user in self.client.users.items():
            name = user.get("name") or user.get("nick")
            if name:
                self.names[uid] = name

    async def _history(self, peer_key: str, limit: int, date: Optional[int]) -> Dict[str, Any]:
        if self.demo:
            return {"messages": self.demo_backend.history(peer_key, limit)}
        peer = Peer.parse(peer_key)
        known = self.client.peers.get(peer.key)
        if known and known.access_hash:
            peer.access_hash = known.access_hash
        msgs = await self.client.load_history(peer, limit=limit,
                                              date=-1 if date is None else date)
        self._remember_names()
        my_id = (self.client.me or {}).get("id")
        return {"messages": [message_json(m, my_id, self.names) for m in msgs]}

    async def _send(self, peer_key: str, text: str,
                    reply: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if self.demo:
            self.demo_backend.send(peer_key, text)
            return {"ok": True}
        peer = Peer.parse(peer_key)
        known = self.client.peers.get(peer.key)
        if known and known.access_hash:
            peer.access_hash = known.access_hash
        quoted = None
        if reply:
            quoted = {"peer": peer.to_dict(), "rid": int(reply.get("rid", 0) or 0),
                      "date": int(reply.get("date", 0) or 0),
                      "seq": int(reply.get("seq", 0) or 0)}
        await self.client.send_text(peer, text, reply_to=quoted)
        return {"ok": True}

    async def _read(self, peer_key: str, date: int) -> Dict[str, Any]:
        if self.demo:
            return {"ok": True}
        peer = Peer.parse(peer_key)
        await self.client.message_read(peer, date)
        return {"ok": True}

    # -- media -------------------------------------------------------------
    async def _avatar(self, peer_key: str) -> Optional[bytes]:
        if self.demo:
            return None
        peer = Peer.parse(peer_key)
        cache_key = f"{peer.key}:{self.client.jwt_expiry()}"
        if cache_key in self._avatar_cache:
            return self._avatar_cache[cache_key]
        if peer.type == 1 and peer.id not in self.client.users:
            await self.client.load_users([peer.id])
        if peer.type == 2 and peer.id not in self.client.groups:
            await self.client.load_groups([peer.id])
        parts = self.client.avatar_url_parts(peer.type, peer.id)
        if not parts:
            self._avatar_cache[cache_key] = None
            return None
        try:
            data = await self.client.download_file(*parts)
        except Exception:  # noqa: BLE001
            data = None
        self._avatar_cache[cache_key] = data
        return data

    async def _media(self, file_id: int, access_hash: int) -> Optional[bytes]:
        if self.demo:
            return None
        key = f"{file_id}:{access_hash}"
        if key in self._media_cache:
            return self._media_cache[key]
        data = await self.client.download_file(file_id, access_hash)
        if len(self._media_cache) > 60:
            self._media_cache.clear()
        self._media_cache[key] = data
        return data

    async def _send_media(self, peer_key: str, name: str, mime: str,
                          data_b64: str, caption: str) -> Dict[str, Any]:
        import base64
        data = base64.b64decode(data_b64)
        if self.demo:
            return self.demo_backend.send_media(peer_key, name, caption)
        peer = Peer.parse(peer_key)
        known = self.client.peers.get(peer.key)
        if known and known.access_hash:
            peer.access_hash = known.access_hash
        await self.client.send_media(peer, data, caption=caption, name=name, mime=mime)
        return {"ok": True}

    async def _delete(self, peer_key: str, dates: List[int]) -> Dict[str, Any]:
        if self.demo:
            return self.demo_backend.delete(peer_key, dates)
        await self.client.delete_messages(Peer.parse(peer_key), dates)
        return {"ok": True}

    async def _edit(self, peer_key: str, rid: int, text: str) -> Dict[str, Any]:
        if self.demo:
            return self.demo_backend.edit(peer_key, rid, text)
        await self.client.edit_message(Peer.parse(peer_key), rid, text)
        return {"ok": True}

    async def _forward(self, from_key: str, to_key: str,
                       messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        if self.demo:
            return self.demo_backend.forward(from_key, to_key, messages)
        await self.client.forward_messages(Peer.parse(to_key), Peer.parse(from_key), messages)
        return {"ok": True}

    async def _typing(self, peer_key: str) -> Dict[str, Any]:
        if self.demo:
            return {"ok": True}
        await self.client.send_typing(Peer.parse(peer_key))
        return {"ok": True}

    async def _profile(self, peer_key: str) -> Dict[str, Any]:
        if self.demo:
            return self.demo_backend.profile(peer_key)
        peer = Peer.parse(peer_key)
        if peer.type == 1:
            if peer.id not in self.client.users:
                await self.client.load_users([peer.id])
            user = self.client.users.get(peer.id) or {}
            nick = unwrap(user.get("nick")) or ""
            return {
                "peer": peer.key,
                "title": user.get("name") or str(peer.id),
                "isGroup": False,
                "subtitle": f"@{nick}" if nick else self.t("user"),
                "about": self.t("bio") if user.get("name") else "",
                "members": 0, "id": peer.id,
                "isBot": bool(unwrap(user.get("isBot"))),
            }
        if peer.id not in self.client.groups:
            await self.client.load_groups([peer.id])
        group = self.client.groups.get(peer.id) or {}
        members = group.get("members") or []
        return {
            "peer": peer.key,
            "title": group.get("title") or str(peer.id),
            "isGroup": True,
            "subtitle": self.t("group"),
            "about": unwrap(group.get("about")) or "",
            "members": len(members) if isinstance(members, list) else int(group.get("memberCount") or 0),
            "id": peer.id,
        }

    async def _search(self, query: str, peer_key: str = "") -> Dict[str, Any]:
        if self.demo:
            return {"results": self.demo_backend.search(query)}
        peer = Peer.parse(peer_key) if peer_key else None
        if peer is not None:
            known = self.client.peers.get(peer.key)
            if known and known.access_hash:
                peer.access_hash = known.access_hash
        data = await self.client.search_messages(query, peer=peer)
        names: Dict[str, str] = {}
        for user in data.get("users", []) or []:
            uid = int(user.get("id", 0) or 0)
            name = f"{user.get('firstName', '')} {user.get('lastName', '')}".strip()
            names[f"u:{uid}"] = name or str(uid)
            self.names[uid] = names[f"u:{uid}"]
        for group in data.get("groups", []) or []:
            gid = int(group.get("id", 0) or 0)
            names[f"g:{gid}"] = group.get("title") or str(gid)
        out = []
        for item in data.get("results", []):
            p = item.get("peer") or {}
            ptype = int(p.get("type", 1) or 1)
            key = f"{'g' if ptype == 2 else 'u'}:{p.get('id')}"
            known = self.client.peers.get(key) or {}
            out.append({
                "peer": key,
                "title": names.get(key) or known.get("title") or key,
                "senderName": self.names.get(item.get("sender", 0), str(item.get("sender", 0))),
                "text": _content_text(item.get("content")) or "",
                "date": item.get("date", 0),
                "rid": item.get("rid", 0),
                "out": bool(self.client.me and item.get("sender") == self.client.me.get("id")),
            })
        return {"results": out}

    async def _react(self, peer_key: str, rid: int, date: int, code: str,
                     remove: bool = False) -> Dict[str, Any]:
        if self.demo:
            return {"ok": True}
        peer = Peer.parse(peer_key)
        known = self.client.peers.get(peer.key)
        if known and known.access_hash:
            peer.access_hash = known.access_hash
        if remove:
            await self.client.remove_reaction(peer, rid, code, date)
        else:
            await self.client.set_reaction(peer, rid, code, date)
        return {"ok": True}

    async def _members(self, peer_key: str) -> Dict[str, Any]:
        if self.demo:
            return {"members": self.demo_backend.members(peer_key)}
        peer = Peer.parse(peer_key)
        if peer.type != 2:
            return {"members": []}
        members = await self.client.load_group_members(peer.id)
        await self.client.load_users([int(m.get("uid", 0)) for m in members][:100])
        out = []
        for member in members:
            uid = int(member.get("uid", 0) or 0)
            user = self.client.users.get(uid) or {}
            out.append({"uid": uid, "name": user.get("name") or str(uid),
                        "isAdmin": bool(unwrap(member.get("isAdmin"))),
                        "title": unwrap(member.get("title")) or ""})
        return {"members": out}

    # -- updates -----------------------------------------------------------
    async def _on_update(self, body: Dict[str, Any]) -> None:
        try:
            if "message" in body:
                msg = body["message"] or {}
                peer = msg.get("peer") or {}
                kind = 2 if int(peer.get("type", 0)) == 2 else 1
                key = f"{'g' if kind == 2 else 'u'}:{peer.get('id')}"
                content = msg.get("message") or {}
                text = ""
                for k in ("textMessage", "longTextMessage", "serviceMessage"):
                    if isinstance(content.get(k), dict):
                        text = content[k].get("text", "") or ""
                        break
                if not text and isinstance(content, dict):
                    for k, v in content.items():
                        if isinstance(v, dict) and k != "_unknown":
                            text = f"[{k.replace('Message', '').lower()}]"
                            break
                sender = int(msg.get("senderUid", 0) or 0)
                self.push("message", {
                    "peer": key, "text": text, "sender": sender,
                    "senderName": self.names.get(sender, str(sender)),
                    "date": int(msg.get("date", 0) or 0), "kind": "text",
                    "out": bool(self.client.me and sender == self.client.me.get("id")),
                    "rid": int(msg.get("rid", 0) or 0),
                    "seq": int((msg.get("previousMessageId") or {}).get("seq", 0) or 0),
                    "media": media_of(msg.get("message") or {}),
                })
            elif "messageSent" in body:
                info = body["messageSent"] or {}
                peer = info.get("peer") or {}
                kind = 2 if int(peer.get("type", 0)) == 2 else 1
                self.push("sent", {"peer": f"{'g' if kind == 2 else 'u'}:{peer.get('id')}",
                                   "rid": int(info.get("rid", 0) or 0),
                                   "date": int(info.get("date", 0) or 0)})
            elif "reactionsUpdate" in body:
                info = body["reactionsUpdate"] or {}
                peer = info.get("peer") or {}
                f = info.get("field_26") or {}
                key = f"{'g' if int(peer.get('type', 0)) == 2 else 'u'}:{peer.get('id')}"
                card = unwrap(f.get("cardinality"))
                self.push("reaction", {
                    "peer": key, "rid": int(info.get("rid", 0) or 0),
                    "code": f.get("code") or "",
                    "count": int(card or len(f.get("users") or []) or 1),
                    "byMe": bool(info.get("reactionByMe")),
                })
            elif "typing" in body:
                info = body["typing"] or {}
                peer = info.get("peer") or {}
                uid = int(info.get("uid", 0) or 0)
                self.push("typing", {
                    "peer": f"{'g' if int(peer.get('type', 0)) == 2 else 'u'}:{peer.get('id')}",
                    "uid": uid, "name": self.names.get(uid, str(uid)),
                    "type": int(info.get("typingType", 1) or 1),
                })
            elif "typingStop" in body:
                info = body["typingStop"] or {}
                peer = info.get("peer") or {}
                self.push("typing_stop", {
                    "peer": f"{'g' if int(peer.get('type', 0)) == 2 else 'u'}:{peer.get('id')}",
                    "uid": int(info.get("uid", 0) or 0)})
            elif "messageRead" in body:
                info = body["messageRead"] or {}
                peer = info.get("peer") or {}
                self.push("read", {"peer": f"{'u' if int(peer.get('type', 0)) == 1 else 'g'}:"
                                           f"{peer.get('id')}", "date": int(info.get("date", 0) or 0)})
        except Exception:  # noqa: BLE001
            traceback.print_exc()


# --------------------------------------------------------------------------- http
class Handler(BaseHTTPRequestHandler):
    app: WebApp = None            # type: ignore
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:   # quieter server
        if os.environ.get("BALE_WEB_LOG"):
            super().log_message(fmt, *args)

    # -- helpers -----------------------------------------------------------
    def _json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _bytes(self, data: bytes, ctype: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()
        self.wfile.write(data)

    def _file(self, path: str) -> None:
        try:
            with open(path, "rb") as fh:
                body = fh.read()
        except OSError:
            self._json({"error": "not found"}, 404)
            return
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if path.endswith(".html"):
            ctype = "text/html; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw or b"{}")
        except Exception:  # noqa: BLE001
            return {}

    # -- routes ------------------------------------------------------------
    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        route = parsed.path
        query = parse_qs(parsed.query)
        app = self.app

        if route in ("/", "/index.html"):
            return self._file(os.path.join(STATIC_DIR, "index.html"))
        if route.startswith("/static/"):
            name = os.path.normpath(route[len("/static/"):]).lstrip("\\/")
            return self._file(os.path.join(STATIC_DIR, name))

        try:
            if route == "/api/status":
                return self._json({
                    "loggedIn": bool(app.client.token or app.client.state.get("token")),
                    "connected": app.connected, "demo": app.demo,
                    "me": app.client.me,
                    "session": app.client.session_file,
                })
            if route == "/api/dialogs":
                return self._json(app.call(app._dialogs()))
            if route == "/api/history":
                peer = (query.get("peer") or ["u:0"])[0]
                limit = int((query.get("limit") or ["40"])[0])
                date = query.get("date")
                return self._json(app.call(app._history(
                    peer, limit, int(date[0]) if date else None)))
            if route == "/favicon.ico":
                return self._bytes(b"", "image/x-icon")
            if route == "/api/avatar":
                peer_key = (query.get("peer") or ["u:0"])[0]
                if app.demo:
                    return self._json({"error": "demo"}, 404)
                data = app.call(app._avatar(peer_key), timeout=30)
                if not data:
                    return self._json({"error": "no avatar"}, 404)
                return self._bytes(data, "image/jpeg")
            if route == "/api/media":
                file_id = int((query.get("file") or ["0"])[0])
                access_hash = int((query.get("hash") or ["0"])[0])
                if app.demo:
                    blob = app.demo_backend.media_blob(file_id)
                    if not blob:
                        return self._json({"error": "no such demo file"}, 404)
                    return self._bytes(blob[0], blob[1])
                data = app.call(app._media(file_id, access_hash), timeout=90)
                if data is None:
                    return self._json({"error": "download failed"}, 404)
                ctype = (query.get("mime") or ["application/octet-stream"])[0]
                return self._bytes(data, ctype)
            if route == "/api/profile":
                peer_key = (query.get("peer") or ["u:0"])[0]
                return self._json(app.call(app._profile(peer_key), timeout=45))
            if route == "/api/search":
                needle = (query.get("q") or [""])[0]
                peer_key = (query.get("peer") or [""])[0]
                if not needle.strip():
                    return self._json({"results": []})
                return self._json(app.call(app._search(needle, peer_key), timeout=60))
            if route == "/api/members":
                peer_key = (query.get("peer") or ["u:0"])[0]
                return self._json(app.call(app._members(peer_key)))
            if route == "/api/poll":
                since = int((query.get("since") or ["0"])[0])
                return self._json(app.poll(since))
        except BaleRpcError as exc:
            return self._json({"error": str(exc), "topic": exc.topic}, 400)
        except TransportError as exc:
            return self._json({"error": str(exc)}, 503)
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)

        self._json({"error": "not found"}, 404)

    def do_POST(self) -> None:  # noqa: N802
        route = urlparse(self.path).path
        app = self.app
        data = self._body()
        try:
            if route == "/api/login/start":
                return self._json(app.call(app._do_login_start(str(data.get("phone", "")))))
            if route == "/api/login/code":
                return self._json(app.call(app._do_login_code(str(data.get("code", "")))))
            if route == "/api/login/password":
                return self._json(app.call(app._do_login_password(str(data.get("password", "")))))
            if route == "/api/login/signup":
                return self._json(app.call(app._do_signup(str(data.get("name", "")))))
            if route == "/api/send":
                return self._json(app.call(app._send(
                    str(data.get("peer")), str(data.get("text", "")),
                    data.get("reply"))))
            if route == "/api/send_media":
                return self._json(app.call(app._send_media(
                    str(data.get("peer")), str(data.get("name", "file")),
                    str(data.get("mime", "application/octet-stream")),
                    str(data.get("data", "")), str(data.get("caption", "")))))
            if route == "/api/delete":
                return self._json(app.call(app._delete(
                    str(data.get("peer")), [int(d) for d in data.get("dates", [])])))
            if route == "/api/edit":
                return self._json(app.call(app._edit(
                    str(data.get("peer")), int(data.get("rid", 0)), str(data.get("text", "")))))
            if route == "/api/forward":
                return self._json(app.call(app._forward(
                    str(data.get("from")), str(data.get("to")),
                    data.get("messages", []))))
            if route == "/api/typing":
                return self._json(app.call(app._typing(str(data.get("peer")))))
            if route == "/api/react":
                return self._json(app.call(app._react(
                    str(data.get("peer")), int(data.get("rid", 0)),
                    int(data.get("date", 0)), str(data.get("code", "")),
                    bool(data.get("remove")))))
            if route == "/api/read":
                return self._json(app.call(app._read(str(data.get("peer")),
                                                      int(data.get("date", 0)))))
        except BaleRpcError as exc:
            return self._json({"error": exc.message, "topic": exc.topic}, 400)
        except TransportError as exc:
            return self._json({"error": str(exc)}, 503)
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)
        self._json({"error": "not found"}, 404)


# --------------------------------------------------------------------------- entry
def serve(host: str = "127.0.0.1", port: int = 8765, demo: bool = False,
          session: Optional[str] = None, open_browser: bool = True) -> None:
    client = BaleClient(session_path=session or None)
    app = WebApp(client, demo=demo)
    app.start()
    if demo:
        app.connected = True

    Handler.app = app
    httpd = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{'127.0.0.1' if host in ('0.0.0.0', '') else host}:{port}/"
    print(f"Bale client UI   ->  {url}")
    print("   demo mode - no account needed" if demo else "   press ctrl-c to stop")
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")
    finally:
        httpd.server_close()
