"""
baleclient.client - a from scratch Python client for the Bale messenger.

    from baleclient import BaleClient

    async with BaleClient() as bale:
        await bale.login("98912...")     # phone number, then SMS code
        for chat in await bale.load_dialogs():
            print(chat.title, chat.unread)
        await bale.send_text(Peer.user(chat.peer_id), "hello from my client")

Everything is built on the schemas recovered in ``schema.json``.
"""
from __future__ import annotations

import asyncio
import getpass
import json
import os
import random
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from .proto import Codec, default_codec
from .transport import (API_KEY, APP_ID, DEFAULT_HOST, BaleRpcError, Transport,
                        TransportError)

SVC_AUTH = "bale.auth.v1.Auth"
SVC_MSG = "bale.messaging.v2.Messaging"
SVC_USERS = "bale.users.v1.Users"
SVC_CONFIGS = "bale.v1.Configs"
SVC_FILES = "ai.bale.server.Files"
SVC_ABACUS = "bale.abacus.v1.Abacus"
SVC_SEARCH = "bale.search.v1.Search"
SVC_PRESENCE = "bale.presence.v1.Presence"
SVC_GROUPS = "bale.groups.v1.Groups"

# SendType (bale.messaging.v2): 1 photo, 2 video, 3 voice, 4 gif, 5 audio,
# 6 document, 7 sticker, 8 crowdfunding
SEND_PHOTO, SEND_VIDEO, SEND_VOICE, SEND_GIF, SEND_AUDIO, SEND_DOCUMENT, SEND_STICKER = 1, 2, 3, 4, 5, 6, 7

# TypingType
TYPING_TEXT, TYPING_VOICE, TYPING_PHOTO, TYPING_VIDEO = 1, 2, 3, 4

# services map (from the recovered schema)
DEFAULT_SESSION = os.path.expanduser("~/.bale-client/session.json")


# --------------------------------------------------------------------------- helpers
def unwrap(value: Any) -> Any:
    """google.protobuf.*Value -> plain python value."""
    if isinstance(value, dict) and set(value) <= {"value", "_unknown"}:
        return value.get("value")
    return value


def peer_dict(peer: Any) -> Dict[str, int]:
    if isinstance(peer, Peer):
        return peer.to_dict()
    if isinstance(peer, dict):
        return {k: int(v) for k, v in peer.items() if k in ("type", "id", "accessHash") and v}
    return {"type": 1, "id": int(peer)}


@dataclass
class Peer:
    id: int
    type: int = 1               # 1 = user, 2 = group / channel
    access_hash: int = 0

    @classmethod
    def user(cls, uid: int, access_hash: int = 0) -> "Peer":
        return cls(int(uid), 1, int(access_hash))

    @classmethod
    def group(cls, gid: int, access_hash: int = 0) -> "Peer":
        return cls(int(gid), 2, int(access_hash))

    @classmethod
    def parse(cls, text: str) -> "Peer":
        """'u:123', 'g:456' or a bare number (user)."""
        text = str(text).strip()
        if text[:2] in ("u:", "U:"):
            return cls(int(text[2:]), 1)
        if text[:2] in ("g:", "G:"):
            return cls(int(text[2:]), 2)
        return cls(int(text), 1)

    def to_dict(self) -> Dict[str, int]:
        data = {"type": self.type, "id": self.id}
        if self.access_hash:
            data["accessHash"] = self.access_hash
        return data

    @property
    def key(self) -> str:
        return f"{'g' if self.type == 2 else 'u'}:{self.id}"

    def __str__(self) -> str:
        return self.key


def _content_kind(union: Any) -> str:
    if not isinstance(union, dict):
        return "unknown"
    for key in ("textMessage", "longTextMessage", "serviceMessage"):
        if isinstance(union.get(key), dict):
            return "text" if key != "serviceMessage" else "service"
    for key, value in union.items():
        if isinstance(value, dict) and key != "_unknown":
            return key.replace("Message", "").lower() or "unknown"
    return "empty"


def _content_text(union: Any) -> str:
    """Readable text out of a Message2 / UpdateBody message content union."""
    if not isinstance(union, dict):
        return ""
    inner = union.get("message") if isinstance(union.get("message"), dict) else union
    for key in ("textMessage", "longTextMessage", "serviceMessage"):
        value = inner.get(key)
        if isinstance(value, dict):
            text = value.get("text", "")
            if text:
                return text
    template = inner.get("templateMessage")
    if isinstance(template, dict):
        for key in ("text", "caption", "title"):
            if isinstance(template.get(key), str) and template[key]:
                return template[key]
        if isinstance(template.get("template"), dict):
            inner_tpl = template["template"]
            for key in ("text", "caption", "title"):
                if isinstance(inner_tpl.get(key), str) and inner_tpl[key]:
                    return inner_tpl[key]
    document = inner.get("documentMessage")
    if isinstance(document, dict):
        name = unwrap(document.get("name")) or unwrap(document.get("fileName"))
        if isinstance(name, bytes):
            name = name.decode("utf-8", "replace")
        if name:
            return f"[file] {name}"
    for key, value in inner.items():
        if isinstance(value, dict) and key not in ("_unknown",):
            return f"<{key.replace('Message', '').lower()}>"
    return ""


@dataclass
class Chat:
    peer: Peer
    title: str = ""
    unread: int = 0
    date: int = 0
    last_text: str = ""
    is_group: bool = False


@dataclass
class Message:
    peer: Peer
    sender_uid: int = 0
    date: int = 0
    rid: int = 0
    text: str = ""
    kind: str = "text"
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def time(self) -> str:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.date / 1000))


# --------------------------------------------------------------------------- client
class BaleClient:
    def __init__(self, host: str = DEFAULT_HOST, proxy: Optional[str] = None,
                 session_path: Optional[str] = DEFAULT_SESSION,
                 debug: bool = False, device_title: str = "Chrome_135.0.0.0, Windows"):
        self.codec: Codec = default_codec()
        self.session_path = session_path
        self.debug = debug
        self.device_title = device_title
        self.transport = Transport(host=host, proxy=proxy, codec=self.codec, debug=debug)
        self.token: Optional[str] = None
        self.me: Optional[Dict[str, Any]] = None
        self.state: Dict[str, Any] = self._load_session() or {}
        self.users: Dict[int, Dict[str, Any]] = {}     # id -> Users message
        self.groups: Dict[int, Dict[str, Any]] = {}    # id -> Groups2 message
        self.peers: Dict[str, "Peer"] = {}             # "u:1" -> Peer (with access hash)
        self._update_handler: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None

    # -- lifecycle ---------------------------------------------------------
    async def __aenter__(self) -> "BaleClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def close(self) -> None:
        await self.transport.close()

    # -- session -----------------------------------------------------------
    def _load_session(self) -> Optional[Dict[str, Any]]:
        if not self.session_path or not os.path.exists(self.session_path):
            return None
        try:
            with open(self.session_path, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return None

    @property
    def session_file(self) -> str:
        return os.path.expanduser(self.session_path or DEFAULT_SESSION)

    def save_session(self) -> Optional[str]:
        if not self.session_path:
            return None
        data = {
            "token": self.token,
            "me": self.me,
            "device_hash": self.state.get("device_hash"),
            "host": self.transport.host,
        }
        path = os.path.expanduser(self.session_path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return path

    @property
    def device_hash(self) -> str:
        dh = self.state.get("device_hash")
        if not dh:
            dh = str(uuid.uuid4())
            self.state["device_hash"] = dh
        return dh

    # =====================================================================
    #  authentication
    # =====================================================================
    async def start_phone_auth(self, phone_number: str, send_code_type: int = 1) -> Dict[str, Any]:
        """Ask Bale to send a login code.  ``phone_number`` is E.164 without '+'."""
        number = int(str(phone_number).replace("+", "").replace(" ", "").replace("-", ""))
        request = {
            "phoneNumber": number,
            "appId": APP_ID,
            "apiKey": API_KEY,
            "deviceHash": self.device_hash.encode(),
            "deviceTitle": self.device_title,
            "sendCodeType": send_code_type,
            "options": [],
        }
        payload = self.codec.encode("Auth_StartPhoneAuth_Request", request)
        raw = await self.transport.post(SVC_AUTH, "StartPhoneAuth", payload)
        resp = self.codec.decode("Auth_StartPhoneAuth_Response", raw)
        if self.debug:
            print("[auth] StartPhoneAuth ->", resp)
        return resp

    async def validate_code(self, transaction_hash: str, code: str) -> Dict[str, Any]:
        request = {
            "transactionHash": transaction_hash,
            "code": str(code),
            "isJwt": {"value": True},
        }
        payload = self.codec.encode("Auth_ValidateCode_Request", request)
        raw = await self.transport.post(SVC_AUTH, "ValidateCode", payload)
        resp = self.codec.decode("Msg_index_fe3fa18088__86923_A", raw)
        return self._finish_login(resp)

    async def validate_password(self, transaction_hash: str, password: str) -> Dict[str, Any]:
        request = {
            "transactionHash": transaction_hash,
            "password": password,
            "isJwt": {"value": True},
        }
        payload = self.codec.encode("Auth_ValidatePassword_Request", request)
        raw = await self.transport.post(SVC_AUTH, "ValidatePassword", payload)
        resp = self.codec.decode("Msg_index_fe3fa18088__86923_A", raw)
        return self._finish_login(resp)

    async def sign_up(self, transaction_hash: str, name: str) -> Dict[str, Any]:
        request = {"transactionHash": transaction_hash, "name": name}
        payload = self.codec.encode("Auth_SignUp_Request", request)
        raw = await self.transport.post(SVC_AUTH, "SignUp", payload)
        resp = self.codec.decode("Msg_index_fe3fa18088__86923_A", raw)
        return self._finish_login(resp)

    def _finish_login(self, resp: Dict[str, Any]) -> Dict[str, Any]:
        token = unwrap(resp.get("jwt"))
        if isinstance(token, bytes):
            token = token.decode()
        if token:
            self.token = token
        user = resp.get("user") or {}
        if user:
            self.me = {
                "id": user.get("id"),
                "name": user.get("name"),
                "accessHash": user.get("accessHash"),
            }
        self.save_session()
        return {"token": self.token, "user": self.me, "config": resp.get("config")}

    async def login(self, phone_number: Optional[str] = None,
                    ask_code: Callable[[], str] = None,
                    ask_password: Callable[[], str] = None,
                    force: bool = False) -> Dict[str, Any]:
        """Full interactive login (uses the saved session when possible)."""
        if force:
            self.token = None
            self.state.pop("token", None)
        if self.token is None and self.state.get("token"):
            self.token = self.state["token"]
            self.me = self.state.get("me")
            return {"token": self.token, "user": self.me, "cached": True}

        ask_code = ask_code or (lambda: input("SMS code: ").strip())
        ask_password = ask_password or (lambda: getpass.getpass("2FA password: "))

        if not phone_number:
            phone_number = input("Phone number (e.g. 989121234567): ").strip()

        started = await self.start_phone_auth(phone_number)
        tx = started.get("transactionHash", "")
        print(f"code sent via type={started.get('sentCodeType')} "
              f"expires={unwrap(started.get('codeExpirationDate'))}")

        if started.get("activationType") == 1:  # password protected account
            return await self.validate_password(tx, ask_password())

        code = ask_code()
        try:
            return await self.validate_code(tx, code)
        except BaleRpcError as exc:
            if "password" in exc.message.lower():
                return await self.validate_password(tx, ask_password())
            if "UNOCCUPIED" in exc.message or "unoccupied" in exc.message.lower():
                name = input("New account - your display name: ").strip()
                return await self.sign_up(tx, name)
            raise

    # -- connection --------------------------------------------------------
    async def connect(self, token: Optional[str] = None) -> Dict[str, Any]:
        token = token or self.token or self.state.get("token")
        if not token:
            where = os.path.expanduser(self.session_path or DEFAULT_SESSION)
            raise TransportError(
                f"not logged in - no token in {where}\n"
                "  run:  python run.py login --force")
        self.token = token
        await self.transport.connect(token)
        hs = self.transport.handshake_result or {}
        if self.debug:
            print("[ws] handshake:", hs)
        return hs

    async def ensure_connected(self) -> None:
        if self.transport.ws is None:
            await self.connect()

    # =====================================================================
    #  RPC helpers
    # =====================================================================
    async def rpc(self, service: str, method: str, request: Dict[str, Any],
                  request_type: str, response_type: Optional[str],
                  timeout: float = 20.0) -> Dict[str, Any]:
        await self.ensure_connected()
        payload = self.codec.encode(request_type, request)
        if self.debug:
            print(f"[rpc] {method} -> {len(payload)} bytes: {payload.hex()[:160]}")
        raw = await self.transport.call(service, method, payload, timeout=timeout)
        if not response_type or not raw:
            return {}
        if self.debug:
            print(f"[rpc] {method} <- {len(raw)} bytes: {raw.hex()[:160]}")
        decoded = self.codec.decode(response_type, raw)
        if self.debug:
            print(f"[rpc] {method} decoded: {str(decoded)[:600]}")
        return decoded

    # =====================================================================
    #  messaging api
    # =====================================================================
    async def get_full_user(self, peer: Peer) -> Dict[str, Any]:
        req = {"peer": {"uid": peer.id, "accessHash": peer.access_hash}}
        resp = await self.rpc(SVC_USERS, "GetFullUser", req,
                              "Users_GetFullUser_Request", "Users_GetFullUser_Response")
        return resp.get("fullUser", {})

    async def load_dialogs(self, limit: int = 60) -> List[Chat]:
        # Mirrors core/dialogs.loadDialogs() in the official web client:
        #   minDate must be -1 for the first page (0 or >0 means "paginate
        #   older than this date"), optimizations is the incremental-sync
        #   state blob (empty on a cold start), archiveFilter 0 = ALL.
        req = {
            "minDate": -1,
            "dialogType": 0,          # 0 = every folder
            "limit": limit,
            "optimizations": [],
            "excludePinnedDialogs": False,
            "archiveFilter": 0,       # ARCHIVEFILTER_ALL
        }
        resp = await self.rpc(SVC_MSG, "LoadDialogs", req,
                              "Messaging_LoadDialogs_Request",
                              "Messaging_LoadDialogs_Response")
        users = {u.get("id"): u for u in resp.get("users", [])}
        groups = {g.get("id"): g for g in resp.get("groups", [])}

        # Access hashes are delivered separately from the dialogs themselves.
        hashes: Dict[str, int] = {}
        for up in resp.get("userPeers", []) or []:
            hashes[f"u:{up.get('uid')}"] = int(up.get("accessHash") or 0)
        for gp in resp.get("groupPeers", []) or []:
            hashes[f"g:{gp.get('groupId')}"] = int(gp.get("accessHash") or 0)

        # The dialog list only carries peer ids; the web client resolves names
        # with Users/LoadUsers and Groups/LoadGroups.
        missing_users = {int((d.get("peer") or {}).get("id", 0)) for d in resp.get("dialogs", [])
                         if int((d.get("peer") or {}).get("type", 0)) == 1} - set(users)
        missing_groups = {int((d.get("peer") or {}).get("id", 0)) for d in resp.get("dialogs", [])
                          if int((d.get("peer") or {}).get("type", 0)) == 2} - set(groups)
        if missing_users:
            try:
                users.update(await self.load_users(sorted(missing_users)[:100]))
            except BaleRpcError as exc:
                if self.debug:
                    print("[dialogs] LoadUsers failed:", exc)
        if missing_groups:
            try:
                groups.update(await self.load_groups(sorted(missing_groups)[:100]))
            except BaleRpcError as exc:
                if self.debug:
                    print("[dialogs] LoadGroups failed:", exc)

        chats: List[Chat] = []
        for d in resp.get("dialogs", []):
            p = d.get("peer") or {}
            kind = int(p.get("type", 0))
            pid = int(p.get("id", 0))
            if kind == 1:
                title = (users.get(pid) or {}).get("name") or str(pid)
            else:
                title = (groups.get(pid) or {}).get("title") or str(pid)
            text = _content_text(d.get("message"))
            chats.append(Chat(peer=Peer(pid, kind, hashes.get(f"{'g' if kind == 2 else 'u'}:{pid}", 0)),
                              title=title,
                              unread=int(d.get("unreadCount", 0)),
                              date=int(d.get("sortDate") or d.get("date") or 0),
                              last_text=text,
                              is_group=(kind == 2)))
        return chats

    async def load_history(self, peer: Peer, limit: int = 20,
                           date: int = -1, load_mode: int = 2) -> List[Message]:
        """Load a page of a conversation.

        Mirrors ``MessagesModule.openHistory`` in the web client:
          * first page            -> date = -1, load_mode = BACKWARD (2)
          * chat with unread msgs -> date = firstUnreadDate, load_mode = BOTH (3)
          * older page            -> date = date of the oldest loaded message
        """
        req = {"peer": peer.to_dict(), "date": date, "loadMode": load_mode,
               "limit": limit, "optimizations": []}
        resp = await self.rpc(SVC_MSG, "LoadHistory", req,
                              "Messaging_LoadHistory_Request",
                              "Messaging_LoadHistory_Response")
        # the response carries the peers a client needs to resolve senders
        for up in resp.get("userPeers", []) or []:
            uid = int(up.get("uid", 0) or 0)
            self.peers.setdefault(f"u:{uid}", Peer(uid, 1, int(up.get("accessHash") or 0)))
            if uid == peer.id and peer.type == 1:
                peer.access_hash = int(up.get("accessHash") or peer.access_hash)
        for gp in resp.get("groupPeers", []) or []:
            gid = int(gp.get("groupId", 0) or 0)
            self.peers.setdefault(f"g:{gid}", Peer(gid, 2, int(gp.get("accessHash") or 0)))
            if gid == peer.id and peer.type == 2:
                peer.access_hash = int(gp.get("accessHash") or peer.access_hash)
        for user in resp.get("users", []) or []:
            self.users[int(user.get("id", 0) or 0)] = user
        for group in resp.get("groups", []) or []:
            self.groups[int(group.get("id", 0) or 0)] = group

        out: List[Message] = []
        for h in resp.get("history", []):
            content = h.get("message") or {}
            out.append(Message(peer=peer,
                               sender_uid=int(h.get("senderUid", 0)),
                               date=int(h.get("date", 0)),
                               rid=int(h.get("rid", 0)),
                               text=_content_text(content),
                               kind=_content_kind(content),
                               raw=h))
        out.sort(key=lambda m: m.date)
        return out

    # -- name resolution ---------------------------------------------------
    async def load_users(self, uids: List[int]) -> Dict[int, Dict[str, Any]]:
        """Users/LoadUsers - the call the web client uses to fill its user cache."""
        peers = []
        for uid in uids:
            known = self.peers.get(f"u:{uid}")
            peers.append({"uid": uid, "accessHash": known.access_hash if known else 0})
        if not peers:
            return {}
        resp = await self.rpc(SVC_USERS, "LoadUsers", {"peers": peers},
                              "Users_LoadUsers_Request", "Users_LoadUsers_Response")
        found = {}
        for user in resp.get("users", []) or []:
            uid = int(user.get("id", 0) or 0)
            self.users[uid] = user
            found[uid] = user
        return found

    async def load_groups(self, gids: List[int]) -> Dict[int, Dict[str, Any]]:
        peers = []
        for gid in gids:
            known = self.peers.get(f"g:{gid}")
            if known and known.access_hash:
                peers.append({"groupId": gid, "accessHash": known.access_hash})
        if not peers:
            return {}
        resp = await self.rpc("bale.groups.v1.Groups", "LoadGroups", {"peers": peers},
                              "Groups_LoadGroups_Request", "Groups_LoadGroups_Response")
        found = {}
        for group in resp.get("groups", []) or []:
            gid = int(group.get("id", 0) or 0)
            self.groups[gid] = group
            found[gid] = group
        return found

    def display_name(self, peer_type: int, peer_id: int) -> str:
        if peer_type == 2:
            group = self.groups.get(peer_id) or {}
            return group.get("title") or f"group {peer_id}"
        user = self.users.get(peer_id) or {}
        return (user.get("name") or user.get("nick")
                or f"user {peer_id}")


    # -- token helpers -----------------------------------------------------
    def jwt_expiry(self) -> Optional[int]:
        """Unix expiry of the current JWT (seconds), or None."""
        import base64
        token = self.token or self.state.get("token")
        if not token:
            return None
        try:
            payload = token.split(".")[1]
            payload += "=" * (-len(payload) % 4)
            data = json.loads(base64.urlsafe_b64decode(payload))
            return int(data.get("exp") or 0) or None
        except Exception:
            return None

    async def refresh_jwt(self) -> Optional[str]:
        """Ask Auth/GetJWTToken for a fresh token while connected."""
        resp = await self.rpc(SVC_AUTH, "GetJWTToken", {},
                              "Auth_GetJWTToken_Request",
                              "Auth_GetJWTToken_Response")
        token = unwrap(resp.get("jwt"))
        if isinstance(token, bytes):
            token = token.decode()
        if token:
            self.token = token
            self.save_session()
        return token

    async def message_read(self, peer: Peer, date: int) -> None:
        req = {"peer": peer.to_dict(), "date": int(date)}
        await self.rpc(SVC_MSG, "MessageRead", req,
                       "Messaging_MessageRead_Request",
                       "Msg_index_fe3fa18088__83329_u")

    # =====================================================================
    #  media
    # =====================================================================
    async def get_file_url(self, file_id: int, access_hash: int,
                           storage_version: Optional[int] = None) -> Optional[str]:
        """Files/GetNasimFileUrl -> a temporary download URL."""
        location = {"fileId": int(file_id), "accessHash": int(access_hash)}
        if storage_version:
            location["fileStorageVersion"] = {"value": int(storage_version)}
        resp = await self.rpc(SVC_FILES, "GetNasimFileUrl",
                              {"file": location, "ciphertext": False},
                              "Files_GetNasimFileUrl_Request",
                              "Files_GetNasimFileUrl_Response")
        file_url = resp.get("fileUrl") or {}
        return file_url.get("url") or unwrap(file_url.get("unsignedUrl"))

    async def download_file(self, file_id: int, access_hash: int,
                            storage_version: Optional[int] = None) -> bytes:
        url = await self.get_file_url(file_id, access_hash, storage_version)
        if not url:
            raise TransportError("no download url for this file")
        return await self.transport.fetch(url)

    async def upload_file(self, data: bytes, name: str, mime: str,
                          peer: Optional[Peer] = None,
                          send_type: Optional[int] = None) -> int:
        """Files/GetNasimFileUploadUrl + PUT.  Returns the new fileId."""
        ex_peer = None
        if peer is not None:
            ex_peer = peer.to_dict()          # ExPeer { type, id, accessHash }
        # NB: the official web client leaves crc empty and sends chunkSize /
        # compressedSize / fileKind as 0 - see modulesBuilder.getUploadUrl().
        req = {
            "expectedSize": len(data),
            "uid": int((self.me or {}).get("id") or 0),
            "name": name,
            "mimeType": mime,
            "chunkSize": 0,
            "compressedSize": 0,
            "fileKind": 0,
        }
        if ex_peer:
            req["exPeer"] = ex_peer
        if send_type:
            req["sendType"] = {"type": int(send_type)}
        resp = await self.rpc(SVC_FILES, "GetNasimFileUploadUrl", req,
                              "Files_GetNasimFileUploadUrl_Request",
                              "Files_GetNasimFileUploadUrl_Response")
        url = resp.get("url")
        file_id = int(resp.get("fileId") or 0)
        if not url or not file_id:
            raise TransportError("server did not return an upload url")
        chunk = int(resp.get("chunkSize") or 0)
        if chunk > 0 and len(data) > chunk:
            # The server asked for chunked upload: PUT every chunk with the
            # ``chunk``/``no`` headers, then confirm with an empty PUT.
            total = (len(data) + chunk - 1) // chunk
            for index in range(total):
                blob = data[index * chunk:(index + 1) * chunk]
                await self.transport.put(url, blob, mime,
                                         {"chunk": str(index), "no": str(total)})
            await self.transport.put(url, b"", mime,
                                     {"chunk": str(total), "no": str(total)})
        else:
            await self.transport.put(url, data, mime)
        if self.debug:
            print(f"[upload] {name} ({len(data)} bytes) -> fileId {file_id}")
        return file_id

    async def send_media(self, peer: Peer, path_or_bytes: Any,
                         caption: str = "", name: Optional[str] = None,
                         mime: Optional[str] = None,
                         send_type: Optional[int] = None) -> Dict[str, Any]:
        """Upload a file and send it as a document/photo message."""
        import mimetypes
        import os
        if isinstance(path_or_bytes, (bytes, bytearray)):
            data = bytes(path_or_bytes)
            name = name or "file.bin"
        else:
            data = open(path_or_bytes, "rb").read()
            name = name or os.path.basename(path_or_bytes)
        mime = mime or mimetypes.guess_type(name)[0] or "application/octet-stream"
        if send_type is None:
            send_type = SEND_PHOTO if mime.startswith("image/") else SEND_DOCUMENT

        file_id = await self.upload_file(data, name, mime, peer, send_type)
        document = {
            "fileId": file_id,
            "fileSize": len(data),
            "name": name,
            "mimeType": mime,
        }
        if caption:
            document["caption"] = {"text": caption}
        if send_type == SEND_PHOTO:
            document["ext"] = {"documentExPhoto": {"w": 0, "h": 0}}
        req = {
            "peer": peer.to_dict(),
            "rid": random.getrandbits(62),
            "message": {"documentMessage": document},
        }
        return await self.rpc(SVC_MSG, "SendMessage", req,
                              "Messaging_SendMessage_Request",
                              "Msg_index_fe3fa18088__83329_h")

    def avatar_url_parts(self, peer_type: int, peer_id: int) -> Optional[Tuple[int, int]]:
        """(fileId, accessHash) of the small avatar, from the cached profile."""
        source = self.groups.get(peer_id) if peer_type == 2 else self.users.get(peer_id)
        avatar = (source or {}).get("avatar") or {}
        image = avatar.get("smallImage") or avatar.get("largeImage") or {}
        location = image.get("fileLocation") or {}
        if not location.get("fileId"):
            return None
        return int(location.get("fileId", 0)), int(location.get("accessHash", 0) or 0)

    # =====================================================================
    #  message actions
    # =====================================================================
    async def send_text(self, peer: Peer, text: str, is_silent: bool = False,
                        reply_to: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        req = {
            "peer": peer.to_dict(),
            "rid": random.getrandbits(62),
            "message": {"textMessage": {"text": text}},
            "isSilent": is_silent,
        }
        if reply_to:
            # QuotedMessageReference { peer, rid, date, seq }
            req["quotedMessageReference"] = reply_to
        return await self.rpc(SVC_MSG, "SendMessage", req,
                              "Messaging_SendMessage_Request",
                              "Msg_index_fe3fa18088__83329_h")

    async def delete_messages(self, peer: Peer, dates: List[int],
                              just_mine: bool = True) -> None:
        """Messaging/DeleteMessage - dates are the message `date` fields."""
        req = {"peer": peer.to_dict(), "dates": {"dates": [int(d) for d in dates]},
               "justMine": {"value": bool(just_mine)}}
        await self.rpc(SVC_MSG, "DeleteMessage", req,
                       "Messaging_DeleteMessage_Request",
                       "Msg_index_fe3fa18088__83329_f")

    async def edit_message(self, peer: Peer, rid: int, text: str,
                           date: int = 0) -> Dict[str, Any]:
        req = {
            "peer": peer.to_dict(),
            "rid": int(rid),
            "updatedMessage": {"textMessage": {"text": text}},
        }
        return await self.rpc(SVC_MSG, "UpdateMessage", req,
                              "Messaging_UpdateMessage_Request",
                              "Msg_index_fe3fa18088__83329_h")

    async def forward_messages(self, to_peer: Peer, from_peer: Peer,
                               messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        refs = []
        for msg in messages:
            refs.append({
                "peer": from_peer.to_dict(),
                "rid": int(msg.get("rid", 0) or 0),
                "date": int(msg.get("date", 0) or 0),
                "seq": int((msg.get("previousMessageId") or {}).get("seq", 0) or 0),
            })
        req = {"peer": to_peer.to_dict(), "forwardedMessages": refs}
        return await self.rpc(SVC_MSG, "ForwardMessages", req,
                              "Messaging_ForwardMessages_Request",
                              "Msg_index_fe3fa18088__83329_h")

    # =====================================================================
    #  reactions + search
    # =====================================================================
    async def set_reaction(self, peer: Peer, rid: int, code: str, date: int = 0) -> None:
        await self.rpc(SVC_ABACUS, "MessageSetReaction",
                       {"peer": peer.to_dict(), "rid": int(rid), "code": code,
                        "date": int(date)}, "Abacus_MessageSetReaction_Request", None)

    async def remove_reaction(self, peer: Peer, rid: int, code: str, date: int = 0) -> None:
        await self.rpc(SVC_ABACUS, "MessageRemoveReaction",
                       {"peer": peer.to_dict(), "rid": int(rid), "code": code,
                        "date": int(date)}, "Abacus_MessageRemoveReaction_Request", None)

    async def get_reactions(self, peer: Peer, ids: List[Dict[str, Any]]) -> Dict[str, Any]:
        """GetMessagesReactions takes two MessageIds per call; returns rid -> reactions."""
        out: Dict[str, Any] = {}
        pairs = [ids[i:i + 2] for i in range(0, len(ids), 2)]
        for pair in pairs:
            req: Dict[str, Any] = {"peer": peer.to_dict()}
            if len(pair) > 0:
                req["field_18"] = {"rid": int(pair[0].get("rid", 0)),
                                   "date": int(pair[0].get("date", 0))}
            if len(pair) > 1:
                req["field_34"] = {"rid": int(pair[1].get("rid", 0)),
                                   "date": int(pair[1].get("date", 0))}
            try:
                resp = await self.rpc(SVC_ABACUS, "GetMessagesReactions", req,
                                      "Abacus_GetMessagesReactions_Request",
                                      "Abacus_GetMessagesReactions_Response")
            except Exception:  # noqa: BLE001
                continue
            for container in resp.get("containers", []) or []:
                key = f"{int(container.get('rid', 0))}:{int(container.get('date', 0))}"
                out[key] = container.get("reactions", []) or []
        return out

    async def search_messages(self, query: str, peer: Optional[Peer] = None,
                              limit: int = 30) -> Dict[str, Any]:
        """Search/SearchMessages - the query is a nested Query2 condition tree."""
        text = {"searchPieceText": {"query": query}}
        if peer is not None:
            cond = {"searchAndCondition": {"andQuery": [
                text, {"searchPeerCondition": {"peer": peer.to_dict()}}]}}
        else:
            cond = text
        resp = await self.rpc(SVC_SEARCH, "SearchMessages",
                              {"query": cond, "optimizations": []},
                              "Search_SearchMessages_Request",
                              "Msg_modulesBuilder_e7b98d256c__62663_sr")
        results = []
        for item in resp.get("searchResults", []) or []:
            res = (item or {}).get("result") or {}
            entry = res.get("messageContainer") or {}
            content = res.get("content") or entry.get("message") or {}
            results.append({
                "peer": res.get("peer") or {},
                "rid": int(res.get("rid") or entry.get("rid") or 0),
                "date": int(res.get("date") or entry.get("date") or 0),
                "sender": int(res.get("senderId") or entry.get("senderUid") or 0),
                "content": content,
                "raw": entry,
            })
            if len(results) >= limit:
                break
        users = resp.get("users", []) or []
        groups = resp.get("groups", []) or []
        return {"results": results, "users": users, "groups": groups}

    # =====================================================================
    #  presence
    # =====================================================================
    async def send_typing(self, peer: Peer, typing_type: int = TYPING_TEXT) -> None:
        await self.rpc(SVC_PRESENCE, "Typing",
                       {"peer": peer.to_dict(), "typingType": int(typing_type)},
                       "Presence_Typing_Request", None)

    async def stop_typing(self, peer: Peer, typing_type: int = TYPING_TEXT) -> None:
        await self.rpc(SVC_PRESENCE, "StopTyping",
                       {"peer": peer.to_dict(), "typingType": int(typing_type)},
                       "Presence_StopTyping_Request", None)

    async def set_online(self) -> None:
        try:
            await self.rpc(SVC_PRESENCE, "SetOnline", {},
                           "Presence_SetOnline_Request", None)
        except BaleRpcError:
            pass

    # =====================================================================
    #  groups
    # =====================================================================
    async def load_group_members(self, gid: int, limit: int = 100) -> List[Dict[str, Any]]:
        """Groups/LoadMembers - returns member records with uids."""
        access_hash = 0
        known = self.peers.get(f"g:{gid}")
        if known:
            access_hash = known.access_hash
        else:
            access_hash = int((self.groups.get(gid) or {}).get("accessHash") or 0)
        req = {"group": {"groupId": int(gid), "accessHash": int(access_hash)},
               "limit": int(limit)}
        resp = await self.rpc(SVC_GROUPS, "LoadMembers", req,
                              "Groups_LoadMembers_Request",
                              "Groups_LoadMembers_Response")
        return resp.get("members", []) or []

    # =====================================================================
    #  updates
    # =====================================================================
    def on_update(self, handler: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
        self._update_handler = handler

    async def _dispatch_update(self, body: Dict[str, Any]) -> None:
        if self._update_handler is not None:
            await self._update_handler(body)

    async def listen(self, handler: Callable[[str, Any], Awaitable[None]],
                     poll_history_chats: Optional[List[Peer]] = None) -> None:
        """Run forever, calling ``handler(kind, payload)`` for every update."""
        await self.ensure_connected()
        self.transport.update_callback = self._dispatch_update
        queue: asyncio.Queue = asyncio.Queue()

        async def _queue(body: Dict[str, Any]) -> None:
            await queue.put(body)

        self._update_handler = _queue

        while True:
            body = await queue.get()
            if "messageSent" in body:
                info = body["messageSent"] or {}
                peer = info.get("peer") or {}
                await handler("message_sent", {"peer": peer, "rid": info.get("rid"),
                                               "date": info.get("date")})
            elif "message" in body:
                msg = body["message"] or {}
                await handler("message", msg)
            elif "typing" in body:
                await handler("typing", body["typing"])
            elif "messageDelete" in body:
                await handler("message_delete", body["messageDelete"])
            elif "messageRead" in body:
                await handler("message_read", body["messageRead"])
            else:
                kind = next((k for k in body if not k.startswith("_")), "unknown")
                await handler(kind, body.get(kind))
