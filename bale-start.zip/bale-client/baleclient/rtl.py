"""
baleclient.rtl - Arabic/Persian text shaping and bidirectional ordering.

Tk (and most terminal emulators) draw a string strictly left to right, glyph
by glyph.  That is enough for English, but Persian/Arabic needs two extra
steps that the browser does for us and Tk does not:

1. **Shaping** - a letter has up to four glyphs (isolated, final, initial,
   medial): ``س`` at the start of ``سلام`` is drawn with the *initial* form and
   joins the letter after it.  The Unicode Arabic Presentation Forms blocks
   (``U+FB50``-``U+FEFF``) contain one code point per glyph.
2. **Bidi** - an RTL paragraph is laid out right to left, so the glyph run has
   to be reversed; embedded LTR runs (Latin words, numbers, URLs) stay in
   their own order inside the RTL line.

Both tables here are derived from :mod:`unicodedata` at import time, so there is
no hand-maintained glyph table and no third-party dependency.

    >>> visual("سلام")
    'ﻡﺎﻠﺳ'
    >>> visual("سلام 123 abc")
    'abc 123 ﻡﺎﻠﺳ'

The output is a string of *presentation forms* meant only for display - never
for the wire, the protocol always carries the original logical text.
"""
from __future__ import annotations

import unicodedata
from typing import Dict, List, Optional, Tuple

__all__ = ["visual", "is_rtl", "shape", "bidi"]

# --------------------------------------------------------------------------- tables
FORMS = ("isolated", "final", "initial", "medial")
_INDEX = {name: i for i, name in enumerate(FORMS)}


def _build_tables() -> Tuple[Dict[str, List[str]], Dict[str, str]]:
    """Return (letter -> [isolated, final, initial, medial], ligature -> forms)."""
    letters: Dict[str, List[str]] = {}
    ligatures: Dict[str, List[str]] = {}

    def absorb(codepoint: int) -> None:
        char = chr(codepoint)
        name = unicodedata.name(char, "")
        if not name.startswith("ARABIC "):
            return
        for form in FORMS:
            suffix = " " + form.upper() + " FORM"
            if name.endswith(suffix):
                base = name[: -len(suffix)]
                if " LIGATURE " in base:
                    key = base.replace("ARABIC LIGATURE ", "").lower()
                    ligatures.setdefault(key, ["", "", "", ""])[_INDEX[form]] = char
                else:
                    key = base.replace("ARABIC LETTER ", "").lower()
                    letters.setdefault(key, ["", "", "", ""])[_INDEX[form]] = char
                return

    for codepoint in list(range(0xFB50, 0xFC00)) + list(range(0xFE70, 0xFF00)):
        absorb(codepoint)

    # map the base character to the entry built above
    by_char: Dict[str, List[str]] = {}
    for codepoint in (list(range(0x0600, 0x0700)) + list(range(0x0750, 0x0780))
                      + list(range(0x08A0, 0x0900))):
        char = chr(codepoint)
        name = unicodedata.name(char, "")
        if name.startswith("ARABIC LETTER "):
            key = name.replace("ARABIC LETTER ", "").lower()
            if key in letters:
                by_char[char] = letters[key]
    return by_char, ligatures


SHAPES, LIGATURES = _build_tables()

# letters that connect to the previous letter but never to the next one
_RIGHT_JOINING = set("اآأإؤدذرزژوةىۃﻻ")
# letters that never join at all
_NON_JOINING = set("ء")

# characters whose visual form is mirrored inside an RTL run
MIRROR = {
    "(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{",
    "<": ">", ">": "<", "\u00ab": "\u00bb", "\u00bb": "\u00ab",
}


def _is_arabic(char: str) -> bool:
    code = ord(char)
    return (0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F
            or 0x08A0 <= code <= 0x08FF or 0xFB50 <= code <= 0xFDFF
            or 0xFE70 <= code <= 0xFEFF)


def is_rtl(text: str) -> bool:
    """True when the first strong character of ``text`` is Arabic/Hebrew."""
    for char in text:
        if _is_arabic(char) or 0x0590 <= ord(char) <= 0x05FF:
            return True
        if char.isalpha():
            return False
    return False


# --------------------------------------------------------------------------- shaping
def _joins_forward(char: str) -> bool:
    """Can ``char`` connect to the letter that follows it?"""
    if char in _NON_JOINING or char in _RIGHT_JOINING:
        return False
    return char in SHAPES or bool(unicodedata.combining(char))


def _joins_backward(char: str) -> bool:
    """Can ``char`` connect to the letter before it?"""
    if char in _NON_JOINING:
        return False
    return char in SHAPES or bool(unicodedata.combining(char))


def shape(text: str) -> str:
    """Replace Arabic letters with their contextual presentation forms."""
    if not any(_is_arabic(c) for c in text):
        return text
    out: List[str] = []
    index = 0
    total = len(text)
    while index < total:
        char = text[index]
        forms = SHAPES.get(char)
        if forms is None:
            out.append(char)
            index += 1
            continue

        # lam + alef becomes a single mandatory ligature
        if char in "\u0644" and index + 1 < total and text[index + 1] in "اآأإ":
            alef = text[index + 1]
            name = {"ا": "lam with alef", "آ": "lam with alef madda",
                    "أ": "lam with alef hamza above",
                    "إ": "lam with alef hamza below"}[alef]
            lig = LIGATURES.get(name)
            if lig:
                previous = text[index - 1] if index else ""
                joined = bool(previous) and _joins_forward(previous)
                out.append(lig[1] if joined else lig[0])
                index += 2
                continue

        previous = text[index - 1] if index else ""
        following = text[index + 1] if index + 1 < total else ""
        connect_prev = bool(previous) and _joins_forward(previous) and _joins_backward(char)
        connect_next = bool(following) and _joins_forward(char) and _joins_backward(following)
        if connect_prev and connect_next and forms[3]:
            out.append(forms[3])
        elif connect_prev and forms[1]:
            out.append(forms[1])
        elif connect_next and forms[2]:
            out.append(forms[2])
        else:
            out.append(forms[0] or char)
        index += 1
    return "".join(out)


# --------------------------------------------------------------------------- bidi
def _classify_digits(text: str) -> List[str]:
    """Digits glued to Latin letters belong to the Latin run (``CiX98k``).

    Without this, every digit would split a URL or a version string into
    separate runs and the whole run sequence would be reordered.
    """
    kinds = [_classify(char) for char in text]
    latin_punct = set("./:\\_-+@#?&=%")
    for index, kind in enumerate(kinds):
        before = text[index - 1] if index else ""
        after = text[index + 1] if index + 1 < len(text) else ""
        latin_before = bool(before) and before.isascii() and before.isalnum()
        latin_after = bool(after) and after.isascii() and after.isalnum()
        if kind == "N":
            if latin_before or latin_after:
                kinds[index] = "L"
        elif kind == "T" and text[index] in latin_punct and latin_before and latin_after:
            kinds[index] = "L"          # keeps URLs and file names in one piece
    return kinds


def _classify(char: str) -> str:
    if char in "\u200c\u200d\u0640" or unicodedata.combining(char):
        return "R"          # ZWNJ, ZWJ, tatweel and harakat join the RTL run
    if _is_arabic(char) or 0x0590 <= ord(char) <= 0x05FF:
        return "R"
    if char.isdigit() or ("\u0660" <= char <= "\u0669"):
        return "N"
    if char.isalpha():
        return "L"
    return "T"          # neutral / punctuation / space


def _runs(text: str, kinds: Optional[List[str]] = None) -> List[Tuple[str, str]]:
    runs: List[Tuple[str, str]] = []
    kinds = kinds or [_classify(char) for char in text]
    for char, kind in zip(text, kinds):
        if runs and runs[-1][0] == kind:
            runs[-1] = (kind, runs[-1][1] + char)
        else:
            runs.append((kind, char))

    # neutrals pick up the direction of their neighbours (RTL wins a tie)
    resolved: List[Tuple[str, str]] = []
    for index, (kind, chunk) in enumerate(runs):
        if kind != "T":
            resolved.append((kind, chunk))
            continue
        before = next((k for k, _ in reversed(runs[:index]) if k != "T"), None)
        after = next((k for k, _ in runs[index + 1:] if k != "T"), None)
        direction = "R" if "R" in (before, after) else ("L" if before or after else "L")
        resolved.append((direction, chunk))

    return resolved


def bidi(text: str) -> str:
    """Reorder a shaped string for a right-to-left paragraph."""
    if not text:
        return text
    if not is_rtl(text):
        return "".join(MIRROR.get(c, c) for c in text) if False else text

    resolved = _runs(text, _classify_digits(text))
    out: List[str] = []
    for kind, chunk in reversed(resolved):
        if kind in ("R", "N"):
            # numbers keep their own order, letters are reversed
            if kind == "N":
                out.append(chunk)
            else:
                out.append("".join(MIRROR.get(c, c) for c in reversed(chunk)))
        else:
            out.append(chunk)
    return "".join(out)


def visual(text: str) -> str:
    """Shape then reorder - the string to hand to Tk/terminal for display."""
    if not text:
        return text
    return bidi(shape(text))
