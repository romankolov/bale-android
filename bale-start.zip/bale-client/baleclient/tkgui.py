"""
baleclient.tkgui - the native desktop GUI.

100% Python: tkinter (part of the standard library) draws the whole window, and
every protocol call goes through :class:`baleclient.client.BaleClient` directly.
There is no JavaScript, no browser and no HTTP server in this path - which is
the point: the challenge accepts Java, C#, Kotlin and Python, and this client
is Python end to end.

    python run.py native            # real account, resumes a saved session
    python run.py native --demo     # fake chats, no account needed

The window is deliberately built from plain ``tk`` widgets (no ttk themes) so it
looks the same on Windows, macOS and Linux, and so the colours can be swapped
for the dark theme at runtime.
"""
from __future__ import annotations

import base64
import io
import os
import queue
import threading
import time
import traceback
import tkinter as tk
from tkinter import filedialog, messagebox
from typing import Any, Callable, Dict, List, Optional

from .client import Chat, Message, Peer
from .rtl import is_rtl, visual
from .webui import DemoBackend, WebApp, chat_json, media_of, message_json

try:  # Pillow is optional: without it photos fall back to a file card
    from PIL import Image, ImageTk  # type: ignore
    HAVE_PIL = True
except Exception:  # noqa: BLE001  pragma: no cover
    HAVE_PIL = False

FONT = ("Segoe UI", 10)
FONT_SMALL = ("Segoe UI", 8)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")
FONT_BIG = ("Segoe UI", 17, "bold")

LIGHT = {
    "bg": "#eef2f4", "side": "#ffffff", "panel": "#ffffff", "line": "#e3e9ec",
    "txt": "#16232b", "muted": "#7b8a93", "accent": "#00a693",
    "out": "#d5f2ea", "in": "#ffffff", "hover": "#eef4f5", "day": "#dde5e8",
}
DARK = {
    "bg": "#0f1518", "side": "#111a1e", "panel": "#141d21", "line": "#22303a",
    "txt": "#e7eef1", "muted": "#8fa3ad", "accent": "#2ec7b4",
    "out": "#12463c", "in": "#18242a", "hover": "#1b262c", "day": "#1d2a31",
}


def V(text: str) -> str:
    """Shape + reorder Persian/Arabic text for Tk, which has no bidi support."""
    return visual(text or "")


def _initials(name: str) -> str:
    text = (name or "?").strip()
    if not text:
        return "?"
    if any("\u0600" <= ch <= "\u06ff" for ch in text):
        return text[:2]
    parts = text.split()
    return "".join(p[0] for p in parts[:2]).upper()


def _clock(ms: int) -> str:
    if not ms:
        return ""
    return time.strftime("%H:%M", time.localtime(ms / 1000))


def _day(ms: int) -> str:
    if not ms:
        return ""
    today = time.strftime("%Y-%m-%d")
    yesterday = time.strftime("%Y-%m-%d", time.localtime(time.time() - 86400))
    stamp = time.strftime("%Y-%m-%d", time.localtime(ms / 1000))
    if stamp == today:
        return "Today"
    if stamp == yesterday:
        return "Yesterday"
    return time.strftime("%d %b %Y", time.localtime(ms / 1000))


def _size(n: int) -> str:
    n = float(n or 0)
    if n <= 0:
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return ""


# --------------------------------------------------------------------------- scroll
class ScrollFrame(tk.Frame):
    """A vertical scroller whose inner frame always matches the canvas width."""

    def __init__(self, master: tk.Misc, bg: str, **kw: Any):
        super().__init__(master, bg=bg, **kw)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.bar = tk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.bar.set)
        self.bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas.bind("<Configure>",
                         lambda e: self.canvas.itemconfig(self.win, width=e.width))
        self.inner.bind("<Configure>", self._on_inner)
        self.canvas.bind("<Enter>", self._grab_wheel)
        self.canvas.bind("<Leave>", self._release_wheel)

    def _on_inner(self, _event: tk.Event) -> None:
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _grab_wheel(self, _event: tk.Event) -> None:
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", lambda e: self.canvas.yview_scroll(-3, "units"))
        self.canvas.bind_all("<Button-5>", lambda e: self.canvas.yview_scroll(3, "units"))

    def _release_wheel(self, _event: tk.Event) -> None:
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    def _wheel(self, event: tk.Event) -> None:
        delta = -1 if event.delta > 0 else 1
        self.canvas.yview_scroll(delta * 3, "units")

    def bottom(self) -> None:
        self.update_idletasks()
        self.canvas.yview_moveto(1.0)

    def clear(self) -> None:
        for child in self.inner.winfo_children():
            child.destroy()
        self.canvas.yview_moveto(0.0)


# --------------------------------------------------------------------------- app
class NativeApp(WebApp):
    """Tk front end on top of :class:`WebApp`'s asyncio plumbing.

    ``WebApp`` already knows how to talk to Bale (login, dialogs, history,
    media, search, ...).  Reusing it means the desktop and browser front ends
    share one tested backend; this file only builds widgets and maps events.
    """

    def __init__(self, client, demo: bool = False):
        super().__init__(client, demo)
        self.ui: "queue.Queue[Dict[str, Any]]" = queue.Queue()
        self.dark = False
        self.c = dict(LIGHT)
        self.chats: List[Dict[str, Any]] = []
        self.messages: Dict[str, List[Dict[str, Any]]] = {}
        self.active: Optional[str] = None
        self.filter_text = ""
        self.reply_to: Optional[Dict[str, Any]] = None
        self.editing: Optional[Dict[str, Any]] = None
        self.ctx_msg: Optional[Dict[str, Any]] = None
        self.typing_job: Optional[str] = None
        self.last_typing = 0.0
        self.photo_cache: Dict[str, Any] = {}
        self.my_reactions: set = set()
        self.step = "phone"
        self.login_status: Optional[tk.Label] = None

        self.root = tk.Tk()
        self.root.title("Bale - Python client")
        self.root.geometry("1040x680")
        self.root.minsize(860, 560)
        self.root.configure(bg=self.c["bg"])
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        self.login_frame: Optional[tk.Frame] = None
        self.main_frame: Optional[tk.Frame] = None
        self._build_login()
        if not demo and not (client.token or client.state.get("token")):
            self.login_frame.pack(fill="both", expand=True)
        else:
            self._show_main()

        self.start()                      # WebApp: background asyncio + demo loop
        self.root.after(60, self._pump)

    # -- WebApp hooks ------------------------------------------------------
    def push(self, kind: str, payload: Dict[str, Any]) -> None:
        """Called from the asyncio thread - never touch Tk from here."""
        self.ui.put({"type": kind, "data": payload})

    # -- helpers -----------------------------------------------------------
    def theme(self) -> None:
        self.c = dict(DARK if self.dark else LIGHT)

    def bg(self, fn: Callable[[], Any], done: Optional[Callable[[Any], None]] = None) -> None:
        """Run a blocking backend call off the Tk thread, then hand the result back."""
        def runner() -> None:
            try:
                result = fn()
            except Exception as exc:  # noqa: BLE001
                traceback.print_exc()
                result = {"error": str(exc)}
            if done is not None:
                self.ui.put({"type": "callback", "fn": done, "data": result})
        threading.Thread(target=runner, daemon=True).start()

    def _on_close(self) -> None:
        try:
            self.loop.call_soon_threadsafe(self.loop.stop)
        except Exception:  # noqa: BLE001
            pass
        self.root.destroy()

    def _pump(self) -> None:
        try:
            for _ in range(60):
                event = self.ui.get_nowait()
                self._handle(event)
        except queue.Empty:
            pass
        except Exception:  # noqa: BLE001
            traceback.print_exc()
        self.root.after(60, self._pump)

    def _handle(self, event: Dict[str, Any]) -> None:
        kind, data = event.get("type"), event.get("data") or {}
        if kind == "callback":
            try:
                event["fn"](data)
            except Exception:  # noqa: BLE001
                traceback.print_exc()
            return
        if kind == "status":
            self._set_conn(bool(data.get("connected")))
        elif kind == "message":
            self._incoming(data)
        elif kind == "typing":
            self._show_typing(data)
        elif kind == "typing_stop":
            self._hide_typing()
        elif kind == "reaction":
            self._live_reaction(data)

    # =====================================================================
    #  login
    # =====================================================================
    def _build_login(self) -> None:
        frame = tk.Frame(self.root, bg=self.c["bg"])
        self.login_frame = frame
        card = tk.Frame(frame, bg=self.c["panel"], padx=34, pady=30,
                        highlightbackground=self.c["line"], highlightthickness=1)
        card.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(card, text="Bale", font=FONT_BIG, bg=self.c["panel"],
                 fg=self.c["accent"]).pack()
        self.login_title = tk.Label(card, text="Sign in to Bale", font=FONT_TITLE,
                                    bg=self.c["panel"], fg=self.c["txt"])
        self.login_title.pack(pady=(2, 2))
        self.login_sub = tk.Label(card, text="Enter your phone number", font=FONT_SMALL,
                                  bg=self.c["panel"], fg=self.c["muted"])
        self.login_sub.pack(pady=(0, 16))

        self.phone_var = tk.StringVar()
        self.code_var = tk.StringVar()
        self.pass_var = tk.StringVar()
        self.name_var = tk.StringVar()
        self.field = tk.Entry(card, textvariable=self.phone_var, font=("Segoe UI", 13),
                              bg=self.c["bg"], fg=self.c["txt"], insertbackground=self.c["txt"],
                              relief="flat", width=26)
        self.field.pack(ipady=7, pady=(0, 12))

        self.login_btn = tk.Button(card, text="Send code", font=FONT_BOLD, bd=0,
                                   bg=self.c["accent"], fg="white", activebackground=self.c["accent"],
                                   activeforeground="white", cursor="hand2", command=self._login_action)
        self.login_btn.pack(fill="x", ipady=7)
        self.back_btn = tk.Button(card, text="Change number", font=FONT_SMALL, bd=0,
                                  bg=self.c["panel"], fg=self.c["accent"], cursor="hand2",
                                  command=self._login_back)

        self.login_status = tk.Label(card, text="", font=FONT_SMALL, bg=self.c["panel"],
                                     fg="#d9534f", wraplength=250, justify="center")
        self.login_status.pack(pady=(12, 0))
        self.field.bind("<Return>", lambda e: self._login_action())
        self.field.focus_set()

    def _login_set(self, step: str, message: str = "") -> None:
        self.step = step
        titles = {
            "phone": ("Sign in to Bale", "Enter your phone number", "Send code"),
            "code": ("Check your messages", "Enter the SMS code", "Verify"),
            "password": ("Two-step verification", "Enter your 2FA password", "Sign in"),
            "name": ("Almost there", "Choose a display name", "Create account"),
        }
        title, sub, button = titles[step]
        self.login_title.config(text=title)
        self.login_sub.config(text=sub)
        self.login_btn.config(text=button)
        if step == "phone":
            self.field.config(textvariable=self.phone_var, show="")
            self.back_btn.pack_forget()
        elif step == "code":
            self.field.config(textvariable=self.code_var, show="")
            self.back_btn.pack(pady=(8, 0))
        elif step == "password":
            self.field.config(textvariable=self.pass_var, show="*")
            self.back_btn.pack(pady=(8, 0))
        else:
            self.field.config(textvariable=self.name_var, show="")
            self.back_btn.pack(pady=(8, 0))
        if self.login_status is not None:
            self.login_status.config(text=message, fg=("#d9534f" if message else "#d9534f"))
        self.field.focus_set()

    def _login_back(self) -> None:
        self._login_set("phone")
        self.code_var.set("")
        self.pass_var.set("")

    def _login_action(self) -> None:
        if self.login_status:
            self.login_status.config(text="working...", fg=self.c["muted"])
        if self.step == "phone":
            phone = self.phone_var.get().strip()
            if len(phone) < 8:
                self._login_error("Enter a phone number like 989121234567")
                return
            self.bg(lambda: self.call(self._do_login_start(phone)), self._after_start)
        elif self.step == "code":
            code = self.code_var.get().strip()
            self.bg(lambda: self.call(self._do_login_code(code)), self._after_login)
        elif self.step == "password":
            password = self.pass_var.get()
            self.bg(lambda: self.call(self._do_login_password(password)), self._after_login)
        else:
            name = self.name_var.get().strip() or "Bale user"
            self.bg(lambda: self.call(self._do_signup(name)), self._after_login)

    def _login_error(self, text: str) -> None:
        if self.login_status:
            self.login_status.config(text=text, fg="#d9534f")

    def _after_start(self, res: Dict[str, Any]) -> None:
        if res.get("error"):
            self._login_error(str(res["error"]))
            return
        if res.get("status") == "password":
            self._login_set("password", "This account uses a 2FA password")
        else:
            self._login_set("code", "A code was sent to your phone")

    def _after_login(self, res: Dict[str, Any]) -> None:
        if res.get("error"):
            self._login_error(str(res["error"]))
            return
        if res.get("status") == "signup":
            self._login_set("name", "This number is new - pick a name")
            return
        if res.get("status") != "ok":
            self._login_error(str(res))
            return
        self._show_main()

    # =====================================================================
    #  window shell
    # =====================================================================
    def _show_main(self) -> None:
        self.theme()
        if self.login_frame is not None:
            self.login_frame.pack_forget()
        if self.main_frame is not None:
            self.main_frame.destroy()
        self._build_main()
        self.main_frame.pack(fill="both", expand=True)
        self.bg(lambda: self.call(self._dialogs()), self._got_chats)

    def _build_main(self) -> None:
        c = self.c
        self.main_frame = tk.Frame(self.root, bg=c["bg"])
        main = self.main_frame
        main.columnconfigure(0, weight=0, minsize=320)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(0, weight=1)

        # ---------------- sidebar
        side = tk.Frame(main, bg=c["side"], width=320)
        side.grid(row=0, column=0, sticky="nsew")
        side.pack_propagate(False)

        head = tk.Frame(side, bg=c["side"], padx=12, pady=10)
        head.pack(fill="x")
        self.me_avatar = tk.Canvas(head, width=34, height=34, bg=c["side"],
                                   highlightthickness=0)
        self.me_avatar.pack(side="left")
        self.me_name = tk.Label(head, text="Bale", font=FONT_BOLD, bg=c["side"], fg=c["txt"])
        self.me_name.pack(side="left", padx=(8, 0))
        self.conn = tk.Canvas(head, width=10, height=10, bg=c["side"], highlightthickness=0)
        self.conn.pack(side="left", padx=(8, 0))
        self.conn.create_oval(1, 1, 9, 9, fill="#c9d4da", outline="")
        tk.Button(head, text="\u25d0", font=FONT, bd=0, bg=c["side"], fg=c["muted"],
                  activebackground=c["hover"], cursor="hand2",
                  command=self._toggle_theme).pack(side="right")

        search_wrap = tk.Frame(side, bg=c["side"], padx=12)
        search_wrap.pack(fill="x")
        self.search_var = tk.StringVar()
        search = tk.Entry(search_wrap, textvariable=self.search_var, font=FONT, bd=0,
                          bg=c["hover"], fg=c["txt"], insertbackground=c["txt"])
        search.pack(fill="x", ipady=6, padx=1)
        search.bind("<KeyRelease>", self._on_filter)
        search.bind("<Return>", lambda e: self._run_search())

        self.chat_scroll = ScrollFrame(side, bg=c["side"])
        self.chat_scroll.pack(fill="both", expand=True, padx=(4, 0), pady=(6, 6))

        # ---------------- chat pane
        pane = tk.Frame(main, bg=c["bg"])
        pane.grid(row=0, column=1, sticky="nsew")
        pane.rowconfigure(2, weight=1)
        pane.columnconfigure(0, weight=1)

        self.pane_head = tk.Frame(pane, bg=c["panel"], padx=14, pady=9)
        self.pane_head.grid(row=0, column=0, sticky="ew")
        self.peer_avatar = tk.Canvas(self.pane_head, width=38, height=38, bg=c["panel"],
                                     highlightthickness=0)
        self.peer_avatar.pack(side="left")
        titles = tk.Frame(self.pane_head, bg=c["panel"])
        titles.pack(side="left", padx=(10, 0))
        self.peer_name = tk.Label(titles, text="Select a chat", font=FONT_BOLD,
                                  bg=c["panel"], fg=c["txt"], anchor="w")
        self.peer_name.pack(anchor="w")
        self.peer_status = tk.Label(titles, text="connected to Bale", font=FONT_SMALL,
                                    bg=c["panel"], fg=c["muted"], anchor="w")
        self.peer_status.pack(anchor="w")
        tk.Button(self.pane_head, text="\u2630", font=FONT, bd=0, bg=c["panel"],
                  fg=c["muted"], activebackground=c["hover"], cursor="hand2",
                  command=self._show_members).pack(side="right")
        tk.Button(self.pane_head, text="\u24d8", font=FONT, bd=0, bg=c["panel"],
                  fg=c["muted"], activebackground=c["hover"], cursor="hand2",
                  command=self._show_profile).pack(side="right", padx=(0, 4))

        self.msg_scroll = ScrollFrame(pane, bg=c["bg"])
        self.msg_scroll.grid(row=2, column=0, sticky="nsew")
        self.empty = tk.Label(pane, text="Select a conversation\n\n"
                                         "python run.py native - the whole client is Python",
                              font=FONT, bg=c["bg"], fg=c["muted"], justify="center")
        self.empty.grid(row=2, column=0)

        self.reply_bar = tk.Frame(pane, bg=c["panel"], padx=14, pady=6)
        self.reply_label = tk.Label(self.reply_bar, text="", font=FONT_SMALL,
                                    bg=c["panel"], fg=c["accent"], anchor="w")
        self.reply_label.pack(side="left", fill="x", expand=True)
        tk.Button(self.reply_bar, text="\u2715", font=FONT_SMALL, bd=0, bg=c["panel"],
                  fg=c["muted"], command=self._cancel_reply).pack(side="right")

        comp = tk.Frame(pane, bg=c["panel"], padx=10, pady=9)
        comp.grid(row=3, column=0, sticky="ew")
        tk.Button(comp, text="\U0001f4ce", font=("Segoe UI", 13), bd=0, bg=c["panel"],
                  fg=c["muted"], activebackground=c["hover"], cursor="hand2",
                  command=self._attach).pack(side="left", padx=(2, 6))
        self.entry = tk.Text(comp, height=1, font=("Segoe UI", 11), bd=0, wrap="word",
                             bg=c["hover"], fg=c["txt"], insertbackground=c["txt"],
                             padx=10, pady=8)
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.entry.bind("<Return>", self._on_return)
        self.entry.bind("<Shift-Return>", lambda e: None)
        self.entry.bind("<KeyRelease>", self._on_type)
        tk.Button(comp, text="\u27a4", font=("Segoe UI", 13), bd=0, width=3,
                  bg=c["accent"], fg="white", activebackground=c["accent"],
                  activeforeground="white", cursor="hand2",
                  command=self._composer_send).pack(side="right")

        self._draw_avatar(self.me_avatar, "Bale", self.c["accent"], 34)
        self._update_theme_buttons()

    def _toggle_theme(self) -> None:
        self.dark = not self.dark
        self.theme()
        active, messages = self.active, self.messages
        if self.main_frame is not None:
            self.main_frame.destroy()
        self.main_frame = None
        self.active = None
        self._build_main()
        self.main_frame.pack(fill="both", expand=True)
        self._render_chats()
        self.messages = messages
        if active:
            self.active = active
            self.empty.grid_forget()
            self.msg_scroll.grid(row=2, column=0, sticky="nsew")
            chat = next((c for c in self.chats if c["peer"] == active), None)
            title = (chat or {}).get("title") or active
            self.peer_name.config(text=V(title))
            self._draw_avatar(self.peer_avatar, title, self.c["accent"], 38)
            self.render_messages()

    def _update_theme_buttons(self) -> None:
        pass

    def _set_conn(self, on: bool) -> None:
        if not hasattr(self, "conn"):
            return
        self.conn.delete("all")
        self.conn.create_oval(1, 1, 9, 9, fill=("#2ecc71" if on else "#c9d4da"), outline="")

    # =====================================================================
    #  avatars
    # =====================================================================
    def _draw_avatar(self, canvas: tk.Canvas, name: str, color: str, size: int) -> None:
        canvas.delete("all")
        canvas.configure(width=size, height=size)
        canvas.create_oval(1, 1, size - 1, size - 1, fill=color, outline="")
        canvas.create_text(size / 2, size / 2, text=_initials(name), fill="white",
                           font=("Segoe UI", max(8, size // 4), "bold"))

    # =====================================================================
    #  chat list
    # =====================================================================
    def _got_chats(self, res: Dict[str, Any]) -> None:
        if isinstance(res, dict) and res.get("error"):
            self._set_status(str(res["error"]))
            return
        self.chats = res.get("chats", []) if isinstance(res, dict) else []
        me = (res or {}).get("me") or {}
        if me:
            name = me.get("name") or "Bale"
            self.me_name.config(text=V(name))
            self._draw_avatar(self.me_avatar, name, self.c["accent"], 34)
        self._render_chats()

    def _set_status(self, text: str) -> None:
        if hasattr(self, "peer_status"):
            self.peer_status.config(text=text)

    def _render_chats(self) -> None:
        if not hasattr(self, "chat_scroll"):
            return
        self.chat_scroll.clear()
        needle = self.filter_text.lower()
        shown = [c for c in self.chats
                 if not needle or needle in (c.get("title") or "").lower()
                 or needle in (c.get("preview") or "").lower()]
        for chat in shown:
            self._chat_row(chat)
        if not shown:
            tk.Label(self.chat_scroll.inner, text="no conversations", font=FONT_SMALL,
                     bg=self.c["side"], fg=self.c["muted"]).pack(pady=20)

    def _chat_row(self, chat: Dict[str, Any]) -> None:
        c = self.c
        active = self.active == chat["peer"]
        bg = c["hover"] if active else c["side"]
        row = tk.Frame(self.chat_scroll.inner, bg=bg, cursor="hand2", padx=8, pady=5)
        row.pack(fill="x")

        avatar = tk.Canvas(row, width=42, height=42, bg=bg, highlightthickness=0)
        avatar.pack(side="left")
        self._draw_avatar(avatar, chat.get("title") or "?", c["accent"], 42)

        right = tk.Frame(row, bg=bg)
        right.pack(side="right", fill="y")
        tk.Label(right, text=_clock(chat.get("date") or 0), font=FONT_SMALL,
                 bg=bg, fg=c["muted"]).pack(anchor="e")
        if chat.get("unread"):
            badge = tk.Label(right, text=str(min(int(chat["unread"]), 99)), font=("Segoe UI", 8, "bold"),
                             bg=c["accent"], fg="white", padx=5)
            badge.pack(anchor="e", pady=(4, 0))

        mid = tk.Frame(row, bg=bg)
        mid.pack(side="left", fill="x", expand=True, padx=(9, 4))
        title = chat.get("title") or chat["peer"]
        tk.Label(mid, text=V(title)[:46], font=FONT_BOLD, bg=bg,
                 fg=c["txt"], anchor="e" if is_rtl(title) else "w").pack(fill="x")
        preview = (chat.get("preview") or "").replace("\n", " ")
        tk.Label(mid, text=V(preview[:70]), font=FONT_SMALL, bg=bg, fg=c["muted"],
                 anchor="e" if is_rtl(preview) else "w").pack(fill="x")

        handler = lambda e, key=chat["peer"]: self._open_chat(key)  # noqa: E731
        for widget in (row, avatar, mid, right, *mid.winfo_children(), *right.winfo_children()):
            widget.bind("<Button-1>", handler)

    # =====================================================================
    #  opening a conversation
    # =====================================================================
    def _open_chat(self, peer_key: str) -> None:
        chat = next((c for c in self.chats if c["peer"] == peer_key), None)
        if chat is None:
            chat = {"peer": peer_key, "title": peer_key, "isGroup": peer_key.startswith("g:")}
        self.active = peer_key
        self.empty.grid_forget()
        self.msg_scroll.grid(row=2, column=0, sticky="nsew")
        title = chat.get("title") or peer_key
        self.peer_name.config(text=V(title))
        self.peer_status.config(text="group" if chat.get("isGroup") else "user")
        self._draw_avatar(self.peer_avatar, chat.get("title") or "?", self.c["accent"], 38)
        self._render_chats()
        self.msg_scroll.clear()
        tk.Label(self.msg_scroll.inner, text="loading...", font=FONT_SMALL,
                 bg=self.c["bg"], fg=self.c["muted"]).pack(pady=16)
        self.bg(lambda: self.call(self._history(peer_key, 60, None)),
                lambda res: self._got_history(peer_key, res))
        if chat.get("unread"):
            chat["unread"] = 0
            self.bg(lambda: self.call(self._read(peer_key, chat.get("date") or int(time.time() * 1000))))

    def _got_history(self, peer_key: str, res: Dict[str, Any]) -> None:
        if self.active != peer_key:
            return
        if isinstance(res, dict) and res.get("error"):
            self.msg_scroll.clear()
            tk.Label(self.msg_scroll.inner, text=str(res["error"]), font=FONT_SMALL,
                     bg=self.c["bg"], fg="#d9534f", wraplength=420).pack(pady=16)
            return
        self.messages[peer_key] = res.get("messages", [])
        self.render_messages()

    # =====================================================================
    #  messages
    # =====================================================================
    def render_messages(self) -> None:
        if not self.active or not hasattr(self, "msg_scroll"):
            return
        inner = self.msg_scroll.inner
        for child in inner.winfo_children():
            child.destroy()
        msgs = self.messages.get(self.active, [])
        last_day, last_sender, last_time = None, None, 0
        for msg in msgs:
            day = _day(msg.get("date") or 0)
            if day != last_day:
                tk.Label(inner, text=day, font=FONT_SMALL, bg=self.c["day"],
                         fg=self.c["muted"], padx=10, pady=2).pack(pady=(12, 6))
                last_day, last_sender = day, None
            grouped = msg.get("sender") == last_sender and (msg.get("date", 0) - last_time) < 300000
            self._bubble(inner, msg, grouped)
            last_sender, last_time = msg.get("sender"), msg.get("date", 0)
        if not msgs:
            tk.Label(inner, text="no messages yet", font=FONT_SMALL, bg=self.c["bg"],
                     fg=self.c["muted"]).pack(pady=20)
        self.msg_scroll.bottom()

    def _bubble(self, parent: tk.Misc, msg: Dict[str, Any], grouped: bool) -> None:
        c = self.c
        out = bool(msg.get("out"))
        row = tk.Frame(parent, bg=c["bg"])
        row.pack(fill="x", padx=10, pady=1)
        holder = tk.Frame(row, bg=c["bg"])
        holder.pack(side="right" if out else "left")
        bubble = tk.Frame(holder, bg=c["out"] if out else c["in"], padx=11, pady=6,
                          highlightbackground=c["line"], highlightthickness=1)
        bubble.pack(anchor="e" if out else "w")

        if not out and not grouped and self._is_group():
            sender = msg.get("senderName") or ""
            tk.Label(bubble, text=V(sender), font=("Segoe UI", 9, "bold"),
                     bg=c["out"] if out else c["in"], fg=c["accent"],
                     anchor="e" if is_rtl(sender) else "w").pack(fill="x")

        if msg.get("quoted"):
            quote = str(msg["quoted"])[:90]
            rtl_quote = is_rtl(quote)
            tk.Label(bubble, text=V(quote), font=FONT_SMALL,
                     bg=c["hover"], fg=c["muted"],
                     anchor="e" if rtl_quote else "w",
                     justify="right" if rtl_quote else "left",
                     wraplength=340, padx=6, pady=3).pack(fill="x", pady=(0, 4))

        media = msg.get("media") or {}
        if media:
            self._media_widget(bubble, msg, media)

        caption = (media or {}).get("caption") or msg.get("text") or ""
        if caption:
            rtl = is_rtl(caption)
            tk.Label(bubble, text=V(caption), font=FONT, bg=c["out"] if out else c["in"],
                     fg=c["txt"], wraplength=430, justify="right" if rtl else "left",
                     anchor="e" if rtl else "w").pack(fill="x")
        if not caption and msg.get("kind") not in ("text", None) and not media:
            tk.Label(bubble, text=f"[{msg.get('kind')}]", font=FONT_SMALL,
                     bg=c["out"] if out else c["in"], fg=c["muted"]).pack(fill="x")

        reactions = msg.get("reactions") or []
        if reactions:
            line = "  ".join(f"{r['code']} {r['count']}" for r in reactions)
            tk.Label(bubble, text=line, font=FONT_SMALL, bg=c["out"] if out else c["in"],
                     fg=c["txt"]).pack(anchor="e", pady=(3, 0))

        meta = tk.Frame(bubble, bg=c["out"] if out else c["in"])
        meta.pack(fill="x", pady=(3, 0))
        tk.Label(meta, text=_clock(msg.get("date") or 0), font=("Segoe UI", 7),
                 bg=c["out"] if out else c["in"], fg=c["muted"]).pack(side="right")
        if out:
            tk.Label(meta, text="\u2713", font=("Segoe UI", 8),
                     bg=c["out"], fg=c["accent"]).pack(side="right", padx=(0, 5))

        for widget in (bubble, *bubble.winfo_children(), row, holder):
            widget.bind("<Button-3>", lambda e, m=msg: self._ctx_menu(e, m))
            widget.bind("<Button-1>", lambda e, m=msg: setattr(self, "ctx_msg", m))

    def _is_group(self) -> bool:
        chat = next((c for c in self.chats if c["peer"] == self.active), None)
        return bool(chat and chat.get("isGroup"))

    def _media_widget(self, parent: tk.Misc, msg: Dict[str, Any], media: Dict[str, Any]) -> None:
        c = self.c
        kind = media.get("kind") or "document"
        name = media.get("name") or "file"
        if kind in ("photo", "gif"):
            url = msg.get("local") or ""
            if url.startswith("data:"):
                self._put_photo(parent, url, media)
                return
            if msg.get("id") in self.photo_cache:
                tk.Label(parent, image=self.photo_cache[msg["id"]],
                         bg=parent.cget("bg"), bd=0).pack(pady=(0, 4))
                return
            placeholder = tk.Label(parent, text=f"\U0001f5bc {name}", font=FONT_SMALL,
                                   bg=c["hover"], fg=c["muted"], padx=12, pady=18)
            placeholder.pack(pady=(0, 4))
            self.bg(lambda: self.call(self._media(int(media.get("fileId") or 0),
                                                  int(media.get("accessHash") or 0))),
                    lambda data, mid=msg.get("id"), holder=placeholder, md=media: self._got_photo(mid, holder, data, md))
            return
        row = tk.Frame(parent, bg=c["hover"], padx=8, pady=5)
        row.pack(fill="x", pady=(0, 4))
        icon = "\U0001f3b5" if kind in ("voice", "audio") else "\U0001f4c4"
        tk.Label(row, text=icon, font=("Segoe UI", 14), bg=c["hover"], fg=c["accent"]).pack(side="left")
        text = tk.Frame(row, bg=c["hover"])
        text.pack(side="left", padx=(8, 10))
        tk.Label(text, text=V(name)[:32], font=("Segoe UI", 9, "bold"), bg=c["hover"],
                 fg=c["txt"], anchor="w").pack(anchor="w")
        tk.Label(text, text=_size(media.get("fileSize") or 0), font=FONT_SMALL,
                 bg=c["hover"], fg=c["muted"], anchor="w").pack(anchor="w")
        tk.Button(row, text="save", font=FONT_SMALL, bd=0, bg=c["hover"], fg=c["accent"],
                  cursor="hand2", command=lambda m=media: self._save_media(m)).pack(side="right")

    def _put_photo(self, parent: tk.Misc, data_uri: str, media: Dict[str, Any]) -> None:
        try:
            raw = base64.b64decode(data_uri.split(",", 1)[1])
            self._show_image(parent, raw, bg=parent.cget("bg"))
        except Exception:  # noqa: BLE001
            tk.Label(parent, text=f"\U0001f5bc {media.get('name')}", font=FONT_SMALL,
                     bg=self.c["hover"], fg=self.c["muted"], padx=12, pady=18).pack(pady=(0, 4))

    def _got_photo(self, msg_id: str, placeholder: tk.Label, data: Any, media: Dict[str, Any]) -> None:
        if not isinstance(data, (bytes, bytearray)) or not data:
            placeholder.config(text=f"\U0001f5bc {media.get('name')} (download failed)")
            return
        self._show_image(placeholder.master, data, placeholder,
                         bg=placeholder.master.cget("bg"))

    def _show_image(self, parent: tk.Misc, raw: bytes,
                    placeholder: Optional[tk.Widget] = None,
                    bg: Optional[str] = None) -> None:
        if not HAVE_PIL:
            if placeholder is not None:
                placeholder.config(text=f"\U0001f5bc image ({_size(len(raw))})")
            return
        try:
            image = Image.open(io.BytesIO(raw))
            image.thumbnail((360, 260))
            photo = ImageTk.PhotoImage(image)
        except Exception:  # noqa: BLE001
            return
        if placeholder is not None:
            placeholder.destroy()
        label = tk.Label(parent, image=photo, bg=bg or self.c["bg"], bd=0)
        label.image = photo            # keep a reference
        label.pack(pady=(0, 4))
        self.photo_cache[id(photo)] = photo

    def _save_media(self, media: Dict[str, Any]) -> None:
        name = media.get("name") or "file"
        path = filedialog.asksaveasfilename(initialfile=name)
        if not path:
            return
        def worker() -> None:
            data = self.call(self._media(int(media.get("fileId") or 0),
                                         int(media.get("accessHash") or 0)), timeout=120)
            if data:
                with open(path, "wb") as handle:
                    handle.write(data)
                self.ui.put({"type": "callback", "fn": lambda _r, p=path: messagebox.showinfo("saved", p),
                             "data": None})
        threading.Thread(target=worker, daemon=True).start()

    # =====================================================================
    #  context menu
    # =====================================================================
    def _ctx_menu(self, event: tk.Event, msg: Dict[str, Any]) -> None:
        self.ctx_msg = msg
        menu = tk.Menu(self.root, tearoff=0)
        reactions = tk.Menu(menu, tearoff=0)
        for code in ("\U0001f44d", "\u2764\ufe0f", "\U0001f602", "\U0001f62e",
                     "\U0001f622", "\U0001f525"):
            reactions.add_command(label=code,
                                  command=lambda c=code, m=msg: self._toggle_reaction(m, c))
        menu.add_cascade(label="React", menu=reactions)
        menu.add_separator()
        menu.add_command(label="Reply", command=self._start_reply)
        menu.add_command(label="Copy text", command=self._copy_text)
        menu.add_command(label="Forward", command=self._ctx_forward)
        if msg.get("out"):
            menu.add_separator()
            menu.add_command(label="Edit", command=self._start_edit)
            menu.add_command(label="Delete", command=self._ctx_delete)
        menu.tk_popup(event.x_root, event.y_root)

    def _toggle_reaction(self, msg: Dict[str, Any], code: str) -> None:
        """Toggle one emoji reaction and update the bubble immediately."""
        key = f"{msg.get('id')}|{code}"
        mine = key in self.my_reactions
        if mine:
            self.my_reactions.discard(key)
        else:
            self.my_reactions.add(key)
        bucket = msg.setdefault("reactions", [])
        for reaction in bucket:
            if reaction["code"] == code:
                reaction["count"] = max(0, int(reaction.get("count") or 1) + (-1 if mine else 1))
                if reaction["count"] <= 0:
                    bucket.remove(reaction)
                break
        else:
            if not mine:
                bucket.append({"code": code, "count": 1})
        self.render_messages()
        peer = self.active
        self.bg(lambda: self.call(self._react_call(peer, msg, code, mine)),
                lambda res: self._status_or_error(res))

    def _react_call(self, peer: str, msg: Dict[str, Any], code: str, remove: bool) -> Dict[str, Any]:
        return self._react(peer, int(msg.get("rid") or 0), int(msg.get("date") or 0), code, remove)

    def _status_or_error(self, res: Dict[str, Any]) -> None:
        if isinstance(res, dict) and res.get("error"):
            self._set_status(str(res["error"]))

    def _start_reply(self) -> None:
        if not self.ctx_msg:
            return
        self.editing = None
        self.reply_to = self.ctx_msg
        text = self.ctx_msg.get("text") or ""
        who = self.ctx_msg.get("senderName") or "message"
        self.reply_label.config(text=f"Replying to {V(who)}: {V(text)[:60]}")
        self.reply_bar.grid(row=1, column=0, sticky="ew")
        self.entry.focus_set()

    def _start_edit(self) -> None:
        if not self.ctx_msg:
            return
        self.reply_to = None
        self.editing = self.ctx_msg
        self.reply_label.config(text="Editing message")
        self.reply_bar.grid(row=1, column=0, sticky="ew")
        self.entry.delete("1.0", "end")
        self.entry.insert("1.0", self.ctx_msg.get("text") or "")   # logical text, not shaped
        self.entry.focus_set()

    def _cancel_reply(self) -> None:
        self.reply_to = None
        self.editing = None
        self.reply_bar.grid_forget()
        self.entry.delete("1.0", "end")

    def _copy_text(self) -> None:
        if not self.ctx_msg:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(self.ctx_msg.get("text") or "")
        self._set_status("copied")

    def _ctx_forward(self) -> None:
        if not self.ctx_msg:
            return
        target = self._pick_chat("Forward to")
        if not target:
            return
        msg = self.ctx_msg
        payload = [{"rid": msg.get("rid") or 0, "date": msg.get("date") or 0,
                    "seq": msg.get("seq") or 0}]
        self.bg(lambda: self.call(self._forward(str(self.active), target, payload)),
                lambda res: self._set_status("forwarded" if not res.get("error") else str(res["error"])))

    def _ctx_delete(self) -> None:
        if not self.ctx_msg or not messagebox.askyesno("Delete", "Delete this message?"):
            return
        msg = self.ctx_msg
        peer = self.active
        self.messages[peer] = [m for m in self.messages.get(peer, []) if m["id"] != msg["id"]]
        self.render_messages()
        self.bg(lambda: self.call(self._delete(peer, [msg.get("date") or 0])))

    def _pick_chat(self, title: str) -> Optional[str]:
        window = tk.Toplevel(self.root)
        window.title(title)
        window.configure(bg=self.c["panel"], padx=10, pady=10)
        window.transient(self.root)
        tk.Label(window, text=title, font=FONT_BOLD, bg=self.c["panel"],
                 fg=self.c["txt"]).pack(anchor="w", pady=(0, 8))
        box = tk.Listbox(window, width=40, height=14, font=FONT, bd=0,
                         bg=self.c["bg"], fg=self.c["txt"], highlightthickness=0)
        box.pack(fill="both", expand=True)
        choices = [c for c in self.chats if c["peer"] != self.active]
        for chat in choices:
            box.insert("end", chat.get("title") or chat["peer"])
        result: Dict[str, Optional[str]] = {"peer": None}

        def choose(_event: Optional[tk.Event] = None) -> None:
            selection = box.curselection()
            if selection:
                result["peer"] = choices[selection[0]]["peer"]
            window.destroy()

        box.bind("<Double-Button-1>", choose)
        tk.Button(window, text="OK", command=choose, bg=self.c["accent"], fg="white",
                  bd=0, font=FONT_BOLD).pack(fill="x", pady=(8, 0), ipady=4)
        window.grab_set()
        self.root.wait_window(window)
        return result["peer"]

    # =====================================================================
    #  composer
    # =====================================================================
    def _on_return(self, event: tk.Event) -> str:
        self._composer_send()
        return "break"

    def _on_type(self, _event: tk.Event) -> None:
        if not self.active:
            return
        now = time.time()
        if now - self.last_typing > 4 and self.entry.get("1.0", "end").strip():
            self.last_typing = now
            peer = self.active
            self.bg(lambda: self.call(self._typing(peer)))

    def _composer_send(self) -> None:
        if not self.active:
            return
        text = self.entry.get("1.0", "end").strip()
        if not text:
            return
        peer = self.active
        self.entry.delete("1.0", "end")
        self.reply_bar.grid_forget()

        if self.editing:
            msg = self.editing
            self.editing = None
            msg["text"] = text
            self.render_messages()
            self.bg(lambda: self.call(self._edit(peer, msg.get("rid") or 0, text)))
            return

        reply = self.reply_to
        self.reply_to = None
        local = {
            "id": f"local:{time.time()}", "peer": peer, "sender": 1, "senderName": "me",
            "date": int(time.time() * 1000), "text": text, "kind": "text", "out": True,
            "quoted": (reply or {}).get("text") or "", "media": None, "reactions": [],
        }
        self.messages.setdefault(peer, []).append(local)
        self.render_messages()
        payload = None
        if reply:
            payload = {"rid": reply.get("rid") or 0, "date": reply.get("date") or 0,
                       "seq": reply.get("seq") or 0}
        self.bg(lambda: self.call(WebApp._send(self, peer, text, payload)),
                lambda res: self._sent(res))
        chat = next((c for c in self.chats if c["peer"] == peer), None)
        if chat:
            chat["preview"] = text
            chat["date"] = local["date"]
            self._render_chats()

    def _sent(self, res: Dict[str, Any]) -> None:
        if isinstance(res, dict) and res.get("error"):
            messagebox.showerror("send failed", str(res["error"]))

    def _attach(self) -> None:
        if not self.active:
            return
        path = filedialog.askopenfilename()
        if not path:
            return
        peer = self.active
        name = os.path.basename(path)
        self._set_status(f"uploading {name}...")
        def worker() -> None:
            try:
                data = open(path, "rb").read()
                mime = __import__("mimetypes").guess_type(name)[0] or "application/octet-stream"
                b64 = base64.b64encode(data).decode()
                result = self.call(self._send_media(peer, name, mime, b64, ""), timeout=180)
            except Exception as exc:  # noqa: BLE001
                result = {"error": str(exc)}
            self.ui.put({"type": "callback", "fn": lambda r: self._attached(name, r), "data": result})
        threading.Thread(target=worker, daemon=True).start()

    def _attached(self, name: str, res: Dict[str, Any]) -> None:
        self._set_status("sent" if not (res or {}).get("error") else str(res["error"]))
        if self.active:
            self._open_chat(self.active)

    # =====================================================================
    #  live events
    # =====================================================================
    def _incoming(self, data: Dict[str, Any]) -> None:
        peer = data.get("peer")
        if not peer:
            return
        if data.get("out"):
            return
        self._hide_typing()
        message = {
            "id": f"srv:{peer}:{data.get('date')}:{data.get('rid')}",
            "peer": peer, "sender": data.get("sender") or 0,
            "senderName": data.get("senderName") or data.get("title") or "",
            "date": data.get("date") or int(time.time() * 1000),
            "text": data.get("text") or "", "kind": data.get("kind") or "text",
            "out": False, "quoted": "", "rid": data.get("rid") or 0,
            "seq": data.get("seq") or 0, "media": data.get("media"), "reactions": [],
        }
        self.messages.setdefault(peer, []).append(message)
        chat = next((c for c in self.chats if c["peer"] == peer), None)
        if chat:
            chat["preview"] = message["text"] or "[media]"
            chat["date"] = message["date"]
            if self.active != peer:
                chat["unread"] = int(chat.get("unread") or 0) + 1
        self._render_chats()
        if self.active == peer:
            self.render_messages()

    def _show_typing(self, data: Dict[str, Any]) -> None:
        if data.get("peer") != self.active:
            return
        who = data.get("name") if self._is_group() else ""
        self._set_status(f"{who + ' is ' if who else ''}typing...")
        if self.typing_job:
            self.root.after_cancel(self.typing_job)
        self.typing_job = self.root.after(5000, self._reset_status)

    def _hide_typing(self) -> None:
        if self.typing_job:
            self.root.after_cancel(self.typing_job)
            self.typing_job = None
        self._reset_status()

    def _reset_status(self) -> None:
        if not self.active:
            return
        self.peer_status.config(text="group" if self._is_group() else "user")

    def _live_reaction(self, data: Dict[str, Any]) -> None:
        for msg in self.messages.get(data.get("peer"), []):
            if int(msg.get("rid") or 0) == int(data.get("rid") or 0):
                reactions = msg.setdefault("reactions", [])
                for reaction in reactions:
                    if reaction["code"] == data.get("code"):
                        reaction["count"] = data.get("count") or reaction["count"]
                        break
                else:
                    reactions.append({"code": data.get("code"), "count": data.get("count") or 1})
                if self.active == data.get("peer"):
                    self.render_messages()
                return

    # =====================================================================
    #  search + profile
    # =====================================================================
    def _on_filter(self, _event: tk.Event) -> None:
        self.filter_text = self.search_var.get().strip()
        self._render_chats()

    def _run_search(self) -> None:
        needle = self.search_var.get().strip()
        if not needle:
            return
        self.bg(lambda: self.call(self._search(needle), timeout=60),
                lambda res: self._search_done(needle, res))

    def _search_done(self, needle: str, res: Dict[str, Any]) -> None:
        results = (res or {}).get("results") or []
        window = tk.Toplevel(self.root)
        window.title(f"Search: {needle}")
        window.configure(bg=self.c["panel"], padx=10, pady=10)
        tk.Label(window, text=f"{len(results)} results for \"{needle}\"", font=FONT_BOLD,
                 bg=self.c["panel"], fg=self.c["txt"]).pack(anchor="w", pady=(0, 8))
        frame = ScrollFrame(window, bg=self.c["bg"])
        frame.pack(fill="both", expand=True)
        for item in results:
            row = tk.Frame(frame.inner, bg=self.c["bg"], padx=8, pady=6, cursor="hand2")
            row.pack(fill="x", pady=1)
            title = item.get("title") or item.get("peer")
            snippet = (item.get("text") or "")[:110]
            tk.Label(row, text=V(title), font=FONT_BOLD,
                     bg=self.c["bg"], fg=self.c["txt"],
                     anchor="e" if is_rtl(title) else "w").pack(fill="x")
            tk.Label(row, text=V(snippet), font=FONT_SMALL,
                     bg=self.c["bg"], fg=self.c["muted"],
                     anchor="e" if is_rtl(snippet) else "w",
                     justify="right" if is_rtl(snippet) else "left").pack(fill="x")
            peer = item.get("peer")
            row.bind("<Button-1>", lambda e, p=peer, w=window: (w.destroy(), self._open_chat(p)))
            for child in row.winfo_children():
                child.bind("<Button-1>", lambda e, p=peer, w=window: (w.destroy(), self._open_chat(p)))

    def _show_members(self) -> None:
        if not self.active:
            return
        peer = self.active
        self._set_status("loading members...")
        self.bg(lambda: self.call(self._members(peer), timeout=60),
                lambda res: self._members_done(res))

    def _members_done(self, res: Dict[str, Any]) -> None:
        self._reset_status()
        members = (res or {}).get("members") or []
        window = tk.Toplevel(self.root)
        window.title("Members")
        window.geometry("380x460")
        window.configure(bg=self.c["panel"], padx=10, pady=10)
        tk.Label(window, text=f"Members ({len(members)})", font=FONT_BOLD,
                 bg=self.c["panel"], fg=self.c["txt"]).pack(anchor="w", pady=(0, 8))
        frame = ScrollFrame(window, bg=self.c["panel"])
        frame.pack(fill="both", expand=True)
        for member in members:
            row = tk.Frame(frame.inner, bg=self.c["panel"], padx=6, pady=5)
            row.pack(fill="x")
            avatar = tk.Canvas(row, width=32, height=32, bg=self.c["panel"],
                               highlightthickness=0)
            avatar.pack(side="left")
            name = member.get("name") or str(member.get("uid"))
            self._draw_avatar(avatar, name, self.c["accent"], 32)
            text = tk.Frame(row, bg=self.c["panel"])
            text.pack(side="left", fill="x", expand=True, padx=(8, 0))
            tk.Label(text, text=V(name), font=FONT_BOLD, bg=self.c["panel"], fg=self.c["txt"],
                     anchor="e" if is_rtl(name) else "w").pack(fill="x")
            role = member.get("title") if member.get("isAdmin") else ""
            if member.get("isAdmin") and not role:
                role = "admin"
            if role:
                tk.Label(text, text=V(str(role)), font=FONT_SMALL, bg=self.c["panel"],
                         fg=self.c["muted"], anchor="w").pack(fill="x")

    def _show_profile(self) -> None:
        if not self.active:
            return
        self._set_status("loading profile...")
        self.bg(lambda: self.call(self._profile(self.active)),
                lambda res: self._profile_done(res))

    def _profile_done(self, res: Dict[str, Any]) -> None:
        if (res or {}).get("error"):
            self._set_status(str(res["error"]))
            return
        text = (f"{V(res.get('title') or '')}\n\n"
                f"{'group' if res.get('isGroup') else res.get('subtitle') or 'user'}\n"
                f"{'members: ' + str(res.get('members')) if res.get('isGroup') else ''}\n"
                f"{V(res.get('about') or '')}\n\n"
                f"id: {res.get('id')}")
        messagebox.showinfo("Profile", text)
        self._reset_status()
        if res.get("isGroup") and messagebox.askyesno("Members", "Show the member list?"):
            self._show_members()


# --------------------------------------------------------------------------- cli
def run(client, demo: bool = False) -> None:
    """Entry point used by ``python run.py native``."""
    app = NativeApp(client, demo=demo)
    try:
        app.root.mainloop()
    finally:
        try:
            app.call(app.client.close(), timeout=5)
        except Exception:  # noqa: BLE001
            pass
