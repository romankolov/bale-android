"""
baleclient.transport - the wire protocol used by Bale.

Two channels are used by the official clients:

* **gRPC-web over HTTPS** for unauthenticated calls (the login flow):
  ``POST https://<host>/<service>/<method>`` with
  ``content-type: application/grpc-web+proto``, body = 5 byte frame header
  (flag + big endian length) followed by the protobuf message.

* **a protobuf framed WebSocket** for everything else:
  ``wss://<host>/ws/`` with ``Cookie: access_token=<jwt>``.

Every frame is one ``WsRequest``/``WsResponse`` protobuf (definitions below).
Both were recovered from the production bundle - see PROTOCOL.md.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import ssl
import struct
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Awaitable, Callable, Dict, List, Optional

from .proto import Codec, Reader, Writer, default_codec

# --------------------------------------------------------------------------- constants
HOSTS = ["next-ws.bale.ai", "maviz-ws.bale.ai", "beta-ws.bale.ai"]
DEFAULT_HOST = HOSTS[0]

APP_VERSION = "176652"          # web@5.8.0+176652
PROTOCOL_VERSION = 1            # handshake "mkprotoVersion"
APP_ID = 4                      # web
API_KEY = "C28D46DC4C3A7A26564BFCC48B929086A95C93C98E789A19847BEE8627DE4E7D"
ORIGIN = "https://web.bale.ai"
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36")

# metadata mirrors what the official web client sends with every call
META = {
    "app_version": APP_VERSION,
    "browser_type": "1",
    "browser_version": "138.0.0.0",
    "os_type": "3",
}


class BaleRpcError(Exception):
    """Raised when the server answers a call with a ``BaleError``."""

    def __init__(self, topic: int, message: str):
        super().__init__(f"[{topic}] {message}")
        self.topic = topic
        self.message = message


class TransportError(Exception):
    pass


# --------------------------------------------------------------------------- envelope
def _write_ext_value(w: Writer, value: str) -> None:
    inner = Writer()
    inner.bytes_field(1, value.encode())
    w.bytes_field(2, bytes(inner.buf))


def _write_metadata(w: Writer, meta: Dict[str, str]) -> None:
    lst = Writer()
    for key, value in meta.items():
        entry = Writer()
        entry.bytes_field(1, key.encode())
        _write_ext_value(entry, value)
        lst.bytes_field(1, bytes(entry.buf))
    w.bytes_field(4, bytes(lst.buf))


def encode_request_body(service: str, method: str, payload: bytes,
                        request_id: int, meta: Optional[Dict[str, str]] = None) -> bytes:
    body = Writer()
    body.bytes_field(1, service.encode())
    body.bytes_field(2, method.encode())
    body.bytes_field(3, payload)
    _write_metadata(body, meta or META)
    body.varint((5 << 3) | 0)
    body.varint(request_id)
    req = Writer()
    req.bytes_field(1, bytes(body.buf))
    return bytes(req.buf)


def encode_ping(ident: int) -> bytes:
    ping = Writer()
    ping.varint((1 << 3) | 0)
    ping.varint(ident)
    req = Writer()
    req.bytes_field(2, bytes(ping.buf))
    return bytes(req.buf)


def encode_handshake() -> bytes:
    hs = Writer()
    hs.varint((1 << 3) | 0)
    hs.varint(PROTOCOL_VERSION)
    hs.varint((2 << 3) | 0)
    hs.varint(int(APP_VERSION))
    req = Writer()
    req.bytes_field(3, bytes(hs.buf))
    return bytes(req.buf)


def decode_frame(codec: Codec, data: bytes) -> Dict[str, Any]:
    """Decode a ``WsResponse`` into a plain dict."""
    r = Reader(data)
    out: Dict[str, Any] = {}
    while r.remaining:
        key = r.varint()
        number, wire = key >> 3, key & 7
        if wire == 2:
            raw = r.take(r.varint())
        elif wire == 0:
            raw = r.varint()
        elif wire == 1:
            raw = r.take(8)
        elif wire == 5:
            raw = r.take(4)
        else:
            break

        if number == 1:  # response body
            out["response"] = _decode_response_body(raw)
        elif number == 2:  # update
            out["update"] = _decode_update(raw)
        elif number == 3:
            out["terminate_session"] = raw
        elif number == 4:  # pong
            pong = _first_varint_field(raw, 1)
            out["pong"] = pong
        elif number == 5:  # handshake response
            out["handshake"] = _decode_handshake_response(raw)
    return out


def _first_varint_field(data: bytes, wanted: int) -> Optional[int]:
    r = Reader(data)
    while r.remaining:
        key = r.varint()
        number, wire = key >> 3, key & 7
        if wire == 0:
            val = r.varint()
            if number == wanted:
                return val
        elif wire == 2:
            r.take(r.varint())
        elif wire == 1:
            r.take(8)
        elif wire == 5:
            r.take(4)
        else:
            return None
    return None


def _decode_response_body(data: bytes) -> Dict[str, Any]:
    r = Reader(data)
    out: Dict[str, Any] = {}
    while r.remaining:
        key = r.varint()
        number, wire = key >> 3, key & 7
        if wire == 2:
            raw = r.take(r.varint())
        elif wire == 0:
            raw = r.varint()
        elif wire == 1:
            raw = r.take(8)
        elif wire == 5:
            raw = r.take(4)
        else:
            break
        if number == 1:
            er = Reader(raw)
            topic, message = 0, ""
            while er.remaining:
                k = er.varint()
                n2, w2 = k >> 3, k & 7
                if w2 == 0:
                    v = er.varint()
                    if n2 == 1:
                        topic = v
                elif w2 == 2:
                    v = er.take(er.varint())
                    if n2 == 2:
                        message = v.decode("utf-8", "replace")
                elif w2 == 1:
                    er.take(8)
                elif w2 == 5:
                    er.take(4)
                else:
                    break
            out["error"] = {"topic": topic, "message": message}
        elif number == 2:
            out["result"] = raw
        elif number == 3:
            out["number"] = raw
    return out


def _decode_update(data: bytes) -> Dict[str, Any]:
    """Update{ update = 1 bytes } - the payload is an UpdateBody."""
    r = Reader(data)
    while r.remaining:
        key = r.varint()
        number, wire = key >> 3, key & 7
        if wire == 2:
            raw = r.take(r.varint())
            if number == 1:
                return {"body": raw}
        elif wire == 0:
            r.varint()
        elif wire == 1:
            r.take(8)
        elif wire == 5:
            r.take(4)
        else:
            break
    return {}


def _decode_handshake_response(data: bytes) -> Dict[str, Any]:
    r = Reader(data)
    out = {"mkprotoVersion": 0, "apiVersion": 0, "serverTime": 0}
    while r.remaining:
        key = r.varint()
        number, wire = key >> 3, key & 7
        if wire == 0:
            val = r.varint()
            if number == 1:
                out["mkprotoVersion"] = val
            elif number == 2:
                out["apiVersion"] = val
            elif number == 3:
                out["serverTime"] = val
        elif wire == 2:
            r.take(r.varint())
        elif wire == 1:
            r.take(8)
        elif wire == 5:
            r.take(4)
        else:
            break
    return out


# --------------------------------------------------------------------------- transport
class Transport:
    """HTTP (gRPC-web) + WebSocket transport for the Bale protocol."""

    def __init__(self, host: str = DEFAULT_HOST, token: Optional[str] = None,
                 proxy: Optional[str] = None, codec: Optional[Codec] = None,
                 debug: bool = False):
        self.host = host
        self.token = token
        self.proxy = proxy or os.environ.get("BALE_PROXY") or os.environ.get("HTTPS_PROXY")
        self.codec = codec or default_codec()
        self.debug = debug
        self.ws = None
        self._request_id = 0
        self._pending: Dict[int, asyncio.Future] = {}
        self._reader_task: Optional[asyncio.Task] = None
        self._ping_task: Optional[asyncio.Task] = None
        self.update_callback: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None
        self.on_close: Optional[Callable[[int, str], None]] = None
        self.handshake_result: Optional[Dict[str, Any]] = None
        self.auto_reconnect = True
        self._closing = False
        self._reconnect_task: Optional[asyncio.Task] = None

    # -- helpers -----------------------------------------------------------
    def _headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        h = {
            "Origin": ORIGIN,
            "User-Agent": USER_AGENT,
        }
        for key, value in META.items():
            h[key] = value
            h["mt_" + key] = value
        if self.token:
            h["Cookie"] = f"access_token={self.token}"
        if extra:
            h.update(extra)
        return h

    def next_request_id(self) -> int:
        self._request_id += 1
        return self._request_id

    # -- gRPC-web ----------------------------------------------------------
    def _post_sync(self, url: str, body: bytes, headers: Dict[str, str]) -> tuple:
        handlers: List[Any] = []
        if self.proxy:
            handlers.append(urllib.request.ProxyHandler({
                "http": self.proxy, "https": self.proxy}))
        opener = urllib.request.build_opener(*handlers)
        req = urllib.request.Request(url, data=body, method="POST", headers=headers)
        try:
            resp = opener.open(req, timeout=30)
            return resp.status, dict(resp.headers), resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, dict(exc.headers), exc.read()

    async def post(self, service: str, method: str, payload: bytes,
                   token: Optional[str] = None, raw: bool = False) -> Any:
        """gRPC-web unary call.  Returns decoded payload bytes (or str error)."""
        saved, self.token = self.token, token or self.token
        try:
            headers = self._headers({"content-type": "application/grpc-web+proto"})
            body = b"\x00" + struct.pack(">I", len(payload)) + payload
            url = f"https://{self.host}/{service}/{method}"
            status, hdrs, data = await asyncio.to_thread(self._post_sync, url, body, headers)
        finally:
            self.token = saved

        if self.debug:
            print(f"[grpc] {method} -> {status} {dict((k, v) for k, v in hdrs.items() if 'grpc' in k.lower())}")

        message = hdrs.get("grpc-message") or hdrs.get("Grpc-Message")
        if message is not None:
            raise BaleRpcError(-1, urllib.parse.unquote(message))
        if status != 200:
            raise TransportError(f"HTTP {status} for {service}/{method}")
        payload_bytes = _strip_grpc_frames(data)
        if raw:
            return payload_bytes
        return payload_bytes

    def _put_sync(self, url: str, data: bytes, mime: str,
                  headers: Optional[Dict[str, str]] = None) -> int:
        handlers: List[Any] = []
        if self.proxy:
            handlers.append(urllib.request.ProxyHandler({
                "http": self.proxy, "https": self.proxy}))
        opener = urllib.request.build_opener(*handlers)
        # The official uploader always PUTs with multipart/form-data, even for
        # a single chunk (see transport.uploadFile in the bundle).
        all_headers = {"Content-Type": "multipart/form-data",
                       "Origin": ORIGIN,
                       "User-Agent": USER_AGENT}
        all_headers.update(headers or {})
        req = urllib.request.Request(url, data=data if data else None,
                                     method="PUT", headers=all_headers)
        with opener.open(req, timeout=180) as resp:
            return resp.status

    async def put(self, url: str, data: bytes, mime: str,
                  headers: Optional[Dict[str, str]] = None) -> None:
        """PUT raw bytes to the upload URL the Files service handed out.

        Multi-chunk uploads pass ``{"chunk": index, "no": total}`` headers and an
        empty body for the final confirmation, exactly like the web client.
        """
        status = await asyncio.to_thread(self._put_sync, url, data, mime, headers)
        if not (200 <= int(status) < 300):
            raise TransportError(f"upload failed with HTTP {status}")

    def _get_sync(self, url: str) -> bytes:
        handlers: List[Any] = []
        if self.proxy:
            handlers.append(urllib.request.ProxyHandler({
                "http": self.proxy, "https": self.proxy}))
        opener = urllib.request.build_opener(*handlers)
        req = urllib.request.Request(url, headers={"Origin": ORIGIN,
                                                   "User-Agent": USER_AGENT})
        with opener.open(req, timeout=120) as resp:
            return resp.read()

    async def fetch(self, url: str) -> bytes:
        """GET a (temporary) file URL."""
        return await asyncio.to_thread(self._get_sync, url)

    # -- websocket ---------------------------------------------------------
    async def connect(self, token: Optional[str] = None) -> None:
        token = token or self.token
        if not token:
            raise TransportError("a token is required to open the websocket")
        self.token = token

        try:
            import websockets  # type: ignore
        except ImportError as exc:  # pragma: no cover
            raise TransportError(
                "the 'websockets' package is required: pip install websockets"
            ) from exc

        url = f"wss://{self.host}/ws/"
        headers = self._headers()
        self.handshake_result = None
        kwargs: Dict[str, Any] = {"additional_headers": headers, "user_agent_header": None}
        try:
            self.ws = await websockets.connect(url, **kwargs)
        except TypeError:  # websockets < 13
            kwargs.pop("user_agent_header", None)
            kwargs["extra_headers"] = kwargs.pop("additional_headers")
            self.ws = await websockets.connect(url, **kwargs)

        self._reader_task = asyncio.create_task(self._reader_loop())
        await self._handshake()
        self._ping_task = asyncio.create_task(self._ping_loop())

    async def _handshake(self, timeout: float = 10.0) -> Dict[str, Any]:
        await self.ws.send(encode_handshake())
        deadline = asyncio.get_event_loop().time() + timeout
        while self.handshake_result is None:
            if asyncio.get_event_loop().time() > deadline:
                raise TransportError("handshake timed out")
            await asyncio.sleep(0.02)
        return self.handshake_result

    async def _ping_loop(self, interval: float = 20.0) -> None:
        try:
            while True:
                await asyncio.sleep(interval)
                await self.ws.send(encode_ping(self.next_request_id()))
        except asyncio.CancelledError:
            return
        except Exception:
            return

    async def _reader_loop(self) -> None:
        try:
            async for message in self.ws:
                if isinstance(message, str):
                    continue
                frame = decode_frame(self.codec, message)
                await self._dispatch(frame)
        except asyncio.CancelledError:
            pass
        except Exception as exc:  # pragma: no cover
            if self.debug:
                print(f"[ws] reader stopped: {exc!r}")
        finally:
            code = getattr(self.ws, "close_code", None) or 0
            reason = getattr(self.ws, "close_reason", "") or ""
            for fut in list(self._pending.values()):
                if not fut.done():
                    fut.set_exception(TransportError("connection closed"))
            self._pending.clear()
            if self.on_close:
                self.on_close(code, reason)
            if self.auto_reconnect and not self._closing and code != 4401:
                self._reconnect_task = asyncio.create_task(self._reconnect(code))

    async def _reconnect(self, code: int = 0) -> None:
        """Exponential backoff reconnect, like the web client (100ms -> 3s)."""
        delay = 0.2
        attempt = 0
        while not self._closing and self.auto_reconnect:
            attempt += 1
            await asyncio.sleep(delay)
            delay = min(delay * 2, 3.0)
            try:
                if self.debug:
                    print(f"[ws] reconnecting (attempt {attempt})")
                await self.connect(self.token)
                if self.debug:
                    print("[ws] reconnected")
                return
            except Exception as exc:  # noqa: BLE001
                if self.debug:
                    print(f"[ws] reconnect failed: {exc!r}")
        return

    async def _dispatch(self, frame: Dict[str, Any]) -> None:
        if "handshake" in frame:
            self.handshake_result = frame["handshake"]
            return
        if "pong" in frame:
            return
        if "update" in frame and self.update_callback:
            body = self.codec.decode_quiet("Update",
                                           frame["update"].get("body", b""))
            await self.update_callback(body)
            return
        response = frame.get("response")
        if not response:
            return
        number = response.get("number")
        fut = self._pending.pop(number, None) if number is not None else None
        if fut is None or fut.done():
            return
        if response.get("error"):
            fut.set_exception(BaleRpcError(response["error"]["topic"],
                                           response["error"]["message"]))
        else:
            fut.set_result(response.get("result", b""))

    async def call(self, service: str, method: str, payload: bytes,
                   timeout: float = 20.0) -> bytes:
        if self.ws is None:
            raise TransportError("websocket is not connected")
        rid = self.next_request_id()
        fut: asyncio.Future = asyncio.get_event_loop().create_future()
        self._pending[rid] = fut
        await self.ws.send(encode_request_body(service, method, payload, rid))
        try:
            return await asyncio.wait_for(fut, timeout)
        finally:
            self._pending.pop(rid, None)

    async def close(self) -> None:
        self._closing = True
        self.auto_reconnect = False
        if self._reconnect_task:
            self._reconnect_task.cancel()
        for task in (self._ping_task, self._reader_task):
            if task:
                task.cancel()
        if self.ws is not None:
            try:
                await self.ws.close()
            except Exception:
                pass
            self.ws = None


def _strip_grpc_frames(data: bytes) -> bytes:
    """Remove gRPC-web frame headers and trailers, returning the message body."""
    out = bytearray()
    pos = 0
    while pos + 5 <= len(data):
        flags = data[pos]
        length = struct.unpack(">I", data[pos + 1:pos + 5])[0]
        chunk = data[pos + 5:pos + 5 + length]
        pos += 5 + length
        if flags & 0x80:  # trailer frame
            continue
        out += chunk
    return bytes(out)
