"""baleclient - an unofficial, from-scratch Python client for the Bale messenger."""
from .client import BaleClient, Chat, Message, Peer
from .proto import Codec, Schema, default_codec
from .transport import BaleRpcError, Transport, TransportError

__version__ = "1.0.0"
__all__ = [
    "BaleClient", "Peer", "Chat", "Message",
    "Codec", "Schema", "default_codec",
    "Transport", "BaleRpcError", "TransportError",
]
