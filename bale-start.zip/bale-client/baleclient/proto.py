"""
baleclient.proto - a dependency free, schema driven protobuf codec.

The schema was recovered from the compiled Bale web client with
``tools/extract_protos.py`` (see PROTOCOL.md).  Every message is described as

    "Name": {number: (field_name, type, repeated)}

where *type* is either a protobuf scalar name or the name of another message
in the same schema.  Fields the extractor could not resolve are kept as raw
``bytes`` so that unknown data survives a decode/encode round trip.
"""
from __future__ import annotations

import json
import os
import struct
from typing import Any, Dict, Iterable, List, Optional, Tuple

VARINT_TYPES = {
    "int32", "int64", "uint32", "uint64", "sint32", "sint64", "bool", "enum",
}
FIXED64_TYPES = {"fixed64", "sfixed64", "double"}
FIXED32_TYPES = {"fixed32", "sfixed32", "float"}
LENGTH_TYPES = {"string", "bytes"}
SCALARS = VARINT_TYPES | FIXED64_TYPES | FIXED32_TYPES | LENGTH_TYPES
PACKABLE = VARINT_TYPES | FIXED64_TYPES | FIXED32_TYPES

_MASK = (1 << 64) - 1


# --------------------------------------------------------------------------- schema
class Field:
    __slots__ = ("number", "name", "type", "repeated", "is_message", "packed")

    def __init__(self, number: int, name: str, type_: str, repeated: bool,
                 is_message: bool, packed: bool = False):
        self.number = number
        self.name = name
        self.type = type_
        self.repeated = repeated
        self.is_message = is_message
        self.packed = packed

    def __repr__(self) -> str:  # pragma: no cover
        rep = "repeated " if self.repeated else ""
        return f"<Field {rep}{self.type} {self.name} = {self.number}>"


class Schema:
    """Message definitions, indexed by name."""

    def __init__(self, messages: Dict[str, Dict[int, Tuple[str, str, bool]]]):
        self.raw = messages
        self.by_name: Dict[str, Dict[int, Field]] = {}
        for name, fields in messages.items():
            out: Dict[int, Field] = {}
            for num, spec in fields.items():
                fname, ftype, repeated = spec
                is_msg = ftype not in SCALARS
                out[int(num)] = Field(int(num), fname, ftype, bool(repeated), is_msg)
            self.by_name[name] = out

    # -- lookup ------------------------------------------------------------
    def has(self, name: str) -> bool:
        return name in self.by_name

    def fields(self, name: str) -> Dict[int, Field]:
        return self.by_name.get(name, {})

    def field(self, message: str, field_name: str) -> Optional[Field]:
        for f in self.fields(message).values():
            if f.name == field_name:
                return f
        return None

    def message_for(self, message: str, field_name: str) -> Optional[str]:
        f = self.field(message, field_name)
        if f and f.is_message and f.type in self.by_name:
            return f.type
        return None

    # -- loading -----------------------------------------------------------
    @classmethod
    def from_schema_json(cls, path: str) -> "Schema":
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        out: Dict[str, Dict[int, Tuple[str, str, bool]]] = {}
        for name, fields in data["messages"].items():
            spec: Dict[int, Tuple[str, str, bool]] = {}
            for num, (fname, ftype, repeated) in fields.items():
                spec[int(num)] = (fname, ftype, bool(repeated))
            out[name] = spec
        return cls(out)

    @classmethod
    def default(cls) -> "Schema":
        here = os.path.dirname(os.path.abspath(__file__))
        return cls.from_schema_json(os.path.join(here, "schema.json"))


def _ref_name(data: dict, ref: List[str]) -> str:
    key = (ref[0], ref[1])
    return data.get("_ref_names", {}).get(f"{key[0]}::{key[1]}", "bytes")


# --------------------------------------------------------------------------- writer
class Writer:
    def __init__(self) -> None:
        self.buf = bytearray()

    def varint(self, value: int) -> None:
        if value < 0:
            value += 1 << 64
        value &= _MASK
        while True:
            b = value & 0x7F
            value >>= 7
            if value:
                self.buf.append(b | 0x80)
            else:
                self.buf.append(b)
                return

    def tag(self, number: int, wire: int) -> None:
        self.varint((number << 3) | wire)

    def raw(self, data: bytes) -> None:
        self.buf += data

    def bytes_field(self, number: int, data: bytes) -> None:
        self.tag(number, 2)
        self.varint(len(data))
        self.buf += data

    def value(self, number: int, type_: str, val: Any) -> None:
        if type_ in ("int32", "int64", "uint32", "uint64", "enum", "bool"):
            self.tag(number, 0)
            self.varint(int(val))
        elif type_ in ("sint32", "sint64"):
            n = int(val)
            self.tag(number, 0)
            self.varint((n << 1) ^ (n >> 63) if type_ == "sint64" else (n << 1) ^ (n >> 31))
        elif type_ == "fixed64":
            self.tag(number, 1)
            self.buf += struct.pack("<Q", int(val) & _MASK)
        elif type_ == "sfixed64":
            self.tag(number, 1)
            self.buf += struct.pack("<q", int(val))
        elif type_ == "double":
            self.tag(number, 1)
            self.buf += struct.pack("<d", float(val))
        elif type_ == "fixed32":
            self.tag(number, 5)
            self.buf += struct.pack("<I", int(val) & 0xFFFFFFFF)
        elif type_ == "sfixed32":
            self.tag(number, 5)
            self.buf += struct.pack("<i", int(val))
        elif type_ == "float":
            self.tag(number, 5)
            self.buf += struct.pack("<f", float(val))
        elif type_ == "string":
            self.bytes_field(number, val.encode("utf-8") if isinstance(val, str) else val)
        elif type_ == "bytes":
            self.bytes_field(number, bytes(val))


# --------------------------------------------------------------------------- reader
class Reader:
    def __init__(self, data: bytes):
        self.data = memoryview(data)
        self.pos = 0

    @property
    def remaining(self) -> int:
        return len(self.data) - self.pos

    def varint(self) -> int:
        shift = 0
        result = 0
        while True:
            if self.pos >= len(self.data):
                raise ValueError("truncated varint")
            b = self.data[self.pos]
            self.pos += 1
            result |= (b & 0x7F) << shift
            if not b & 0x80:
                return result
            shift += 7
            if shift > 70:
                raise ValueError("varint too long")

    def take(self, n: int) -> bytes:
        if self.pos + n > len(self.data):
            raise ValueError("truncated buffer")
        out = bytes(self.data[self.pos:self.pos + n])
        self.pos += n
        return out


# --------------------------------------------------------------------------- codec
class Codec:
    """Encodes/decodes python dicts using a :class:`Schema`."""

    def __init__(self, schema: Schema):
        self.schema = schema

    # -- encode ------------------------------------------------------------
    def encode(self, message: str, obj: Dict[str, Any]) -> bytes:
        w = Writer()
        fields = self.schema.fields(message)
        by_name = {f.name: f for f in fields.values()}
        for name, value in (obj or {}).items():
            if value is None:
                continue
            f = by_name.get(name)
            if f is None:
                continue  # unknown key - ignore
            if f.repeated:
                for item in value:
                    if item is None:
                        continue
                    self._encode_one(w, f, item, message)
            else:
                self._encode_one(w, f, value, message)
        return bytes(w.buf)

    def _encode_one(self, w: Writer, f: Field, value: Any, parent: str) -> None:
        if f.is_message:
            if isinstance(value, (bytes, bytearray)):
                w.bytes_field(f.number, bytes(value))
                return
            data = self.encode(f.type, value)
            w.bytes_field(f.number, data)
        else:
            w.value(f.number, f.type, value)

    # -- decode ------------------------------------------------------------
    def decode_quiet(self, message: str, data: bytes) -> Dict[str, Any]:
        try:
            return self.decode(message, data)
        except Exception:
            return {"_raw": data}

    def decode(self, message: str, data: bytes) -> Dict[str, Any]:
        fields = self.schema.fields(message)
        if not fields:
            return {"_raw": data}
        r = Reader(data)
        out: Dict[str, Any] = {}
        unknown: List[Tuple[int, int, Any]] = []
        while r.remaining:
            key = r.varint()
            number, wire = key >> 3, key & 7
            if number == 0:
                break
            f = fields.get(number)
            if wire == 0:
                val: Any = r.varint()
            elif wire == 1:
                val = r.take(8)
            elif wire == 2:
                val = r.take(r.varint())
            elif wire == 5:
                val = r.take(4)
            else:  # pragma: no cover - groups are not used by bale
                raise ValueError(f"unsupported wire type {wire}")

            if f is None:
                unknown.append((number, wire, val))
                continue

            if f.repeated and f.packed and wire == 2 and f.type in PACKABLE:
                out.setdefault(f.name, []).extend(self._unpack(f.type, val))
                continue

            value = self._decode_value(f, wire, val)
            if f.repeated:
                out.setdefault(f.name, []).append(value)
            else:
                out[f.name] = value
        if unknown:
            out["_unknown"] = unknown
        return out

    def _decode_value(self, f: Field, wire: int, val: Any) -> Any:
        if f.is_message:
            if f.type in self.schema.by_name:
                return self.decode(f.type, val)
            return val
        if f.type in ("string",):
            return val.decode("utf-8", "replace")
        if f.type == "bytes":
            return val
        return self._scalar(f.type, wire, val)

    @staticmethod
    def _scalar(type_: str, wire: int, raw: Any) -> Any:
        if type_ == "bool":
            return bool(raw)
        if type_ in ("int32", "int64", "uint32", "uint64", "enum"):
            if type_ in ("int32", "int64") and raw >> 63:
                raw -= 1 << 64
            return raw
        if type_ == "sint32":
            return (raw >> 1) ^ -(raw & 1)
        if type_ == "sint64":
            n = (raw >> 1) ^ -(raw & 1)
            return n
        if type_ == "fixed64":
            return struct.unpack("<Q", raw)[0]
        if type_ == "sfixed64":
            return struct.unpack("<q", raw)[0]
        if type_ == "double":
            return struct.unpack("<d", raw)[0]
        if type_ == "fixed32":
            return struct.unpack("<I", raw)[0]
        if type_ == "sfixed32":
            return struct.unpack("<i", raw)[0]
        if type_ == "float":
            return struct.unpack("<f", raw)[0]
        return raw

    def _unpack(self, type_: str, data: bytes) -> Iterable[Any]:
        r = Reader(data)
        while r.remaining:
            if type_ in FIXED64_TYPES:
                raw = r.take(8)
                wire = 1
            elif type_ in FIXED32_TYPES:
                raw = r.take(4)
                wire = 5
            else:
                raw = r.varint()
                wire = 0
            yield self._scalar(type_, wire, raw)


_default: Optional[Codec] = None


def default_codec() -> Codec:
    global _default
    if _default is None:
        _default = Codec(Schema.default())
    return _default
