"""
baleclient.cli - a small terminal client (the "usable like a real one" part).

    python run.py login          # interactive phone + SMS code login, then chat
    python run.py chats          # list recent chats
    python run.py history g:123  # show a conversation
    python run.py send u:456 "hello"
    python run.py listen         # live incoming messages
    python run.py repl           # interactive shell (uses the saved session)
    python run.py demo           # show raw protocol frames, no account needed
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Any, Dict, List, Optional

from .client import BaleClient, Chat, Message, Peer
from .transport import BaleRpcError, TransportError


# --------------------------------------------------------------------------- formatting
def _fmt_chat(index: int, chat: Chat) -> str:
    unread = f" ({chat.unread} new)" if chat.unread else ""
    preview = (chat.last_text or "").replace("\n", " ")[:44]
    kind = "group" if chat.is_group else "user "
    return f"{index:>3}. [{kind}] {chat.title[:26]:<28}{unread:<8} {preview}"


def _fmt_message(msg: Message, my_id: Optional[int]) -> str:
    who = "me" if my_id and msg.sender_uid == my_id else str(msg.sender_uid)
    text = msg.text or f"<{msg.kind}>"
    return f"[{msg.time}] {who:>12}: {text}"


def _text_of(message_union: Dict[str, Any]) -> str:
    """Pull readable text out of a Message2/Message3 content union."""
    if not isinstance(message_union, dict):
        return ""
    for key in ("textMessage", "longTextMessage", "serviceMessage"):
        value = message_union.get(key)
        if isinstance(value, dict):
            return value.get("text", "") or ""
    for key, value in message_union.items():
        if isinstance(value, dict) and key not in ("_unknown",):
            return f"<{key.replace('Message', '').lower()}>"
    return ""


# --------------------------------------------------------------------------- commands
async def cmd_login(args: argparse.Namespace) -> None:
    async with BaleClient(host=args.host, session_path=args.session,
                          debug=args.debug) as bale:
        info = await bale.login(args.phone, force=args.force)
        person = info.get("user") or {}
        print(f"logged in as {person.get('name')} (id={person.get('id')})")
        print("session saved:", bale.session_file)
        exp = bale.jwt_expiry()
        if exp:
            import time as _t
            print(f"jwt expires in {max(0, exp - int(_t.time())) // 3600}h "
                  f"({_t.strftime('%Y-%m-%d %H:%M', _t.localtime(exp))})")
        await _connect(bale)
        print("handshake ok:", bale.transport.handshake_result)
        if args.no_repl:
            print("session saved - run 'python run.py repl' to chat")
            return
        await _repl(bale)


async def cmd_chats(args: argparse.Namespace) -> None:
    async with BaleClient(host=args.host, session_path=args.session,
                          debug=args.debug) as bale:
        await bale.connect()
        chats = await bale.load_dialogs(limit=args.limit)
        print(f"{'#':>3}  {'peer':<14} title{'':<25} last message")
        print("-" * 86)
        for i, chat in enumerate(chats, 1):
            unread = f"({chat.unread}) " if chat.unread else ""
            print(f"{i:>3}  {chat.peer.key:<14} {unread}{chat.title[:28]:<30} "
                  f"{(chat.last_text or '')[:34]}")


async def cmd_history(args: argparse.Namespace) -> None:
    peer = Peer.parse(args.peer)
    async with BaleClient(host=args.host, session_path=args.session,
                          debug=args.debug) as bale:
        await bale.connect()
        messages = await bale.load_history(peer, limit=args.limit)
        my_id = (bale.me or {}).get("id")
        for msg in messages:
            print(_fmt_message(msg, my_id))


async def cmd_send(args: argparse.Namespace) -> None:
    peer = Peer.parse(args.peer)
    async with BaleClient(host=args.host, session_path=args.session,
                          debug=args.debug) as bale:
        await bale.connect()
        resp = await bale.send_text(peer, args.text)
        print("sent:", resp if resp else "ok")


async def cmd_listen(args: argparse.Namespace) -> None:
    async with BaleClient(host=args.host, session_path=args.session,
                          debug=args.debug) as bale:
        await bale.connect()
        print("listening for updates (ctrl-c to stop) ...")

        async def handler(kind: str, payload: Any) -> None:
            if kind == "message" and isinstance(payload, dict):
                peer = payload.get("peer") or {}
                text = _text_of(payload.get("message") or {})
                print(f"\n[new] {peer.get('type')}:{peer.get('id')} "
                      f"uid={payload.get('senderUid')} -> {text}")
            elif kind == "message_sent":
                print(f"\n[message_sent] {payload}")
            elif kind == "typing":
                print("\n[typing] ...")
            elif kind != "empty_update":
                print(f"\n[{kind}] {str(payload)[:160]}")

        await bale.listen(handler)


async def cmd_repl(args: argparse.Namespace) -> None:
    async with BaleClient(host=args.host, session_path=args.session,
                          debug=args.debug) as bale:
        await _connect(bale)
        await _repl(bale)


async def _connect(bale: BaleClient) -> None:
    try:
        await bale.connect()
    except TransportError as exc:
        message = str(exc).lower()
        if "handshake" in message or "closed" in message or "4401" in message:
            print("could not open the session - it is probably expired.\n"
                  "run:  python run.py login --force")
        raise


# --------------------------------------------------------------------------- the chat UI
async def _repl(bale: BaleClient) -> None:
    me = bale.me or {}
    print(f"\nconnected as {me.get('name')} (id={me.get('id')})")
    print("loading chats ...")
    try:
        chats = await bale.load_dialogs(limit=60)
    except Exception as exc:  # noqa: BLE001
        print(f"could not load chats: {exc}")
        chats = []

    by_peer: Dict[str, Chat] = {c.peer.key: c for c in chats}
    for i, chat in enumerate(chats[:30], 1):
        print(_fmt_chat(i, chat))
    print("""
commands
  /open <number|peer>   open a chat (number from the list, or u:123 / g:456)
  /chats                refresh the chat list
  /read                 reload the open chat
  /send <text>          send to the open chat
  /me                   who am I
  /quit                 exit
  anything else         sent to the open chat
""")

    current: Optional[Peer] = None

    async def on_update(kind: str, payload: Any) -> None:
        if kind != "message" or not isinstance(payload, dict):
            return
        peer = payload.get("peer") or {}
        key = f"{'g' if int(peer.get('type', 0)) == 2 else 'u'}:{peer.get('id')}"
        text = _text_of(payload.get("message") or {})
        name = by_peer.get(key)
        title = name.title if name else key
        print(f"\n<< {title}: {text}\n> ", end="", flush=True)

    listener = asyncio.create_task(bale.listen(on_update))

    try:
        while True:
            try:
                line = await asyncio.to_thread(input, "> ")
            except (EOFError, KeyboardInterrupt):
                break
            line = line.strip()
            if not line:
                continue

            if line in ("/quit", "/exit", "/q"):
                break
            if line == "/me":
                print(bale.me)
                continue
            if line == "/chats":
                try:
                    chats = await bale.load_dialogs(limit=60)
                except Exception as exc:  # noqa: BLE001
                    print("error:", exc)
                    continue
                if not chats:
                    print("no dialogs returned - try:  py run.py probe")
                by_peer = {c.peer.key: c for c in chats}
                for i, chat in enumerate(chats[:30], 1):
                    print(_fmt_chat(i, chat))
                continue
            if line.startswith("/open"):
                arg = line[5:].strip()
                if not arg:
                    print("usage: /open <number|u:id|g:id>")
                    continue
                if arg.isdigit() and 1 <= int(arg) <= len(chats):
                    current = chats[int(arg) - 1].peer
                else:
                    current = Peer.parse(arg)
                chat = by_peer.get(current.key)
                print(f"--- {chat.title if chat else current} ---")
                try:
                    await _show_history(bale, current, limit=30, chat=chat)
                    if chat and chat.date:
                        await bale.message_read(current, chat.date)
                except BaleRpcError as exc:
                    print("error:", exc)
                continue
            if line == "/read":
                if current is None:
                    print("open a chat first")
                    continue
                try:
                    await _show_history(bale, current, limit=60)
                except BaleRpcError as exc:
                    print("error:", exc)
                continue

            text = line[6:] if line.startswith("/send ") else line
            if current is None:
                print("open a chat first:  /open 1")
                continue
            try:
                await bale.send_text(current, text)
                print("sent")
            except BaleRpcError as exc:
                print("error:", exc)
    finally:
        listener.cancel()
        try:
            await listener
        except (asyncio.CancelledError, Exception):
            pass


async def _show_history(bale: BaleClient, peer: Peer, limit: int = 30,
                        chat: Optional[Chat] = None) -> None:
    """Print a conversation using the client's user/group name cache."""
    messages = await bale.load_history(peer, limit=limit)
    if not messages:
        print("(no messages returned by the server)")
        return
    my_id = (bale.me or {}).get("id")
    for msg in messages:
        who = "me" if my_id and msg.sender_uid == my_id else \
            bale.display_name(1, msg.sender_uid)
        print(f"[{msg.time}] {who[:22]:>22}: {msg.text or _kind_label(msg.kind)}")


def _kind_label(kind: str) -> str:
    return {
        "document": "[document]",
        "template": "[template message]",
        "sticker": "[sticker]",
        "animatedsticker": "[animated sticker]",
        "service": "[service]",
        "empty": "",
        "unknown": "[unsupported]",
    }.get(kind, f"[{kind}]")


def _now_ms() -> int:
    import time
    return int(time.time() * 1000)


async def cmd_demo(args: argparse.Namespace) -> None:
    """Print the exact bytes this client puts on the wire (no account needed)."""
    from .transport import encode_handshake, encode_ping, encode_request_body
    from .proto import default_codec

    print("--- handshake frame (client -> server) ---")
    print(encode_handshake().hex(" "))
    print("    = WsRequest{ handshakeRequest: { mkprotoVersion: 1, apiVersion: 176652 } }")

    print("\n--- ping frame ---")
    print(encode_ping(7).hex(" "))
    print("    = WsRequest{ ping: { ID: 7 } }")

    codec = default_codec()
    payload = codec.encode("Messaging_SendMessage_Request", {
        "peer": {"type": 1, "id": 42},
        "rid": 123456789,
        "message": {"textMessage": {"text": "hello from a custom client"}},
    })
    print("\n--- SendMessage payload ---")
    print(payload.hex(" "))

    frame = encode_request_body("bale.messaging.v2.Messaging", "SendMessage", payload, 9)
    print("\n--- full WsRequest carrying it ---")
    print(frame.hex(" "))

    print("\n--- decoded back ---")
    print(codec.decode("Messaging_SendMessage_Request", payload))

    sample_update = codec.encode("Update", {
        "message": {"peer": {"type": 1, "id": 42}, "senderUid": 42,
                    "date": 1766520000000, "rid": 5,
                    "message": {"textMessage": {"text": "incoming!"}}}})
    print("\n--- an UpdateBody the server would push (decoded) ---")
    print(codec.decode("Update", sample_update))


def cmd_gui(args: argparse.Namespace) -> None:
    from .webui import serve
    serve(host=args.bind, port=args.port, demo=args.demo,
          session=args.session, open_browser=not args.no_browser)


def cmd_native(args: argparse.Namespace) -> None:
    from .tkgui import run
    run(BaleClient(host=args.host, session_path=args.session or None,
                   debug=args.debug), demo=args.demo)


async def cmd_probe(args: argparse.Namespace) -> None:
    """Diagnose a session: dump exactly what the server answers, as raw hex."""
    import os
    from .client import DEFAULT_SESSION

    path = args.session or DEFAULT_SESSION
    print("session file :", os.path.expanduser(path),
          "(exists)" if os.path.exists(os.path.expanduser(path)) else "(MISSING)")

    bale = BaleClient(host=args.host, session_path=path, debug=False)
    token = bale.token or (bale.state or {}).get("token")
    if not token:
        print("no token in the session - run:  python run.py login --force")
        return
    print("token        :", token[:14] + "..." + token[-6:], f"({len(token)} chars)")
    exp = bale.jwt_expiry()
    if exp:
        import time as _t
        left = exp - int(_t.time())
        print(f"jwt expiry   : {_t.strftime('%Y-%m-%d %H:%M', _t.localtime(exp))} "
              f"({left // 3600}h left)")

    async with bale:
        await bale.connect()
        print("handshake    :", bale.transport.handshake_result)
        print("host         :", bale.transport.host)

        me = (bale.me or {}).get("id")
        print("\n--- Users/GetFullUser (self) ---")
        try:
            full = await bale.get_full_user(Peer.user(int(me or 0)))
            print("  fields:", sorted(full)[:12])
            print("  name  :", full.get("name"))
        except Exception as exc:  # noqa: BLE001
            print("  failed:", exc)

        print("\n--- Messaging/LoadHistory (date=-1, loadMode=BACKWARD) ---")
        try:
            chats_now = await bale.load_dialogs(limit=20)
            if chats_now:
                target = chats_now[0].peer
                raw_h = await bale.transport.call(
                    "bale.messaging.v2.Messaging", "LoadHistory",
                    bale.codec.encode("Messaging_LoadHistory_Request", {
                        "peer": target.to_dict(), "date": -1, "loadMode": 2,
                        "limit": 20, "optimizations": []}))
                print(f"  peer {target.key}: {len(raw_h)} bytes: {raw_h.hex()[:300]}")
                msgs = await bale.load_history(target, limit=20)
                print(f"  parsed {len(msgs)} messages")
                for msg in msgs[-5:]:
                    print(f"    {msg.time} uid={msg.sender_uid} {msg.text[:60]!r}")
        except Exception as exc:  # noqa: BLE001
            print("  failed:", exc)

        print("\n--- Messaging/LoadDialogs (minDate=-1, limit=60) ---")
        try:
            raw = await bale.transport.call(
                "bale.messaging.v2.Messaging", "LoadDialogs",
                bale.codec.encode("Messaging_LoadDialogs_Request", {
                    "minDate": -1, "dialogType": 0, "limit": 60,
                    "optimizations": [], "excludePinnedDialogs": False,
                    "archiveFilter": 0,
                }))
            print(f"  {len(raw)} bytes: {raw.hex()[:400]}")
            if raw:
                chats = await bale.load_dialogs(limit=60)
                print(f"  parsed {len(chats)} dialogs")
                for chat in chats[:15]:
                    print("   ", _fmt_chat(0, chat))
        except Exception as exc:  # noqa: BLE001
            print("  failed:", exc)


# --------------------------------------------------------------------------- parser
def build_parser() -> argparse.ArgumentParser:
    # SUPPRESS keeps a value given before the subcommand from being reset by
    # the subparser defaults ("run.py --debug login" and "run.py login --debug"
    # both work).
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--host", default=argparse.SUPPRESS)
    common.add_argument("--session", default=argparse.SUPPRESS)
    common.add_argument("--debug", action="store_true", default=argparse.SUPPRESS)

    parser = argparse.ArgumentParser(prog="baleclient", parents=[common],
                                     description="an unofficial Bale messenger client")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("login", parents=[common])
    p.add_argument("phone", nargs="?")
    p.add_argument("--force", action="store_true", help="ignore the stored session")
    p.add_argument("--no-repl", action="store_true", help="exit after connecting")
    p.set_defaults(func=cmd_login)

    p = sub.add_parser("chats", parents=[common])
    p.add_argument("-n", "--limit", type=int, default=50)
    p.set_defaults(func=cmd_chats)

    p = sub.add_parser("history", parents=[common])
    p.add_argument("peer", help="u:<uid> or g:<gid>")
    p.add_argument("-n", "--limit", type=int, default=30)
    p.set_defaults(func=cmd_history)

    p = sub.add_parser("send", parents=[common])
    p.add_argument("peer")
    p.add_argument("text")
    p.set_defaults(func=cmd_send)

    p = sub.add_parser("listen", parents=[common])
    p.set_defaults(func=cmd_listen)

    p = sub.add_parser("repl", parents=[common])
    p.set_defaults(func=cmd_repl)

    p = sub.add_parser("gui", parents=[common],
                       help="open the graphical client in your browser")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--bind", default="127.0.0.1", help="0.0.0.0 to expose on the LAN")
    p.add_argument("--demo", action="store_true", help="offline demo with fake chats")
    p.add_argument("--no-browser", action="store_true")
    p.set_defaults(func=cmd_gui)

    p = sub.add_parser("native", parents=[common],
                       help="open the desktop GUI (pure Python / tkinter)")
    p.add_argument("--demo", action="store_true", help="offline demo with fake chats")
    p.set_defaults(func=cmd_native)

    p = sub.add_parser("probe", parents=[common],
                       help="dump raw server answers (debug a session)")
    p.set_defaults(func=cmd_probe)

    p = sub.add_parser("demo", parents=[common],
                       help="show protocol frames without logging in")
    p.set_defaults(func=cmd_demo)
    return parser


def _fill_defaults(args: argparse.Namespace) -> None:
    if not hasattr(args, "host"):
        args.host = "next-ws.bale.ai"
    if not hasattr(args, "session"):
        args.session = None
    if not hasattr(args, "debug"):
        args.debug = False


def main(argv: Optional[List[str]] = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    _fill_defaults(args)
    if not getattr(args, "func", None):
        parser.print_help()
        return
    try:
        result = args.func(args)
        if asyncio.iscoroutine(result):
            asyncio.run(result)
    except BaleRpcError as exc:
        print(f"bale error: {exc}", file=sys.stderr)
        raise SystemExit(2)
    except TransportError as exc:
        print(f"transport error: {exc}", file=sys.stderr)
        raise SystemExit(3)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
