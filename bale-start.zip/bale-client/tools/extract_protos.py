#!/usr/bin/env python3
"""
extract_protos.py - recover Bale's protobuf schema from the shipped web client.

The Bale web client is bundled JavaScript containing `google-protobuf`
generated serializers (a compacted variant of classic protoc JS output).
Every message class looks like

    function <defaults>() { return { field: default, ... } }
    let <codec> = {
      encode(v) {
        ... o.uint32(<TAG>).<writer>(v.<field>) ...
        ... <Type>.encode(v.<field>, o.uint32(<TAG>).fork()).join() ...
      },
      decode(r, o) {
        ...
        case <N>:
          if (<TAG> !== r) break;
          c.<field> = a.<reader>();
          continue;
      }
    };

and every RPC as

    let eH = {
      methodName: "StartPhoneAuth",
      service: eG,
      requestType:  { serializeBinary() { return m.encode(this).finish() } },
      responseType: { deserializeBinary(r) { let o = v.decode(r); ... } }
    }

TAG is the protobuf key: (field_number << 3) | wire_type.

This tool parses the bundled modules, resolves cross-module type references,
recovers field names/numbers/types and enum definitions, and writes

  <out>/schema.json    machine readable schema
  <out>/proto/*.proto  protobuf definitions grouped by service package

Usage:  python3 tools/extract_protos.py <js-dir> <out-dir> [--verbose]
"""
from __future__ import annotations

import json
import os
import re
import sys
from collections import defaultdict

# ---------------------------------------------------------------- utilities

# beautified bundles put one module per line, minified ones don't
MODULE_HDR = re.compile(r"^ {1,4}([0-9a-zA-Z_$]+)\(([a-z, ]*)\) \{\s*$", re.M)
MODULE_HDR_RAW = re.compile(r"[,\{](\d{3,6}|\d+e\d+)\((\w+),(\w+),(\w+)\)\{")

SCALARS = {
    "int32", "int64", "uint32", "uint64", "sint32", "sint64",
    "fixed32", "fixed64", "sfixed32", "sfixed64", "float", "double",
    "bool", "string", "bytes",
}

WS = r"\s*"


def brace_match(text: str, open_idx: int) -> int:
    """Index of the '}' matching the '{' at open_idx (string aware)."""
    depth, i, n = 0, open_idx, len(text)
    in_s = None
    while i < n:
        ch = text[i]
        if in_s:
            if ch == "\\":
                i += 2
                continue
            if ch == in_s:
                in_s = None
        elif ch in "\"'`":
            in_s = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise ValueError("unbalanced braces")


def split_modules(text: str):
    marks = [(m.start(), m.group(1)) for m in MODULE_HDR.finditer(text)]
    if len(marks) < 50:
        marks = [(m.start(), m.group(1)) for m in MODULE_HDR_RAW.finditer(text)]
    seen, out = set(), []
    for pos, mid in marks:
        if pos in seen:
            continue
        seen.add(pos)
        out.append((mid, text[pos:]))
    # bodies are sliced by the next header
    result = []
    for i, (mid, body) in enumerate(out):
        end = len(out[i + 1][1]) if i + 1 < len(out) else 0
        result.append((mid, body[:len(body) - end] if end else body))
    return result


# ---------------------------------------------------------------- module

class Module:
    def __init__(self, mod_id: str, body: str, numeric_id: str = ""):
        self.id = mod_id
        self.numeric_id = numeric_id or mod_id
        self.body = body
        self.imports: dict[str, str] = {}
        self.reexports: dict[str, tuple[str, str]] = {}
        self.defaults: dict[str, str] = {}
        self.codecs: dict[str, dict] = {}
        self.exports: dict[str, str] = {}
        self.enums: dict[str, dict] = {}
        self.services: dict[str, str] = {}
        self.methods: list[dict] = []
        self._parse_header()
        self._parse_enums()
        self._parse_codecs()
        self._parse_exports()
        self._parse_services()

    # module imports may be declared anywhere in the body:
    #   var a = r(1234), b = r.n(c), ...
    def _parse_header(self):
        for vm in re.finditer(r"(?<![\w.$])(\w+)\s*=\s*[\w$]+(?:\.n)?\((\d{3,7})\)", self.body):
            self.imports.setdefault(vm.group(1), vm.group(2))

    # (s=p||(p={}))[s.NAME=0]="NAME"
    def _parse_enums(self):
        pat = re.compile(r"\((\w+)\s*=\s*(\w+)\s*\|\|\s*\(\2\s*=\s*\{\}\)\)\[\1\.(\w+)\s*=\s*(-?\d+)\]")
        for m in pat.finditer(self.body):
            self.enums.setdefault(m.group(2), {})[m.group(3)] = int(m.group(4))

    def _parse_codecs(self):
        for m in re.finditer(r"function\s+(\w+)\(\)\s*\{\s*return\s*\{", self.body):
            ob = self.body.index("{", self.body.index("return", m.start()))
            oe = brace_match(self.body, ob)
            self.defaults[m.group(1)] = self.body[ob:oe + 1]

        pat = re.compile(r"(?<![\w$.])([\w$]+)\s*(?:=|:)\s*(\{)\s*encode\((\w+)\)\s*\{")
        for m in pat.finditer(self.body):
            name, enc_var = m.group(1), m.group(3)
            ob = m.start(2)
            oe = brace_match(self.body, ob)
            block = self.body[ob:oe + 1]
            enc = self._fn_body(block, "encode(" + enc_var + ")")
            if enc is None:
                continue
            dm = re.search(r"decode\((\w+)\s*,\s*(\w+)\)\s*\{", block)
            dec = self._fn_body(block, dm.group(0)[:-1]) if dm else None
            if dec is None:
                continue
            prev = None
            for pm in re.finditer(r"function\s+(\w+)\(\)\s*\{\s*return\s*\{", self.body[:m.start()]):
                prev = pm.group(1)
            self.codecs[name] = {
                "defaults": prev, "encode": enc, "decode": dec,
                "enc_var": enc_var,
                "dec_var": dm.group(1), "reader_var": None,
                "module": self.id,
            }
            rm = re.search(r"(\w+)\s*=\s*\w+\s*instanceof\s+[\w.$]+\s*\?\s*\w+\s*:\s*new", dec)
            self.codecs[name]["reader_var"] = rm.group(1) if rm else "a"
            wm = re.search(r"(\w+)\s*=\s*arguments\.length", enc)
            self.codecs[name]["writer_var"] = wm.group(1) if wm else "o"

    @staticmethod
    def _fn_body(block: str, sig: str):
        rx = re.escape(sig).replace(r"\(", r"\(").replace(r"\ ", WS)
        m = re.search(rx + r"\s*\{", block)
        if m is None:
            return None
        ob = block.index("{", m.start())
        return block[ob + 1:brace_match(block, ob)]

    def _parse_exports(self):
        for m in re.finditer(r"\w+\.d\(\w+\s*,", self.body):
            # collect the argument list up to the matching ')'
            i = self.body.index("(", m.start())
            depth, j = 0, i
            while j < len(self.body):
                ch = self.body[j]
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            args = self.body[i + 1:j]
            for ob in re.finditer(r"\{", args):
                try:
                    oe = brace_match(args, ob.start())
                except ValueError:
                    continue
                block = args[ob.start() + 1:oe]
                for em in re.finditer(r"([\w$]+)\s*:\s*\{", block):
                    if em.group(1) in self.codecs:
                        self.exports[em.group(1)] = em.group(1)
                for em in re.finditer(r"([\w$]+)\s*:\s*(\(\)\s*=>\s*)?([\w.$]+)", block):
                    name, value = em.group(1), em.group(3)
                    mm = re.match(r"(\w+)\.(\w+)$", value)
                    if mm and mm.group(1) in self.imports:
                        self.reexports[name] = (self.imports[mm.group(1)], mm.group(2))
                    elif em.group(2) and "." not in value:
                        self.exports[name] = value
                    elif not em.group(2) and "." not in value and value in self.codecs:
                        self.exports[name] = value

    def _parse_services(self):
        for m in re.finditer(r"([\w$]+)\s*=\s*\{\s*serviceName:\s*\"([\w.]+)\"", self.body):
            self.services[m.group(1)] = m.group(2)

        for m in re.finditer(r"\{\s*methodName:\s*\"(\w+)\"", self.body):
            ob = m.start()
            oe = brace_match(self.body, ob)
            block = self.body[ob:oe + 1]
            svc_var = re.search(r"service:\s*([\w$]+)", block)
            req = re.search(r"serializeBinary\(\)\s*\{\s*return\s+([\w.$]+)\.encode", block)
            res = re.search(r"deserializeBinary\(\w+\)\s*\{\s*(?:let\s+\w+\s*=\s*)?([\w.$]+)\.decode", block)
            if res is None:
                res = re.search(r"([\w.$]+)\.decode\(", block)
            if not svc_var or not req:
                continue
            self.methods.append({
                "name": m.group(1),
                "service_var": svc_var.group(1),
                "request": req.group(1),
                "response": res.group(1) if res else None,
                "module": self.id,
            })


# ---------------------------------------------------------------- field parse

def parse_encode(body: str, var: str, wr: str = "o") -> dict:
    out: dict[int, dict] = {}
    v = re.escape(var)
    w = re.escape(wr)
    repeated = set()
    for m in re.finditer(r"for\s*\(\s*let\s+\w+\s+of\s+" + v + r"\.(\w+)\s*\)", body):
        repeated.add(m.group(1))

    # packed repeated scalars:  o.uint32(TAG).fork(), var.field
    for m in re.finditer(w + r"\.uint32\((\d+)\)\.fork\(\)\s*,\s*" + v + r"\.(\w+)", body):
        out[int(m.group(1))] = {"kind": "scalar", "writer": None, "repeated": True,
                                "packed": True, "field": m.group(2)}

    for m in re.finditer(r"([\w.$]+)\.encode\(([^,]+?)\s*,\s*" + w + r"\.uint32\((\d+)\)\.fork\(\)\)", body):
        typ, arg, tag = m.group(1), m.group(2).strip(), int(m.group(3))
        field = None
        wrapper = False
        if arg.startswith(var + "."):
            field = arg[len(var) + 1:]
        elif arg.startswith("{"):
            fm = re.search(r"value:\s*" + v + r"\.(\w+)", arg)
            field, wrapper = (fm.group(1) if fm else None), True
        elif arg in ("a", "e", "t", "n", "r", "o", "s", "c", "l", "i", "u", "d", "f", "p", "h", "g", "m"):
            # repeated message inside for..of
            fm = None
            for lm in re.finditer(r"for\s*\(\s*let\s+" + re.escape(arg) + r"\s+of\s+" + v + r"\.(\w+)\s*\)", body[:m.start()]):
                fm = lm
            field = fm.group(1) if fm else None
        out[tag] = {"kind": "message", "type": typ, "repeated": field in repeated,
                    "field": field, "wrapper": wrapper}

    pat = re.compile(w + r"\.uint32\((\d+)\)\.(\w+)\(([^()]*(?:\([^()]*\)[^()]*)*)\)")
    for m in pat.finditer(body):
        tag, writer, arg = int(m.group(1)), m.group(2), m.group(3).strip()
        if tag in out:
            continue
        field = arg[len(var) + 1:] if arg.startswith(var + ".") else None
        if field is None and re.fullmatch(r"\w+", arg):
            for lm in re.finditer(r"for\s*\(\s*let\s+" + re.escape(arg) + r"\s+of\s+" + v + r"\.(\w+)\s*\)", body[:m.start()]):
                field = lm.group(1)
        out[tag] = {"kind": "scalar", "writer": writer, "repeated": field in repeated,
                    "field": field}
    return out


DECODE_CASE_RE = re.compile(r"case (\d+):\s*if\s*\((\d+)\s*!==\s*r\s*\)\s*break\s*;")


def parse_decode(body: str) -> dict:
    out: dict[int, dict] = {}
    cases = list(DECODE_CASE_RE.finditer(body))
    for i, cm in enumerate(cases):
        tag = int(cm.group(2))
        start = cm.end()
        end = cases[i + 1].start() if i + 1 < len(cases) else len(body)
        block = body[start:end]
        info = {"repeated": False, "packed": False, "type": None,
                "message_type": None, "wrapper": False, "map": False,
                "name": None}

        nm = re.search(r"\b\w+\.(\w+)(?:\.push\(|=)", block)
        if nm:
            info["name"] = nm.group(1)

        if re.search(r"a\.uint32\(\)\s*\+\s*\w+\.pos", block):
            info["map"] = True
            out[tag] = info
            continue

        mm = re.search(r"(\w+)\.push\(([\w.$]+)\.decode\(", block)
        if mm:
            info.update(repeated=True, message_type=mm.group(2))
            out[tag] = info
            continue

        mm = re.search(r"(\w+)\.push\((\w+)\.(\w+)\(\)\)", block)
        if mm:
            info.update(repeated=True, type=mm.group(3))
            out[tag] = info
            continue

        mm = re.search(r"(\w+)\s*=\s*([\w.$]+)\.decode\(\w+,\s*\w+\.uint32\(\)\)(\.value)?", block)
        if mm:
            info.update(message_type=mm.group(2), wrapper=bool(mm.group(3)))
            out[tag] = info
            continue

        mm = re.search(r"(\w+)\s*=\s*(?:\w+\()?(\w+)\.(\w+)\(\)", block)
        if mm:
            info.update(type=mm.group(3))
            out[tag] = info
            continue

        out[tag] = info
    return out


# ---------------------------------------------------------------- schema

class Schema:
    def __init__(self):
        self.modules: dict[str, Module] = {}
        self.by_file: dict[str, dict[str, Module]] = {}
        self.messages: dict[tuple, dict] = {}
        self.methods: list[dict] = []
        self._names: dict[tuple, str] = {}
        self._owner: dict[str, tuple] = {}
        self.wkt: dict[tuple, str] = {}

    def load(self, js_dir: str):
        paths = []
        for root, _d, files in os.walk(js_dir):
            for fn in sorted(files):
                if fn.endswith(".js"):
                    paths.append(os.path.join(root, fn))
        for path in sorted(paths):
            text = open(path, encoding="utf-8", errors="replace").read()
            if "encode(" not in text:
                continue
            base = os.path.relpath(path, js_dir).replace(os.sep, "/")
            local: dict[str, Module] = {}
            self.by_file[base] = local
            for mod_id, body in split_modules(text):
                key = f"{base}::{mod_id}"
                try:
                    mod = Module(key, body, mod_id)
                except Exception:
                    continue
                local[mod_id] = mod
                if mod.codecs:
                    self.modules[key] = mod

    # --- resolution --------------------------------------------------------
    def _module_for(self, ref_file: str, numeric_id: str):
        local = self.by_file.get(ref_file, {})
        if numeric_id in local:
            return local[numeric_id]
        for mods in self.by_file.values():
            if numeric_id in mods:
                return mods[numeric_id]
        return None

    def resolve_ref(self, module_id: str, ref: str):
        if "." not in ref:
            return None
        var, member = ref.split(".", 1)
        mod = self.modules.get(module_id)
        if mod is None:
            return None
        target = mod.imports.get(var)
        if target is None:
            return None
        f = module_id.split("::", 1)[0]
        tm = self._module_for(f, target)
        if tm is None:
            return None
        if member in tm.exports:
            return (tm.id, tm.exports[member])
        if member in tm.reexports:
            m2, name = tm.reexports[member]
            for f2, mods in self.by_file.items():
                if m2 in mods:
                    m3 = mods[m2]
                    if name in m3.exports:
                        return (m3.id, m3.exports[name])
        return None

    def local_ref(self, module_id: str, ref: str):
        mod = self.modules.get(module_id)
        if mod and "." not in ref and ref in mod.codecs:
            return (module_id, ref)
        if "." in ref:
            return self.resolve_ref(module_id, ref)
        return None

    def message(self, module_id: str, codec: str) -> dict:
        key = (module_id, codec)
        if key in self.messages:
            return self.messages[key]
        mod = self.modules[module_id]
        cd = mod.codecs[codec]
        enc = parse_encode(cd["encode"], cd["enc_var"], cd.get("writer_var", "o"))
        dec = parse_decode(cd["decode"])
        fields = []
        for tag in sorted(set(enc) | set(dec)):
            e, d = enc.get(tag, {}), dec.get(tag, {})
            msg_ref = d.get("message_type") or e.get("type")
            resolved = self.local_ref(module_id, msg_ref) if msg_ref else None
            fields.append({
                "number": tag >> 3,
                "name": d.get("name") or e.get("field") or f"field_{tag}",
                "scalar": None if resolved else (d.get("type") or e.get("writer") or "bytes"),
                "type_ref": list(resolved) if resolved else None,
                "type_ref_js": msg_ref,
                "repeated": bool(d.get("repeated") or e.get("repeated")),
                "packed": bool(d.get("packed") or e.get("packed")),
                "wrapper": bool(d.get("wrapper") or e.get("wrapper")),
                "map": bool(d.get("map")),
            })
        entry = {"module": module_id, "codec": codec,
                 "defaults": mod.defaults.get(cd["defaults"], ""), "fields": fields}
        self.messages[key] = entry
        return entry

    # --- naming ------------------------------------------------------------
    def assign_names(self):
        from collections import Counter

        # 1) RPC messages get canonical names when a type is used exactly once
        usage: Counter = Counter()
        for mod in self.modules.values():
            for m in mod.methods:
                for ref in (m["request"], m["response"]):
                    r = self.local_ref(mod.id, ref) if ref else None
                    if r:
                        usage[r] += 1

        for mod in self.modules.values():
            for m in mod.methods:
                svc = mod.services.get(m["service_var"], "unknown.Service")
                short = svc.rsplit(".", 1)[-1]
                keys = {}
                for role, ref in (("Request", m["request"]), ("Response", m["response"])):
                    r = self.local_ref(mod.id, ref) if ref else None
                    if not r:
                        continue
                    keys[role.lower() + "_key"] = list(r)
                    if usage[r] == 1:
                        self._claim(r, f"{short}_{m['name']}_{role}")
                m.update(keys)
                m["service"] = svc
                self.methods.append(m)

        # 2) name by the field that most often references the type
        field_uses: dict[tuple, Counter] = {}
        for msg in self.messages.values():
            for f in msg["fields"]:
                if f["type_ref"]:
                    field_uses.setdefault(tuple(f["type_ref"]), Counter())[f["name"]] += 1
        for key, counter in field_uses.items():
            if key in self._names or key not in self.messages:
                continue
            field = counter.most_common(1)[0][0]
            label = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", field.strip("_"))
            label = "".join(p[:1].upper() + p[1:] for p in label.split("_") if p)
            if label and label not in ("Value", "Result", "Response", "Request"):
                self._claim(key, label)

        # 3) nested messages inherit their parent name
        changed, rounds = True, 0
        while changed and rounds < 6:
            changed, rounds = False, rounds + 1
            for key, msg in self.messages.items():
                parent = self._names.get(key)
                if not parent:
                    continue
                for f in msg["fields"]:
                    if not f["type_ref"]:
                        continue
                    child = tuple(f["type_ref"])
                    if child in self._names or child not in self.messages:
                        continue
                    label = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", f["name"].strip("_")).lower()
                    label = "".join(p[:1].upper() + p[1:] for p in label.split("_") if p)
                    if self._claim(child, f"{parent}_{label}", soft=True):
                        changed = True

        # 4) anything left gets a positional name
        for key in self.messages:
            if key not in self._names:
                raw = "Msg_" + key[0].split("/")[-1].replace(".js", "") + "_" + key[1]
                raw = re.sub(r"[^0-9A-Za-z_]", "_", raw)
                if raw[0].isdigit():
                    raw = "M" + raw
                self._claim(key, raw)

    def _claim(self, key, name, soft=False) -> bool:
        name = re.sub(r"[^0-9A-Za-z_]", "_", name)
        if name and name[0].isdigit():
            name = "M" + name
        if key in self._names:
            return False
        if name in self._owner and self._owner[name] != key:
            i = 2
            while f"{name}{i}" in self._owner:
                i += 1
            name = f"{name}{i}"
        self._names[key] = name
        self._owner[name] = key
        return True

    # --- well known types ---------------------------------------------------
    def classify_wkt(self):
        for key, msg in self.messages.items():
            f = msg["fields"]
            if len(f) == 1 and f[0]["name"] == "value" and f[0]["scalar"]:
                name = {
                    "double": "google.protobuf.DoubleValue",
                    "float": "google.protobuf.FloatValue",
                    "int64": "google.protobuf.Int64Value",
                    "uint64": "google.protobuf.UInt64Value",
                    "int32": "google.protobuf.Int32Value",
                    "uint32": "google.protobuf.UInt32Value",
                    "bool": "google.protobuf.BoolValue",
                    "string": "google.protobuf.StringValue",
                    "bytes": "google.protobuf.BytesValue",
                }.get(f[0]["scalar"])
                if name:
                    self.wkt[key] = name
        for key, msg in self.messages.items():
            if [f["name"] for f in msg["fields"]] == ["seconds", "nanos"]:
                self.wkt[key] = "google.protobuf.Timestamp"

    def type_name(self, key) -> str:
        return self.wkt.get(key) or self._names.get(key, "Unknown")


# ---------------------------------------------------------------- proto emit

def emit_single_proto(schema: Schema, path: str):
    """One self contained .proto with every message and every service."""
    lines = ['syntax = "proto3";', "", "package bale;", "",
             'import "google/protobuf/wrappers.proto";',
             'import "google/protobuf/timestamp.proto";', "",
             "// RPCs whose response type is not a message use this placeholder.",
             "message BaleEmpty {}", ""]
    for key in sorted(schema.messages, key=lambda k: schema.type_name(k)):
        name = schema.type_name(key)
        if name.startswith("google."):
            continue
        msg = schema.messages[key]
        lines.append(f"message {name} {{")
        used = set()
        for f in msg["fields"]:
            fn = f["name"]
            if fn in used:
                fn = f"{fn}_{f['number']}"
            used.add(fn)
            if f["type_ref"]:
                t = schema.type_name(tuple(f["type_ref"]))
            else:
                t = f["scalar"] if f["scalar"] in SCALARS else "bytes"
            rep = "repeated " if f["repeated"] else ""
            lines.append(f"  {rep}{t} {fn} = {f['number']};")
        lines += ["}", ""]

    by_service: dict[str, list] = {}
    for m in schema.methods:
        by_service.setdefault(m["service"], []).append(m)

    message_names = {schema.type_name(k) for k in schema.messages}
    used_services: set[str] = set()
    for service, methods in sorted(by_service.items()):
        short = service.rsplit(".", 1)[-1]
        if short in message_names or short in used_services:
            short = short + "Service"
        while short in message_names or short in used_services:
            short = short + "_"
        used_services.add(short)
        lines.append(f"// {service}")
        lines.append(f"service {short} {{")
        for m in methods:
            req = schema.type_name(tuple(m["request_key"])) if "request_key" in m else "BaleEmpty"
            res = schema.type_name(tuple(m["response_key"])) if "response_key" in m else "BaleEmpty"
            if req.startswith("google.") or req not in message_names:
                req = "BaleEmpty"
            if res.startswith("google.") or res not in message_names:
                res = "BaleEmpty"
            lines.append(f"  rpc {m['name']} ({req}) returns ({res});")
        lines.append("}")
        lines.append("")
    open(path, "w").write("\n".join(lines) + "\n")


def emit_proto(schema: Schema, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    message_names = {schema.type_name(k) for k in schema.messages}
    packages: dict[str, set] = defaultdict(set)
    msg_pkg: dict[tuple, str] = {}

    for m in schema.methods:
        pkg = m["service"].rsplit(".", 1)[0]
        for role in ("request_key", "response_key"):
            if role in m:
                msg_pkg[tuple(m[role])] = pkg
                packages[pkg].add(tuple(m[role]))

    for _ in range(12):
        grew = False
        for key, msg in schema.messages.items():
            if key not in msg_pkg:
                continue
            for f in msg["fields"]:
                if not f["type_ref"]:
                    continue
                child = tuple(f["type_ref"])
                if child not in msg_pkg:
                    msg_pkg[child] = msg_pkg[key]
                    packages[msg_pkg[key]].add(child)
                    grew = True
        if not grew:
            break

    written = {}
    for pkg, keys in sorted(packages.items()):
        fname = pkg.replace(".", "_") + ".proto"
        lines = ['syntax = "proto3";', "", f"package {pkg};", "",
                 'import "google/protobuf/wrappers.proto";',
                 'import "google/protobuf/timestamp.proto";', "",
                 "message BaleEmpty {}", ""]
        for key in sorted(keys, key=lambda k: schema.type_name(k)):
            name = schema.type_name(key)
            if name.startswith("google."):
                continue
            msg = schema.messages[key]
            lines.append(f"message {name} {{")
            used = set()
            for f in msg["fields"]:
                fn = f["name"]
                if fn in used:
                    fn = f"{fn}_{f['number']}"
                used.add(fn)
                if f["type_ref"]:
                    t = schema.type_name(tuple(f["type_ref"]))
                else:
                    t = f["scalar"] if f["scalar"] in SCALARS else "bytes"
                rep = "repeated " if f["repeated"] else ""
                lines.append(f"  {rep}{t} {fn} = {f['number']};")
            lines += ["}", ""]
        lines.append(f"service {pkg.rsplit('.', 1)[-1]} {{")
        for m in schema.methods:
            if m["service"].rsplit(".", 1)[0] != pkg:
                continue
            req = schema.type_name(tuple(m["request_key"])) if "request_key" in m else "BaleEmpty"
            res = schema.type_name(tuple(m["response_key"])) if "response_key" in m else "BaleEmpty"
            if req.startswith("google.") or req not in message_names:
                req = "BaleEmpty"
            if res.startswith("google.") or res not in message_names:
                res = "BaleEmpty"
            lines.append(f"  rpc {m['name']} ({req}) returns ({res});")
        lines.append("}")
        path = os.path.join(out_dir, fname)
        open(path, "w").write("\n".join(lines) + "\n")
        written[pkg] = path
    return written


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    js_dir, out_dir = sys.argv[1], sys.argv[2]
    sch = Schema()
    sch.load(js_dir)
    for mod in sch.modules.values():
        for codec in mod.codecs:
            sch.message(mod.id, codec)
    sch.assign_names()
    sch.classify_wkt()

    os.makedirs(out_dir, exist_ok=True)
    data = {
        "services": sorted({m["service"] for m in sch.methods}),
        "methods": [dict(m) for m in sch.methods],
        "messages": [{"name": sch.type_name(k), **v} for k, v in sch.messages.items()],
        "enums": [{"module": mid, "name": var, "values": vals}
                  for mid, mod in sch.modules.items() for var, vals in mod.enums.items()],
    }
    with open(os.path.join(out_dir, "schema.json"), "w") as fh:
        json.dump(data, fh, indent=1)
    written = emit_proto(sch, os.path.join(out_dir, "proto"))
    emit_single_proto(sch, os.path.join(out_dir, "bale.proto"))
    print(f"modules={len(sch.modules)} messages={len(sch.messages)} "
          f"methods={len(sch.methods)} services={len(data['services'])}")
    for svc in data["services"]:
        n = sum(1 for m in sch.methods if m["service"] == svc)
        print(f"  {svc}: {n} rpc")
    print("proto files:", *written.values(), sep="\n  ")


if __name__ == "__main__":
    main()
