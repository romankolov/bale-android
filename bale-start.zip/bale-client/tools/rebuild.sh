#!/usr/bin/env bash
# Rebuild everything from the challenge archive.
#   ./tools/rebuild.sh /path/to/bale.rar
set -euo pipefail
RAR="${1:-bale.rar}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$ROOT/extract"

echo "[1/3] extracting client bundle"
mkdir -p "$WORK"
if command -v unrar >/dev/null 2>&1; then
  unrar x -o+ -idq "$RAR" "$WORK/"
else
  7z x -y -o"$WORK" "$RAR" >/dev/null
fi

echo "[2/3] recovering protocol schema"
python3 "$ROOT/tools/extract_protos.py" "$WORK/bale/static/js" "$ROOT/out"

echo "[3/3] building the runtime schema"
python3 "$ROOT/tools/build_schema.py" "$ROOT/out/schema.json" "$ROOT/baleclient/schema.json"

echo "done - try: python3 run.py demo"
