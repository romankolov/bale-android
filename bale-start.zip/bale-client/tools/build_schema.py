#!/usr/bin/env python3
"""
build_schema.py - turn out/schema.json into the compact runtime schema used by
``baleclient`` (baleclient/schema.json).

    python3 tools/build_schema.py out/schema.json baleclient/schema.json
"""
from __future__ import annotations

import json
import sys

SCALARS = {
    "int32", "int64", "uint32", "uint64", "sint32", "sint64",
    "fixed32", "fixed64", "sfixed32", "sfixed64", "float", "double",
    "bool", "string", "bytes",
}


def main() -> None:
    src = sys.argv[1] if len(sys.argv) > 1 else "out/schema.json"
    dst = sys.argv[2] if len(sys.argv) > 2 else "baleclient/schema.json"

    data = json.load(open(src))
    by_key = {(m["module"], m["codec"]): m["name"] for m in data["messages"]}

    messages: dict[str, dict[str, list]] = {}
    unresolved = 0
    for msg in data["messages"]:
        name = msg["name"]
        fields = {}
        for f in msg["fields"]:
            if f.get("type_ref"):
                ref = tuple(f["type_ref"])
                ftype = by_key.get(ref)
                if ftype is None:
                    ftype = "bytes"
                    unresolved += 1
            else:
                ftype = f.get("scalar") or "bytes"
                if ftype not in SCALARS:
                    ftype = "bytes"
                    unresolved += 1
            out_name = f["name"]
            if out_name.startswith("field_") and not f.get("type_ref"):
                ftype = "bytes"
            fields[str(f["number"])] = [out_name, ftype, bool(f.get("repeated"))]
        if name in messages and len(messages[name]) >= len(fields):
            continue
        messages[name] = fields

    services = {}
    for m in data["methods"]:
        services.setdefault(m["service"], {})[m["name"]] = {
            "request": by_key.get(tuple(m["request_key"])) if m.get("request_key") else None,
            "response": by_key.get(tuple(m["response_key"])) if m.get("response_key") else None,
        }

    with open(dst, "w", encoding="utf-8") as fh:
        json.dump({"messages": messages, "services": services}, fh,
                  ensure_ascii=False, separators=(",", ":"))
    print(f"{len(messages)} messages, {sum(len(v) for v in services.values())} rpcs, "
          f"{unresolved} unresolved field types -> {dst}")


if __name__ == "__main__":
    main()
