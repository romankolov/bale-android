"""Tests for the Arabic/Persian shaper + bidi reordering used by the Tk GUI."""
import unittest

from baleclient.rtl import bidi, is_rtl, shape, visual


class TestShaping(unittest.TestCase):
    def test_persian_is_detected(self):
        self.assertTrue(is_rtl("سلام"))
        self.assertFalse(is_rtl("hello"))
        self.assertFalse(is_rtl(""))
        self.assertFalse(is_rtl("123"), "numbers alone are not RTL text")

    def test_letters_use_contextual_forms(self):
        shaped = shape("سلام")
        self.assertNotEqual(shaped, "سلام", "letters must not stay in base form")
        # س + (لا ligature) + م  ->  one glyph per letter, lam+alef merged
        self.assertEqual(len(shaped), 3)
        for char in shaped:
            self.assertGreaterEqual(ord(char), 0xFB50,
                                    "every glyph should be a presentation form")

    def test_four_letter_word_without_ligature(self):
        shaped = shape("کتاب")
        self.assertEqual(len(shaped), 4)
        self.assertTrue(all(ord(char) >= 0xFB50 for char in shaped))

    def test_non_arabic_passes_through(self):
        self.assertEqual(shape("file.bin 42"), "file.bin 42")

    def test_lam_alef_ligature(self):
        shaped = shape("لا")
        self.assertEqual(len(shaped), 1, "lam+alef is one mandatory ligature")
        self.assertTrue(0xFEF0 <= ord(shaped[0]) <= 0xFEFC)

    def test_zwnj_still_joins_visually(self):
        # Persian "mi-khaham" uses ZWNJ; shapes into two joined clusters
        shaped = shape("می\u200cخواهم")
        self.assertIn("\u200c", shaped)


class TestBidi(unittest.TestCase):
    def test_rtl_text_is_reversed(self):
        self.assertEqual(visual("سلام"), "ﻡﻼﺳ")

    def test_latin_runs_keep_their_order(self):
        rendered = visual("سلام 123 abc")
        self.assertTrue(rendered.startswith("abc 123"),
                        f"latin/numbers must stay LTR, got {rendered!r}")
        self.assertTrue(rendered.endswith("ﻡﻼﺳ"), f"got {rendered!r}")

    def test_pure_english_is_untouched(self):
        self.assertEqual(bidi("hello world"), "hello world")
        self.assertEqual(visual("hello world"), "hello world")

    def test_empty_string(self):
        self.assertEqual(visual(""), "")
        self.assertEqual(bidi(""), "")

    def test_url_inside_persian(self):
        rendered = visual("لینک ble.ir/join/CiX98k7Rmw را باز کن")
        self.assertIn("ble.ir/join/CiX98k7Rmw", rendered)


class TestNativeGui(unittest.TestCase):
    """The desktop GUI must import and build without a display server."""

    def test_tkgui_imports(self):
        try:
            import baleclient.tkgui  # noqa: F401
        except Exception as exc:  # pragma: no cover - tkinter missing
            self.skipTest(f"tkinter unavailable: {exc}")

    def test_visual_is_idempotent_for_latin(self):
        from baleclient.rtl import visual
        self.assertEqual(visual(visual("hello")), "hello")


if __name__ == "__main__":
    unittest.main()
