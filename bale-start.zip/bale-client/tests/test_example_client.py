"""Runs the standalone example client against its local mock server.

Skips itself when the optional `websockets` package is missing, because the
example's own test server uses it (the *client* needs nothing but stdlib).
"""
import os
import subprocess
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPT = os.path.join(ROOT, "docs", "examples", "test_minimal_client.py")


class TestMinimalClientExample(unittest.TestCase):
    def test_example_client_against_mock_server(self):
        try:
            import websockets  # noqa: F401
        except ImportError:
            self.skipTest("websockets not installed")
        result = subprocess.run([sys.executable, SCRIPT], capture_output=True,
                                text=True, timeout=90)
        self.assertEqual(result.returncode, 0,
                         f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}")
        self.assertIn("all protocol checks passed", result.stdout)


if __name__ == "__main__":
    unittest.main()
