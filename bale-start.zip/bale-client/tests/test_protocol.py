"""
Offline protocol tests - they need no Bale account.

    python -m unittest discover -s tests -v
"""
from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from baleclient.proto import default_codec          # noqa: E402
from baleclient.transport import (decode_frame, encode_handshake,  # noqa: E402
                                  encode_ping, encode_request_body)
from baleclient.client import Peer                  # noqa: E402


class TestSchema(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.codec = default_codec()

    def test_core_messages_exist(self):
        for name in [
            "Auth_StartPhoneAuth_Request", "Auth_StartPhoneAuth_Response",
            "Auth_ValidateCode_Request", "Msg_index_fe3fa18088__86923_A",
            "Messaging_SendMessage_Request", "Messaging_LoadDialogs_Request",
            "Messaging_LoadHistory_Request", "Update", "TextMessage", "Peer",
        ]:
            self.assertIn(name, self.codec.schema.by_name, name)

    def test_start_phone_auth_fields(self):
        fields = self.codec.schema.fields("Auth_StartPhoneAuth_Request")
        self.assertEqual(fields[1].name, "phoneNumber")
        self.assertEqual(fields[1].type, "int64")
        self.assertEqual(fields[3].name, "apiKey")
        self.assertEqual(fields[9].name, "sendCodeType")

    def test_update_schema_is_complete(self):
        update = self.codec.schema.fields("Update")
        self.assertGreater(len(update), 140)
        self.assertEqual(update[4].name, "messageSent")
        self.assertEqual(update[55].name, "message")
        self.assertEqual(update[162].name, "messageContentChanged")

    def test_peer_types_are_int32(self):
        peer = self.codec.schema.fields("Peer")
        self.assertEqual(peer[1].type, "int32")
        self.assertEqual(peer[2].type, "int32")


class TestCodec(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.codec = default_codec()

    def test_roundtrip_scalars(self):
        payload = {
            "phoneNumber": 989121234567,
            "appId": 4,
            "apiKey": "KEY",
            "deviceHash": b"uuid",
            "deviceTitle": "Chrome",
            "sendCodeType": 1,
        }
        raw = self.codec.encode("Auth_StartPhoneAuth_Request", payload)
        self.assertEqual(self.codec.decode("Auth_StartPhoneAuth_Request", raw), payload)

    def test_roundtrip_nested_and_unicode(self):
        msg = {
            "peer": {"type": 1, "id": 42},
            "rid": 123456789,
            "message": {"textMessage": {"text": "سلام دنیا"}},
            "isSilent": False,
        }
        raw = self.codec.encode("Messaging_SendMessage_Request", msg)
        self.assertEqual(self.codec.decode("Messaging_SendMessage_Request", raw), msg)

    def test_field_numbers_on_the_wire(self):
        raw = self.codec.encode("Messaging_SendMessage_Request",
                                {"peer": {"type": 1, "id": 2}})
        # field 1 (peer), wire type 2 -> tag 0x0a
        self.assertEqual(raw[0], 0x0A)
        # peer.type = field 1 varint -> 0x08 0x01
        self.assertEqual(raw[2:4], b"\x08\x01")

    def test_wrapper_boolvalue(self):
        raw = self.codec.encode("Auth_ValidateCode_Request",
                                {"code": "1", "isJwt": {"value": True}})
        self.assertIn(b"\x1a\x02\x08\x01", raw)

    def test_unknown_fields_are_preserved(self):
        raw = bytes.fromhex("08878de1e1e41c1004")   # phoneNumber + appId
        decoded = self.codec.decode("Auth_StartPhoneAuth_Request", raw)
        self.assertEqual(decoded["phoneNumber"], 989121234567)
        self.assertEqual(decoded["appId"], 4)


class TestWebClientParity(unittest.TestCase):
    """The request bytes must match what the official client sends."""

    @classmethod
    def setUpClass(cls):
        cls.codec = default_codec()

    def test_load_dialogs_first_page_uses_minus_one(self):
        # core/dialogs.loadDialogs(): minDate = -1 for the first page
        raw = self.codec.encode("Messaging_LoadDialogs_Request", {
            "minDate": -1, "dialogType": 0, "limit": 60, "optimizations": [],
            "excludePinnedDialogs": False, "archiveFilter": 0})
        self.assertTrue(raw.startswith(b"\x08\xff\xff\xff\xff\xff\xff\xff\xff\xff\x01"),
                        raw.hex())
        self.assertEqual(self.codec.decode("Messaging_LoadDialogs_Request", raw)["minDate"], -1)
        self.assertIn(b"\x10\x3c", raw)          # field 2 (limit) = 60

    def test_load_dialogs_zero_min_date_is_not_the_first_page(self):
        raw = self.codec.encode("Messaging_LoadDialogs_Request", {"minDate": 0})
        self.assertNotIn(b"\xff", raw)

    def test_send_message_layout(self):
        raw = self.codec.encode("Messaging_SendMessage_Request", {
            "peer": {"type": 1, "id": 42}, "rid": 1,
            "message": {"textMessage": {"text": "hi"}}})
        self.assertEqual(raw[:4], b"\x0a\x04\x08\x01\x10\x2a"[:4])  # peer{type,id}
        self.assertIn(b"\x7a\x04\x0a\x02hi", raw)                   # textMessage=f15


class TestEnvelope(unittest.TestCase):
    def test_handshake_frame(self):
        # handshakeRequest{ mkprotoVersion = 1, apiVersion = 176652 }
        self.assertEqual(encode_handshake().hex(), "1a060801108ce40a")

    def test_ping_frame(self):
        self.assertEqual(encode_ping(7).hex(), "12020807")

    def test_request_frame_carries_service_and_id(self):
        frame = encode_request_body("bale.auth.v1.Auth", "StartPhoneAuth", b"\x08\x01", 42)
        self.assertTrue(frame.startswith(b"\x0a"))       # field 1 = request
        self.assertIn(b"bale.auth.v1.Auth", frame)
        self.assertIn(b"StartPhoneAuth", frame)
        self.assertTrue(frame.endswith(b"\x28\x2a"))     # request_id = 42

    def test_decode_response_and_update(self):
        # WsResponse{ response{ result = <payload>, number = 5 } }
        result = bytes.fromhex("0801")
        inner = b"\x12\x02" + result + b"\x18\x05"
        frame = b"\x0a" + bytes([len(inner)]) + inner
        decoded = decode_frame(default_codec(), frame)
        self.assertEqual(decoded["response"]["number"], 5)
        self.assertEqual(decoded["response"]["result"], result)

        # WsResponse{ update{ update = <update body> } }
        body = bytes.fromhex("2200")                     # field 4, empty msg
        upd = b"\x0a\x02" + body
        frame2 = b"\x12" + bytes([len(upd)]) + upd
        decoded2 = decode_frame(default_codec(), frame2)
        self.assertEqual(decoded2["update"]["body"], body)


class TestPeers(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(Peer.parse("u:5"), Peer(5, 1))
        self.assertEqual(Peer.parse("g:7"), Peer(7, 2))
        self.assertEqual(Peer.parse("9"), Peer(9, 1))

    def test_to_dict(self):
        self.assertEqual(Peer.group(7).to_dict(), {"type": 2, "id": 7})
        self.assertEqual(Peer.user(3, 99).to_dict(),
                         {"type": 1, "id": 3, "accessHash": 99})


if __name__ == "__main__":
    unittest.main()
