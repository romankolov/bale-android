try {
 ! function() {
  var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {},
   t = (new e.Error).stack;
  t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "6022783e-9885-4f83-8016-4a38df22382e", e._sentryDebugIdIdentifier = "sentry-dbid-6022783e-9885-4f83-8016-4a38df22382e")
 }()
} catch (e) {}
try {
 ("u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {}).SENTRY_RELEASE = {
  id: "web@5.8.0+176652"
 }
} catch (e) {}(() => {
 var __webpack_modules__ = {
   14981(e, t, r) {
    "use strict";
    var o, n;

    function a(e) {
     let t = e.getHours(),
      r = e.getMinutes().toString().padStart(2, "0"),
      o = e.getSeconds().toString().padStart(2, "0"),
      n = e.getMilliseconds().toString().padEnd(3, "0");
     return `[${t}:${r}:${o}.${n}]`
    }

    function i(e, t) {
     if (!t) return e;
     for (let r in t) null != t[r] && (e[r] = t[r]);
     return e
    }(n = o || (o = {})).Critical = "Critical", n.Error = "Error", n.Warn = "Warn", n.Info = "Info", n.Debug = "Debug";

    function s(e) {
     let t = typeof e;
     switch (t) {
      case "bigint":
      case "boolean":
      case "number":
       return e.toString();
      case "string":
       return e;
      case "function":
       return e.name;
      case "object":
       try {
        return JSON.stringify(e)
       } catch {
        return e.toString()
       }
      default:
       return t
     }
    }
    r.d(t, {
     $b: () => o,
     CK: () => i,
     fU: () => a
    })
   },
   80711(e, t, r) {
    Object.defineProperty(t, Symbol.toStringTag, {
     value: "Module"
    });
    let o = r(1302);
    t.logAndReport = function(e, t, r, n, a, i) {
     return n(o.getShortErrorMsg(e, t, r, a))
    }
   },
   95678(e, t, r) {
    let o = r(76144),
     n = {
      [o.RUNTIME_001]: "Failed to get remoteEntry exports.",
      [o.RUNTIME_002]: 'The remote entry interface does not contain "init"',
      [o.RUNTIME_003]: "Failed to get manifest.",
      [o.RUNTIME_004]: "Failed to locate remote.",
      [o.RUNTIME_005]: "Invalid loadShareSync function call from bundler runtime",
      [o.RUNTIME_006]: "Invalid loadShareSync function call from runtime",
      [o.RUNTIME_007]: "Failed to get remote snapshot.",
      [o.RUNTIME_008]: "Failed to load script resources.",
      [o.RUNTIME_009]: "Please call createInstance first.",
      [o.RUNTIME_010]: 'The name option cannot be changed after initialization. If you want to create a new instance with a different name, please use "createInstance" api.',
      [o.RUNTIME_011]: "The remoteEntry URL is missing from the remote snapshot.",
      [o.RUNTIME_012]: 'The getter for the shared module is not a function. This may be caused by setting "shared.import: false" without the host providing the corresponding lib.'
     },
     a = {
      [o.TYPE_001]: "Failed to generate type declaration. Execute the below cmd to reproduce and fix the error."
     },
     i = {
      [o.BUILD_001]: "Failed to find expose module.",
      [o.BUILD_002]: "PublicPath is required in prod mode."
     },
     s = {
      ...n,
      ...a,
      ...i
     };
    t.buildDescMap = i, t.errorDescMap = s, t.runtimeDescMap = n, t.typeDescMap = a
   },
   76144(e, t) {
    let r = "RUNTIME-001",
     o = "RUNTIME-002",
     n = "RUNTIME-003",
     a = "RUNTIME-004",
     i = "RUNTIME-005",
     s = "RUNTIME-006",
     l = "RUNTIME-007",
     u = "RUNTIME-008",
     c = "RUNTIME-009",
     d = "RUNTIME-010",
     f = "RUNTIME-011",
     p = "RUNTIME-012",
     h = "TYPE-001",
     m = "BUILD-002";
    t.BUILD_001 = "BUILD-001", t.BUILD_002 = m, t.RUNTIME_001 = r, t.RUNTIME_002 = o, t.RUNTIME_003 = n, t.RUNTIME_004 = a, t.RUNTIME_005 = i, t.RUNTIME_006 = s, t.RUNTIME_007 = l, t.RUNTIME_008 = u, t.RUNTIME_009 = c, t.RUNTIME_010 = d, t.RUNTIME_011 = f, t.RUNTIME_012 = p, t.TYPE_001 = h
   },
   1302(e, t) {
    let r = e => `View the docs to see how to solve: https://module-federation.io/guide/troubleshooting/${e.split("-")[0].toLowerCase()}#${e.toLowerCase()}`;
    t.getShortErrorMsg = (e, t, o, n) => {
     let a = [`${[t[e]]} #${e}`];
     return o && a.push(`args: ${JSON.stringify(o)}`), a.push(r(e)), n && a.push(`Original Error Message:
 ${n}`), a.join("\n")
    }
   },
   8583(e, t, r) {
    Object.defineProperty(t, Symbol.toStringTag, {
     value: "Module"
    });
    let o = r(76144),
     n = r(1302),
     a = r(95678);
    t.BUILD_001 = o.BUILD_001, t.BUILD_002 = o.BUILD_002, t.RUNTIME_001 = o.RUNTIME_001, t.RUNTIME_002 = o.RUNTIME_002, t.RUNTIME_003 = o.RUNTIME_003, t.RUNTIME_004 = o.RUNTIME_004, t.RUNTIME_005 = o.RUNTIME_005, t.RUNTIME_006 = o.RUNTIME_006, t.RUNTIME_007 = o.RUNTIME_007, t.RUNTIME_008 = o.RUNTIME_008, t.RUNTIME_009 = o.RUNTIME_009, t.RUNTIME_010 = o.RUNTIME_010, t.RUNTIME_011 = o.RUNTIME_011, t.RUNTIME_012 = o.RUNTIME_012, t.TYPE_001 = o.TYPE_001, t.buildDescMap = a.buildDescMap, t.errorDescMap = a.errorDescMap, t.getShortErrorMsg = n.getShortErrorMsg, t.runtimeDescMap = a.runtimeDescMap, t.typeDescMap = a.typeDescMap
   },
   11757(e, t) {
    var r = Object.defineProperty;
    t.__exportAll = (e, t) => {
     let o = {};
     for (var n in e) r(o, n, {
      get: e[n],
      enumerable: !0
     });
     return t || r(o, Symbol.toStringTag, {
      value: "Module"
     }), o
    }
   },
   19195(e, t) {
    let r = "default";
    t.DEFAULT_REMOTE_TYPE = "global", t.DEFAULT_SCOPE = r
   },
   58238(e, t, r) {
    let o = r(6365),
     n = r(19195),
     a = r(66266),
     i = r(47542),
     s = r(48108),
     l = r(52213);
    r(31255);
    let u = r(45114),
     c = r(65706),
     d = r(63147),
     f = r(51654),
     p = r(63616),
     h = r(14612);
    r(69218);
    let m = r(16053),
     g = r(71913),
     y = r(39541),
     E = r(20337),
     S = r(1228),
     b = r(39839),
     _ = r(8583),
     v = "boolean" != typeof FEDERATION_OPTIMIZE_NO_SNAPSHOT_PLUGIN || !FEDERATION_OPTIMIZE_NO_SNAPSHOT_PLUGIN;
    t.ModuleFederation = class {
     initOptions(e) {
      e.name && e.name !== this.options.name && o.error((0, _.getShortErrorMsg)(_.RUNTIME_010, _.runtimeDescMap)), this.registerPlugins(e.plugins);
      let t = this.formatOptions(this.options, e);
      return this.options = t, t
     }
     async loadShare(e, t) {
      return this.sharedHandler.loadShare(e, t)
     }
     loadShareSync(e, t) {
      return this.sharedHandler.loadShareSync(e, t)
     }
     initializeSharing() {
      let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.DEFAULT_SCOPE,
       t = arguments.length > 1 ? arguments[1] : void 0;
      return this.sharedHandler.initializeSharing(e, t)
     }
     initRawContainer(e, t, r) {
      let o = l.getRemoteInfo({
        name: e,
        entry: t
       }),
       n = new u.Module({
        host: this,
        remoteInfo: o
       });
      return n.remoteEntryExports = r, this.moduleCache.set(e, n), n
     }
     async loadRemote(e, t) {
      return this.remoteHandler.loadRemote(e, t)
     }
     async preloadRemote(e) {
      return this.remoteHandler.preloadRemote(e)
     }
     initShareScopeMap(e, t) {
      let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      this.sharedHandler.initShareScopeMap(e, t, r)
     }
     formatOptions(e, t) {
      let {
       allShareInfos: r
      } = a.formatShareConfigs(e, t), {
       userOptions: o,
       options: n
      } = this.hooks.lifecycle.beforeInit.emit({
       origin: this,
       userOptions: t,
       options: e,
       shareInfo: r
      }), i = this.remoteHandler.formatAndRegisterRemote(n, o), {
       allShareInfos: s
      } = this.sharedHandler.registerShared(n, o), l = [...n.plugins];
      o.plugins && o.plugins.forEach(e => {
       l.includes(e) || l.push(e)
      });
      let u = {
       ...e,
       ...t,
       plugins: l,
       remotes: i,
       shared: s
      };
      return this.hooks.lifecycle.init.emit({
       origin: this,
       options: u
      }), u
     }
     registerPlugins(e) {
      let t = s.registerPlugins(e, this);
      this.options.plugins = this.options.plugins.reduce((e, t) => (t && e && !e.find(e => e.name === t.name) && e.push(t), e), t || [])
     }
     registerRemotes(e, t) {
      return this.remoteHandler.registerRemotes(e, t)
     }
     registerShared(e) {
      this.sharedHandler.registerShared(this.options, {
       ...this.options,
       shared: e
      })
     }
     constructor(e) {
      this.hooks = new h.PluginSystem({
       beforeInit: new f.SyncWaterfallHook("beforeInit"),
       init: new c.SyncHook,
       beforeInitContainer: new p.AsyncWaterfallHook("beforeInitContainer"),
       initContainer: new p.AsyncWaterfallHook("initContainer")
      }), this.version = "2.3.3", this.moduleCache = new Map, this.loaderHook = new h.PluginSystem({
       getModuleInfo: new c.SyncHook,
       createScript: new c.SyncHook,
       createLink: new c.SyncHook,
       fetch: new d.AsyncHook,
       loadEntryError: new d.AsyncHook,
       getModuleFactory: new d.AsyncHook
      }), this.bridgeHook = new h.PluginSystem({
       beforeBridgeRender: new c.SyncHook,
       afterBridgeRender: new c.SyncHook,
       beforeBridgeDestroy: new c.SyncHook,
       afterBridgeDestroy: new c.SyncHook
      });
      const t = v ? [m.snapshotPlugin(), g.generatePreloadAssetsPlugin()] : [],
       r = {
        id: i.getBuilderId(),
        name: e.name,
        plugins: t,
        remotes: [],
        shared: {},
        inBrowser: b.isBrowserEnvValue
       };
      this.name = e.name, this.options = r, this.snapshotHandler = new y.SnapshotHandler(this), this.sharedHandler = new E.SharedHandler(this), this.remoteHandler = new S.RemoteHandler(this), this.shareScopeMap = this.sharedHandler.shareScopeMap, this.registerPlugins([...r.plugins, ...e.plugins || []]), this.options = this.formatOptions(r, e)
     }
    }
   },
   76654(e, t, r) {
    let o = r(6365),
     n = r(88779),
     a = r(39839),
     i = "object" == typeof globalThis ? globalThis : window,
     s = (() => {
      try {
       return document.defaultView
      } catch {
       return i
      }
     })(),
     l = s;

    function u(e, t, r) {
     Object.defineProperty(e, t, {
      value: r,
      configurable: !1,
      writable: !0
     })
    }

    function c(e, t) {
     return Object.hasOwnProperty.call(e, t)
    }
    c(i, "__GLOBAL_LOADING_REMOTE_ENTRY__") || u(i, "__GLOBAL_LOADING_REMOTE_ENTRY__", {});
    let d = i.__GLOBAL_LOADING_REMOTE_ENTRY__;

    function f(e) {
     var t, r, o, n, a, i;
     c(e, "__VMOK__") && !c(e, "__FEDERATION__") && u(e, "__FEDERATION__", e.__VMOK__), c(e, "__FEDERATION__") || (u(e, "__FEDERATION__", {
      __GLOBAL_PLUGIN__: [],
      __INSTANCES__: [],
      moduleInfo: {},
      __SHARE__: {},
      __MANIFEST_LOADING__: {},
      __PRELOADED_MAP__: new Map
     }), u(e, "__VMOK__", e.__FEDERATION__)), (t = e.__FEDERATION__).__GLOBAL_PLUGIN__ ?? (t.__GLOBAL_PLUGIN__ = []), (r = e.__FEDERATION__).__INSTANCES__ ?? (r.__INSTANCES__ = []), (o = e.__FEDERATION__).moduleInfo ?? (o.moduleInfo = {}), (n = e.__FEDERATION__).__SHARE__ ?? (n.__SHARE__ = {}), (a = e.__FEDERATION__).__MANIFEST_LOADING__ ?? (a.__MANIFEST_LOADING__ = {}), (i = e.__FEDERATION__).__PRELOADED_MAP__ ?? (i.__PRELOADED_MAP__ = new Map)
    }

    function p() {
     i.__FEDERATION__.__GLOBAL_PLUGIN__ = [], i.__FEDERATION__.__INSTANCES__ = [], i.__FEDERATION__.moduleInfo = {}, i.__FEDERATION__.__SHARE__ = {}, i.__FEDERATION__.__MANIFEST_LOADING__ = {}, Object.keys(d).forEach(e => {
      delete d[e]
     })
    }

    function h(e) {
     i.__FEDERATION__.__INSTANCES__.push(e)
    }

    function m() {
     return i.__FEDERATION__.__DEBUG_CONSTRUCTOR__
    }

    function g(e) {
     let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : (0, a.isDebugMode)();
     t && (i.__FEDERATION__.__DEBUG_CONSTRUCTOR__ = e, i.__FEDERATION__.__DEBUG_CONSTRUCTOR_VERSION__ = "2.3.3")
    }

    function y(e, t) {
     if ("string" == typeof t)
      if (e[t]) return {
       value: e[t],
       key: t
      };
      else {
       for (let r of Object.keys(e)) {
        let [o, n] = r.split(":"), a = `${o}:${t}`, i = e[a];
        if (i) return {
         value: i,
         key: a
        }
       }
       return {
        value: void 0,
        key: t
       }
      } o.error(`getInfoWithoutType: "key" must be a string, got ${typeof t} (${JSON.stringify(t)}).`)
    }
    f(i), f(s);
    let E = () => s.__FEDERATION__.moduleInfo,
     S = (e, t) => {
      let r = y(t, n.getFMId(e)).value;
      if (r && !r.version && "version" in e && e.version && (r.version = e.version), r) return r;
      if ("version" in e && e.version) {
       let {
        version: t,
        ...r
       } = e, o = n.getFMId(r), a = y(s.__FEDERATION__.moduleInfo, o).value;
       if ((null == a ? void 0 : a.version) === t) return a
      }
     },
     b = e => S(e, s.__FEDERATION__.moduleInfo),
     _ = (e, t) => {
      let r = n.getFMId(e);
      return s.__FEDERATION__.moduleInfo[r] = t, s.__FEDERATION__.moduleInfo
     },
     v = e => (s.__FEDERATION__.moduleInfo = {
      ...s.__FEDERATION__.moduleInfo,
      ...e
     }, () => {
      for (let t of Object.keys(e)) delete s.__FEDERATION__.moduleInfo[t]
     }),
     I = (e, t) => {
      let r = t || `__FEDERATION_${e}:custom__`;
      return {
       remoteEntryKey: r,
       entryExports: i[r]
      }
     },
     R = e => {
      let {
       __GLOBAL_PLUGIN__: t
      } = s.__FEDERATION__;
      e.forEach(e => {
       -1 === t.findIndex(t => t.name === e.name) ? t.push(e) : o.warn(`The plugin ${e.name} has been registered.`)
      })
     },
     T = () => s.__FEDERATION__.__GLOBAL_PLUGIN__,
     M = e => i.__FEDERATION__.__PRELOADED_MAP__.get(e),
     N = e => i.__FEDERATION__.__PRELOADED_MAP__.set(e, !0);
    t.CurrentGlobal = i, t.Global = l, t.addGlobalSnapshot = v, t.getGlobalFederationConstructor = m, t.getGlobalHostPlugins = T, t.getGlobalSnapshot = E, t.getGlobalSnapshotInfoByModuleInfo = b, t.getInfoWithoutType = y, t.getPreloaded = M, t.getRemoteEntryExports = I, t.getTargetSnapshotInfoByModuleInfo = S, t.globalLoading = d, t.nativeGlobal = s, t.registerGlobalPlugins = R, t.resetFederationGlobalInfo = p, t.setGlobalFederationConstructor = g, t.setGlobalFederationInstance = h, t.setGlobalSnapshotInfoByModuleInfo = _, t.setPreloaded = N
   },
   43754(e, t, r) {
    let o = r(76654),
     n = r(66266),
     a = r(9950),
     i = r(52213);
    r(31255);
    let s = r(94988),
     l = {
      getRegisteredShare: n.getRegisteredShare,
      getGlobalShareScope: n.getGlobalShareScope
     };
    t.default = {
     global: {
      Global: o.Global,
      nativeGlobal: o.nativeGlobal,
      resetFederationGlobalInfo: o.resetFederationGlobalInfo,
      setGlobalFederationInstance: o.setGlobalFederationInstance,
      getGlobalFederationConstructor: o.getGlobalFederationConstructor,
      setGlobalFederationConstructor: o.setGlobalFederationConstructor,
      getInfoWithoutType: o.getInfoWithoutType,
      getGlobalSnapshot: o.getGlobalSnapshot,
      getTargetSnapshotInfoByModuleInfo: o.getTargetSnapshotInfoByModuleInfo,
      getGlobalSnapshotInfoByModuleInfo: o.getGlobalSnapshotInfoByModuleInfo,
      setGlobalSnapshotInfoByModuleInfo: o.setGlobalSnapshotInfoByModuleInfo,
      addGlobalSnapshot: o.addGlobalSnapshot,
      getRemoteEntryExports: o.getRemoteEntryExports,
      registerGlobalPlugins: o.registerGlobalPlugins,
      getGlobalHostPlugins: o.getGlobalHostPlugins,
      getPreloaded: o.getPreloaded,
      setPreloaded: o.setPreloaded
     },
     share: l,
     utils: {
      matchRemoteWithNameAndExpose: a.matchRemoteWithNameAndExpose,
      preloadAssets: s.preloadAssets,
      getRemoteInfo: i.getRemoteInfo
     }
    }
   },
   34085(e, t, r) {
    Object.defineProperty(t, Symbol.toStringTag, {
     value: "Module"
    });
    let o = r(6365),
     n = r(88779),
     a = r(76654),
     i = r(9272),
     s = r(66266),
     l = r(9950),
     u = r(52213);
    r(31255);
    let c = r(43754),
     d = r(45114),
     f = r(58238),
     p = r(91914),
     h = r(39839),
     m = c.default;
    t.CurrentGlobal = a.CurrentGlobal, t.Global = a.Global, t.Module = d.Module, t.ModuleFederation = f.ModuleFederation, t.addGlobalSnapshot = a.addGlobalSnapshot, t.assert = o.assert, t.error = o.error, t.getGlobalFederationConstructor = a.getGlobalFederationConstructor, t.getGlobalSnapshot = a.getGlobalSnapshot, t.getInfoWithoutType = a.getInfoWithoutType, t.getRegisteredShare = s.getRegisteredShare, t.getRemoteEntry = u.getRemoteEntry, t.getRemoteInfo = u.getRemoteInfo, t.helpers = m, t.isStaticResourcesEqual = n.isStaticResourcesEqual, Object.defineProperty(t, "loadScript", {
     enumerable: !0,
     get: function() {
      return h.loadScript
     }
    }), Object.defineProperty(t, "loadScriptNode", {
     enumerable: !0,
     get: function() {
      return h.loadScriptNode
     }
    }), t.matchRemoteWithNameAndExpose = l.matchRemoteWithNameAndExpose, t.registerGlobalPlugins = a.registerGlobalPlugins, t.resetFederationGlobalInfo = a.resetFederationGlobalInfo, t.safeWrapper = n.safeWrapper, t.satisfy = i.satisfy, t.setGlobalFederationConstructor = a.setGlobalFederationConstructor, t.setGlobalFederationInstance = a.setGlobalFederationInstance, Object.defineProperty(t, "types", {
     enumerable: !0,
     get: function() {
      return p.type_exports
     }
    })
   },
   45114(e, t, r) {
    let o = r(6365),
     n = r(88779),
     a = r(52213),
     i = r(24330);
    r(31255);
    let s = r(39839),
     l = r(8583);

    function u(e, t, r) {
     let o = t,
      n = Array.isArray(e.shareScope) ? e.shareScope : [e.shareScope];
     n.length || n.push("default"), n.forEach(e => {
      o[e] || (o[e] = {})
     });
     let a = {
      version: e.version || "",
      shareScopeKeys: Array.isArray(e.shareScope) ? n : e.shareScope || "default"
     };
     return Object.defineProperty(a, "shareScopeMap", {
      value: o,
      enumerable: !1
     }), {
      remoteEntryInitOptions: a,
      shareScope: o[n[0]],
      initScope: r ?? []
     }
    }
    t.Module = class {
     async getEntry() {
      if (this.remoteEntryExports) return this.remoteEntryExports;
      let e = await a.getRemoteEntry({
       origin: this.host,
       remoteInfo: this.remoteInfo,
       remoteEntryExports: this.remoteEntryExports
      });
      return o.assert(e, `remoteEntryExports is undefined 
 ${(0,s.safeToString)(this.remoteInfo)}`), this.remoteEntryExports = e, this.remoteEntryExports
     }
     async init(e, t, r) {
      let n = await this.getEntry();
      if (this.inited) return n;
      if (this.initPromise) return await this.initPromise, n;
      this.initing = !0, this.initPromise = (async () => {
       let {
        remoteEntryInitOptions: a,
        shareScope: s,
        initScope: c
       } = u(this.remoteInfo, this.host.shareScopeMap, r), d = await this.host.hooks.lifecycle.beforeInitContainer.emit({
        shareScope: s,
        remoteEntryInitOptions: a,
        initScope: c,
        remoteInfo: this.remoteInfo,
        origin: this.host
       });
       void 0 === (null == n ? void 0 : n.init) && o.error(l.RUNTIME_002, l.runtimeDescMap, {
        hostName: this.host.name,
        remoteName: this.remoteInfo.name,
        remoteEntryUrl: this.remoteInfo.entry,
        remoteEntryKey: this.remoteInfo.entryGlobalName
       }, void 0, i.optionsToMFContext(this.host.options)), await n.init(d.shareScope, d.initScope, d.remoteEntryInitOptions), await this.host.hooks.lifecycle.initContainer.emit({
        ...d,
        id: e,
        remoteSnapshot: t,
        remoteEntryExports: n
       }), this.inited = !0
      })();
      try {
       await this.initPromise
      } finally {
       this.initing = !1, this.initPromise = void 0
      }
      return n
     }
     async get(e, t, r, a) {
      let i, {
        loadFactory: s = !0
       } = r || {
        loadFactory: !0
       },
       l = await this.init(e, a);
      this.lib = l, (i = await this.host.loaderHook.lifecycle.getModuleFactory.emit({
       remoteEntryExports: l,
       expose: t,
       moduleInfo: this.remoteInfo
      })) || (i = await l.get(t)), o.assert(i, `${n.getFMId(this.remoteInfo)} remote don't export ${t}.`);
      let u = n.processModuleAlias(this.remoteInfo.name, t),
       c = this.wraperFactory(i, u);
      return s ? await c() : c
     }
     wraperFactory(e, t) {
      function r(e, t) {
       e && "object" == typeof e && Object.isExtensible(e) && !Object.getOwnPropertyDescriptor(e, Symbol.for("mf_module_id")) && Object.defineProperty(e, Symbol.for("mf_module_id"), {
        value: t,
        enumerable: !1
       })
      }
      return e instanceof Promise ? async () => {
       let o = await e();
       return r(o, t), o
      }: () => {
       let o = e();
       return r(o, t), o
      }
     }
     constructor({
      remoteInfo: e,
      host: t
     }) {
      this.inited = !1, this.initing = !1, this.lib = void 0, this.remoteInfo = e, this.host = t
     }
    }
   },
   71913(e, t, r) {
    let o = r(88779),
     n = r(76654),
     a = r(66266);
    r(31255);
    let i = r(94988),
     s = r(16053),
     l = r(39839);

    function u(e) {
     let t = e.split(":");
     return 1 === t.length ? {
      name: t[0],
      version: void 0
     } : 2 === t.length ? {
      name: t[0],
      version: t[1]
     } : {
      name: t[1],
      version: t[2]
     }
    }

    function c(e, t, r, a) {
     let i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {},
      s = arguments.length > 5 ? arguments[5] : void 0,
      {
       value: d
      } = n.getInfoWithoutType(e, o.getFMId(t)),
      f = s || d;
     if (f && !(0, l.isManifestProvider)(f) && (r(f, t, a), f.remotesInfo))
      for (let t of Object.keys(f.remotesInfo)) {
       if (i[t]) continue;
       i[t] = !0;
       let o = u(t),
        n = f.remotesInfo[t];
       c(e, {
        name: o.name,
        version: n.matchedVersion
       }, r, !1, i, void 0)
      }
    }
    let d = (e, t) => document.querySelector(`${e}[${"link"===e?"href":"src"}="${t}"]`);

    function f(e, t, r, s, u) {
     let f = [],
      p = [],
      h = [],
      m = new Set,
      g = new Set,
      {
       options: y
      } = e,
      {
       preloadConfig: E
      } = t,
      {
       depsRemote: S
      } = E;
     if (c(s, r, (t, r, a) => {
       var s;
       let u;
       if (a) u = E;
       else if (Array.isArray(S)) {
        let e = S.find(e => e.nameOrAlias === r.name || e.nameOrAlias === r.alias);
        if (!e) return;
        u = i.defaultPreloadArgs(e)
       } else {
        if (!0 !== S) return;
        u = E
       }
       let c = (0, l.getResourceUrl)(t, o.getRemoteEntryInfoFromSnapshot(t).url);
       c && h.push({
        name: r.name,
        moduleInfo: {
         name: r.name,
         entry: c,
         type: "remoteEntryType" in t ? t.remoteEntryType : "global",
         entryGlobalName: "globalName" in t ? t.globalName : r.name,
         shareScope: "",
         version: "version" in t ? t.version : void 0
        },
        url: c
       });
       let d = "modules" in t ? t.modules : [],
        m = i.normalizePreloadExposes(u.exposes);

       function g(e) {
        let r = e.map(e => (0, l.getResourceUrl)(t, e));
        return u.filter ? r.filter(u.filter) : r
       }
       if (m.length && "modules" in t && (d = null == t || null == (s = t.modules) ? void 0 : s.reduce((e, t) => ((null == m ? void 0 : m.indexOf(t.moduleName)) !== -1 && e.push(t), e), [])), d) {
        let o = d.length;
        for (let a = 0; a < o; a++) {
         let o = d[a],
          i = `${r.name}/${o.moduleName}`;
         e.remoteHandler.hooks.lifecycle.handlePreloadModule.emit({
          id: "." === o.moduleName ? r.name : i,
          name: r.name,
          remoteSnapshot: t,
          preloadConfig: u,
          remote: r,
          origin: e
         }), n.getPreloaded(i) || ("all" === u.resourceCategory ? (f.push(...g(o.assets.css.async)), f.push(...g(o.assets.css.sync)), p.push(...g(o.assets.js.async)), p.push(...g(o.assets.js.sync))) : "sync" === u.resourceCategory && (f.push(...g(o.assets.css.sync)), p.push(...g(o.assets.js.sync))), n.setPreloaded(i))
        }
       }
      }, !0, {}, u), u.shared && u.shared.length > 0) {
      let t = (t, r) => {
       let {
        shared: o
       } = a.getRegisteredShare(e.shareScopeMap, r.sharedName, t, e.sharedHandler.hooks.lifecycle.resolveShare) || {};
       o && "function" == typeof o.lib && (r.assets.js.sync.forEach(e => {
        m.add(e)
       }), r.assets.css.sync.forEach(e => {
        g.add(e)
       }))
      };
      u.shared.forEach(e => {
       var r;
       let n = null == (r = y.shared) ? void 0 : r[e.sharedName];
       if (!n) return;
       let a = e.version ? n.find(t => t.version === e.version) : n;
       a && o.arrayOptions(a).forEach(r => {
        t(r, e)
       })
      })
     }
     let b = p.filter(e => !m.has(e) && !d("script", e));
     return {
      cssAssets: f.filter(e => !g.has(e) && !d("link", e)),
      jsAssetsWithoutEntry: b,
      entryAssets: h.filter(e => !d("script", e.url))
     }
    }
    t.generatePreloadAssetsPlugin = function() {
     return {
      name: "generate-preload-assets-plugin",
      async generatePreloadAssets(e) {
       let {
        origin: t,
        preloadOptions: r,
        remoteInfo: n,
        remote: a,
        globalSnapshot: i,
        remoteSnapshot: u
       } = e;
       return l.isBrowserEnvValue ? o.isRemoteInfoWithEntry(a) && o.isPureRemoteEntry(a) ? {
        cssAssets: [],
        jsAssetsWithoutEntry: [],
        entryAssets: [{
         name: a.name,
         url: a.entry,
         moduleInfo: {
          name: n.name,
          entry: a.entry,
          type: n.type || "global",
          entryGlobalName: "",
          shareScope: ""
         }
        }]
       } : (s.assignRemoteInfo(n, u), f(t, r, n, i, u)) : {
        cssAssets: [],
        jsAssetsWithoutEntry: [],
        entryAssets: []
       }
      }
     }
    }
   },
   39541(e, t, r) {
    let o = r(6365),
     n = r(88779),
     a = r(76654),
     i = r(52213),
     s = r(24330);
    r(31255);
    let l = r(63147),
     u = r(63616),
     c = r(14612);
    r(69218);
    let d = r(39839),
     f = r(8583);

    function p(e, t) {
     let r = a.getGlobalSnapshotInfoByModuleInfo({
       name: t.name,
       version: t.options.version
      }),
      o = r && "remotesInfo" in r && r.remotesInfo && a.getInfoWithoutType(r.remotesInfo, e.name).value;
     return o && o.matchedVersion ? {
      hostGlobalSnapshot: r,
      globalSnapshot: a.getGlobalSnapshot(),
      remoteSnapshot: a.getGlobalSnapshotInfoByModuleInfo({
       name: e.name,
       version: o.matchedVersion
      })
     } : {
      hostGlobalSnapshot: void 0,
      globalSnapshot: a.getGlobalSnapshot(),
      remoteSnapshot: a.getGlobalSnapshotInfoByModuleInfo({
       name: e.name,
       version: "version" in e ? e.version : void 0
      })
     }
    }
    t.SnapshotHandler = class {
     async loadRemoteSnapshotInfo(e) {
      let t, r, {
        moduleInfo: i,
        id: l,
        expose: u
       } = e,
       {
        options: c
       } = this.HostInstance;
      await this.hooks.lifecycle.beforeLoadRemoteSnapshot.emit({
       options: c,
       moduleInfo: i
      });
      let p = a.getGlobalSnapshotInfoByModuleInfo({
       name: this.HostInstance.options.name,
       version: this.HostInstance.options.version
      });
      p || (p = {
       version: this.HostInstance.options.version || "",
       remoteEntry: "",
       remotesInfo: {}
      }, a.addGlobalSnapshot({
       [this.HostInstance.options.name]: p
      })), p && "remotesInfo" in p && !a.getInfoWithoutType(p.remotesInfo, i.name).value && ("version" in i || "entry" in i) && (p.remotesInfo = {
       ...null == p ? void 0 : p.remotesInfo,
       [i.name]: {
        matchedVersion: "version" in i ? i.version : i.entry
       }
      });
      let {
       hostGlobalSnapshot: h,
       remoteSnapshot: m,
       globalSnapshot: g
      } = this.getGlobalRemoteInfo(i), {
       remoteSnapshot: y,
       globalSnapshot: E
      } = await this.hooks.lifecycle.loadSnapshot.emit({
       options: c,
       moduleInfo: i,
       hostGlobalSnapshot: h,
       remoteSnapshot: m,
       globalSnapshot: g
      });
      if (y)
       if ((0, d.isManifestProvider)(y)) {
        let e = d.isBrowserEnvValue ? y.remoteEntry : y.ssrRemoteEntry || y.remoteEntry || "",
         o = await this.getManifestJson(e, i, {}),
         n = a.setGlobalSnapshotInfoByModuleInfo({
          ...i,
          entry: e
         }, o);
        t = o, r = n
       } else {
        let {
         remoteSnapshot: e
        } = await this.hooks.lifecycle.loadRemoteSnapshot.emit({
         options: this.HostInstance.options,
         moduleInfo: i,
         remoteSnapshot: y,
         from: "global"
        });
        t = e, r = E
       }
      else if (n.isRemoteInfoWithEntry(i)) {
       let e = await this.getManifestJson(i.entry, i, {}),
        o = a.setGlobalSnapshotInfoByModuleInfo(i, e),
        {
         remoteSnapshot: n
        } = await this.hooks.lifecycle.loadRemoteSnapshot.emit({
         options: this.HostInstance.options,
         moduleInfo: i,
         remoteSnapshot: e,
         from: "global"
        });
       t = n, r = o
      } else o.error(f.RUNTIME_007, f.runtimeDescMap, {
       remoteName: i.name,
       remoteVersion: i.version,
       hostName: this.HostInstance.options.name,
       globalSnapshot: JSON.stringify(E)
      }, void 0, s.optionsToMFContext(this.HostInstance.options));
      return await this.hooks.lifecycle.afterLoadSnapshot.emit({
       id: l,
       host: this.HostInstance,
       options: c,
       moduleInfo: i,
       remoteSnapshot: t
      }), {
       remoteSnapshot: t,
       globalSnapshot: r
      }
     }
     getGlobalRemoteInfo(e) {
      return p(e, this.HostInstance)
     }
     async getManifestJson(e, t, r) {
      let n = async () => {
       let r = this.manifestCache.get(e);
       if (r) return r;
       try {
        let o = await this.loaderHook.lifecycle.fetch.emit(e, {}, i.getRemoteInfo(t));
        o && o instanceof Response || (o = await fetch(e, {})), r = await o.json()
       } catch (n) {
        (r = await this.HostInstance.remoteHandler.hooks.lifecycle.errorLoadRemote.emit({
         id: e,
         error: n,
         from: "runtime",
         lifecycle: "afterResolve",
         origin: this.HostInstance
        })) || (delete this.manifestLoading[e], o.error(f.RUNTIME_003, f.runtimeDescMap, {
         manifestUrl: e,
         moduleName: t.name,
         hostName: this.HostInstance.options.name
        }, `${n}`, s.optionsToMFContext(this.HostInstance.options)))
       }
       return o.assert(r.metaData && r.exposes && r.shared, `"${e}" is not a valid federation manifest for remote "${t.name}". Missing required fields: ${[!r.metaData&&"metaData",!r.exposes&&"exposes",!r.shared&&"shared"].filter(Boolean).join(", ")}.`), this.manifestCache.set(e, r), r
      }, a = async () => {
       let r = await n(),
        o = (0, d.generateSnapshotFromManifest)(r, {
         version: e
        }),
        {
         remoteSnapshot: a
        } = await this.hooks.lifecycle.loadRemoteSnapshot.emit({
         options: this.HostInstance.options,
         moduleInfo: t,
         manifestJson: r,
         remoteSnapshot: o,
         manifestUrl: e,
         from: "manifest"
        });
       return a
      };
      return this.manifestLoading[e] || (this.manifestLoading[e] = a().then(e => e)), this.manifestLoading[e]
     }
     constructor(e) {
      this.loadingHostSnapshot = null, this.manifestCache = new Map, this.hooks = new c.PluginSystem({
       beforeLoadRemoteSnapshot: new l.AsyncHook("beforeLoadRemoteSnapshot"),
       loadSnapshot: new u.AsyncWaterfallHook("loadGlobalSnapshot"),
       loadRemoteSnapshot: new u.AsyncWaterfallHook("loadRemoteSnapshot"),
       afterLoadSnapshot: new u.AsyncWaterfallHook("afterLoadSnapshot")
      }), this.manifestLoading = a.Global.__FEDERATION__.__MANIFEST_LOADING__, this.HostInstance = e, this.loaderHook = e.loaderHook
     }
    }, t.getGlobalRemoteInfo = p
   },
   16053(e, t, r) {
    let o = r(6365),
     n = r(88779);
    r(31255);
    let a = r(94988),
     i = r(39839),
     s = r(8583);

    function l(e, t) {
     let r = n.getRemoteEntryInfoFromSnapshot(t);
     r.url || o.error(s.RUNTIME_011, s.runtimeDescMap, {
      remoteName: e.name
     });
     let a = (0, i.getResourceUrl)(t, r.url);
     i.isBrowserEnvValue || a.startsWith("http") || (a = `https:${a}`), e.type = r.type, e.entryGlobalName = r.globalName, e.entry = a, e.version = t.version, e.buildVersion = t.buildVersion
    }

    function u() {
     return {
      name: "snapshot-plugin",
      async afterResolve(e) {
       let {
        remote: t,
        pkgNameOrAlias: r,
        expose: o,
        origin: i,
        remoteInfo: s,
        id: u
       } = e;
       if (!n.isRemoteInfoWithEntry(t) || !n.isPureRemoteEntry(t)) {
        let {
         remoteSnapshot: n,
         globalSnapshot: c
        } = await i.snapshotHandler.loadRemoteSnapshotInfo({
         moduleInfo: t,
         id: u
        });
        l(s, n);
        let d = {
          remote: t,
          preloadConfig: {
           nameOrAlias: r,
           exposes: [o],
           resourceCategory: "sync",
           share: !1,
           depsRemote: !1
          }
         },
         f = await i.remoteHandler.hooks.lifecycle.generatePreloadAssets.emit({
          origin: i,
          preloadOptions: d,
          remoteInfo: s,
          remote: t,
          remoteSnapshot: n,
          globalSnapshot: c
         });
        return f && a.preloadAssets(s, i, f, !1), {
         ...e,
         remoteSnapshot: n
        }
       }
       return e
      }
     }
    }
    t.assignRemoteInfo = l, t.snapshotPlugin = u
   },
   1228(e, t, r) {
    let o = r(6365),
     n = r(76654),
     a = r(19195),
     i = r(66266),
     s = r(9950),
     l = r(52213),
     u = r(24330);
    r(31255);
    let c = r(94988),
     d = r(45114),
     f = r(65706),
     p = r(63147),
     h = r(51654),
     m = r(63616),
     g = r(14612);
    r(69218);
    let y = r(39541),
     E = r(39839),
     S = r(8583);
    t.RemoteHandler = class {
     formatAndRegisterRemote(e, t) {
      return (t.remotes || []).reduce((e, t) => (this.registerRemote(t, e, {
       force: !1
      }), e), e.remotes)
     }
     setIdToRemoteMap(e, t) {
      let {
       remote: r,
       expose: o
      } = t, {
       name: n,
       alias: a
      } = r;
      if (this.idToRemoteMap[e] = {
        name: r.name,
        expose: o
       }, a && e.startsWith(n)) {
       let t = e.replace(n, a);
       this.idToRemoteMap[t] = {
        name: r.name,
        expose: o
       };
       return
      }
      if (a && e.startsWith(a)) {
       let t = e.replace(a, n);
       this.idToRemoteMap[t] = {
        name: r.name,
        expose: o
       }
      }
     }
     async loadRemote(e, t) {
      let {
       host: r
      } = this;
      try {
       let {
        loadFactory: o = !0
       } = t || {
        loadFactory: !0
       }, {
        module: n,
        moduleOptions: a,
        remoteMatchInfo: i
       } = await this.getRemoteModuleAndOptions({
        id: e
       }), {
        pkgNameOrAlias: s,
        remote: l,
        expose: u,
        id: c,
        remoteSnapshot: d
       } = i, f = await n.get(c, u, t, d), p = await this.hooks.lifecycle.onLoad.emit({
        id: c,
        pkgNameOrAlias: s,
        expose: u,
        exposeModule: o ? f : void 0,
        exposeModuleFactory: o ? void 0 : f,
        remote: l,
        options: a,
        moduleInstance: n,
        origin: r
       });
       if (this.setIdToRemoteMap(e, i), "function" == typeof p) return p;
       return f
      } catch (a) {
       let {
        from: o = "runtime"
       } = t || {
        from: "runtime"
       }, n = await this.hooks.lifecycle.errorLoadRemote.emit({
        id: e,
        error: a,
        from: o,
        lifecycle: "onLoad",
        origin: r
       });
       if (!n) throw a;
       return n
      }
     }
     async preloadRemote(e) {
      let {
       host: t
      } = this;
      await this.hooks.lifecycle.beforePreloadRemote.emit({
       preloadOps: e,
       options: t.options,
       origin: t
      });
      let r = c.formatPreloadArgs(t.options.remotes, e);
      await Promise.all(r.map(async e => {
       let {
        remote: r
       } = e, o = l.getRemoteInfo(r), {
        globalSnapshot: n,
        remoteSnapshot: a
       } = await t.snapshotHandler.loadRemoteSnapshotInfo({
        moduleInfo: r
       }), i = await this.hooks.lifecycle.generatePreloadAssets.emit({
        origin: t,
        preloadOptions: e,
        remote: r,
        remoteInfo: o,
        globalSnapshot: n,
        remoteSnapshot: a
       });
       i && c.preloadAssets(o, t, i)
      }))
     }
     registerRemotes(e, t) {
      let {
       host: r
      } = this;
      e.forEach(e => {
       this.registerRemote(e, r.options.remotes, {
        force: null == t ? void 0 : t.force
       })
      })
     }
     async getRemoteModuleAndOptions(e) {
      let t, {
        host: r
       } = this,
       {
        id: n
       } = e;
      try {
       t = await this.hooks.lifecycle.beforeRequest.emit({
        id: n,
        options: r.options,
        origin: r
       })
      } catch (e) {
       if (!(t = await this.hooks.lifecycle.errorLoadRemote.emit({
         id: n,
         options: r.options,
         origin: r,
         from: "runtime",
         error: e,
         lifecycle: "beforeRequest"
        }))) throw e
      }
      let {
       id: a
      } = t, i = s.matchRemoteWithNameAndExpose(r.options.remotes, a);
      i || o.error(S.RUNTIME_004, S.runtimeDescMap, {
       hostName: r.options.name,
       requestId: a
      }, void 0, u.optionsToMFContext(r.options));
      let {
       remote: c
      } = i, f = l.getRemoteInfo(c), p = await r.sharedHandler.hooks.lifecycle.afterResolve.emit({
       id: a,
       ...i,
       options: r.options,
       origin: r,
       remoteInfo: f
      }), {
       remote: h,
       expose: m
      } = p;
      o.assert(h && m, `The 'beforeRequest' hook was executed, but it failed to return the correct 'remote' and 'expose' values while loading ${a}.`);
      let g = r.moduleCache.get(h.name),
       y = {
        host: r,
        remoteInfo: f
       };
      return g || (g = new d.Module(y), r.moduleCache.set(h.name, g)), {
       module: g,
       moduleOptions: y,
       remoteMatchInfo: p
      }
     }
     registerRemote(e, t, r) {
      let {
       host: n
      } = this, i = () => {
       if (e.alias) {
        let r = t.find(t => {
         var r;
         return e.alias && (t.name.startsWith(e.alias) || (null == (r = t.alias) ? void 0 : r.startsWith(e.alias)))
        });
        o.assert(!r, `The alias ${e.alias} of remote ${e.name} is not allowed to be the prefix of ${r&&r.name} name or alias`)
       }
       "entry" in e && E.isBrowserEnvValue && "u" > typeof window && !e.entry.startsWith("http") && (e.entry = new URL(e.entry, window.location.origin).href), e.shareScope || (e.shareScope = a.DEFAULT_SCOPE), e.type || (e.type = a.DEFAULT_REMOTE_TYPE)
      };
      this.hooks.lifecycle.beforeRegisterRemote.emit({
       remote: e,
       origin: n
      });
      let s = t.find(t => t.name === e.name);
      if (s) {
       let o = [`The remote "${e.name}" is already registered.`, "Please note that overriding it may cause unexpected errors."];
       (null == r ? void 0 : r.force) && (this.removeRemote(s), i(), t.push(e), this.hooks.lifecycle.registerRemote.emit({
        remote: e,
        origin: n
       }), (0, E.warn)(o.join(" ")))
      } else i(), t.push(e), this.hooks.lifecycle.registerRemote.emit({
       remote: e,
       origin: n
      })
     }
     removeRemote(e) {
      try {
       let {
        host: r
       } = this, {
        name: o
       } = e, a = r.options.remotes.findIndex(e => e.name === o); - 1 !== a && r.options.remotes.splice(a, 1);
       let s = r.moduleCache.get(e.name);
       if (s) {
        var t;
        let o = s.remoteInfo,
         a = o.entryGlobalName;
        n.CurrentGlobal[a] && ((null == (t = Object.getOwnPropertyDescriptor(n.CurrentGlobal, a)) ? void 0 : t.configurable) ? delete n.CurrentGlobal[a] : n.CurrentGlobal[a] = void 0);
        let u = l.getRemoteEntryUniqueKey(s.remoteInfo);
        n.globalLoading[u] && delete n.globalLoading[u], r.snapshotHandler.manifestCache.delete(o.entry);
        let c = o.buildVersion ? (0, E.composeKeyWithSeparator)(o.name, o.buildVersion) : o.name,
         d = n.CurrentGlobal.__FEDERATION__.__INSTANCES__.findIndex(e => o.buildVersion ? e.options.id === c : e.name === c);
        if (-1 !== d) {
         let e = n.CurrentGlobal.__FEDERATION__.__INSTANCES__[d];
         c = e.options.id || c;
         let t = i.getGlobalShareScope(),
          r = !0,
          a = [];
         Object.keys(t).forEach(e => {
          let n = t[e];
          n && Object.keys(n).forEach(t => {
           let i = n[t];
           i && Object.keys(i).forEach(n => {
            let s = i[n];
            s && Object.keys(s).forEach(i => {
             let l = s[i];
             l && "object" == typeof l && l.from === o.name && (l.loaded || l.loading ? (l.useIn = l.useIn.filter(e => e !== o.name), l.useIn.length ? r = !1 : a.push([e, t, n, i])) : a.push([e, t, n, i]))
            })
           })
          })
         }), r && (e.shareScopeMap = {}, delete t[c]), a.forEach(e => {
          var r, o, n;
          let [a, i, s, l] = e;
          null == (n = t[a]) || null == (o = n[i]) || null == (r = o[s]) || delete r[l]
         }), n.CurrentGlobal.__FEDERATION__.__INSTANCES__.splice(d, 1)
        }
        let {
         hostGlobalSnapshot: f
        } = y.getGlobalRemoteInfo(e, r);
        if (f) {
         let t = f && "remotesInfo" in f && f.remotesInfo && n.getInfoWithoutType(f.remotesInfo, e.name).key;
         t && (delete f.remotesInfo[t], n.Global.__FEDERATION__.__MANIFEST_LOADING__[t] && delete n.Global.__FEDERATION__.__MANIFEST_LOADING__[t])
        }
        r.moduleCache.delete(e.name)
       }
      } catch (e) {
       o.logger.error(`removeRemote failed: ${e instanceof Error?e.message:String(e)}`)
      }
     }
     constructor(e) {
      this.hooks = new g.PluginSystem({
       beforeRegisterRemote: new h.SyncWaterfallHook("beforeRegisterRemote"),
       registerRemote: new h.SyncWaterfallHook("registerRemote"),
       beforeRequest: new m.AsyncWaterfallHook("beforeRequest"),
       onLoad: new p.AsyncHook("onLoad"),
       handlePreloadModule: new f.SyncHook("handlePreloadModule"),
       errorLoadRemote: new p.AsyncHook("errorLoadRemote"),
       beforePreloadRemote: new p.AsyncHook("beforePreloadRemote"),
       generatePreloadAssets: new p.AsyncHook("generatePreloadAssets"),
       afterPreloadRemote: new p.AsyncHook,
       loadEntry: new p.AsyncHook
      }), this.host = e, this.idToRemoteMap = {}
     }
    }
   },
   20337(e, t, r) {
    let o = r(6365),
     n = r(19195),
     a = r(66266),
     i = r(24330);
    r(31255);
    let s = r(63147),
     l = r(51654),
     u = r(63616),
     c = r(14612);
    r(69218);
    let d = r(8583);
    t.SharedHandler = class {
     registerShared(e, t) {
      let {
       newShareInfos: r,
       allShareInfos: o
      } = a.formatShareConfigs(e, t);
      return Object.keys(r).forEach(e => {
       r[e].forEach(r => {
        r.scope.forEach(o => {
         var n;
         this.hooks.lifecycle.beforeRegisterShare.emit({
          origin: this.host,
          pkgName: e,
          shared: r
         }), (null == (n = this.shareScopeMap[o]) ? void 0 : n[e]) || this.setShared({
          pkgName: e,
          lib: r.lib,
          get: r.get,
          loaded: r.loaded || !!r.lib,
          shared: r,
          from: t.name
         })
        })
       })
      }), {
       newShareInfos: r,
       allShareInfos: o
      }
     }
     async loadShare(e, t) {
      let {
       host: r
      } = this, n = a.getTargetSharedOptions({
       pkgName: e,
       extraOptions: t,
       shareInfos: r.options.shared
      });
      (null == n ? void 0 : n.scope) && await Promise.all(n.scope.map(async e => {
       await Promise.all(this.initializeSharing(e, {
        strategy: n.strategy
       }))
      }));
      let {
       shareInfo: i
      } = await this.hooks.lifecycle.beforeLoadShare.emit({
       pkgName: e,
       shareInfo: n,
       shared: r.options.shared,
       origin: r
      });
      o.assert(i, `Cannot find shared "${e}" in host "${r.options.name}". Ensure the shared config for "${e}" is declared in the federation plugin options and the host has been initialized before loading shares.`);
      let {
       shared: s,
       useTreesShaking: l
      } = a.getRegisteredShare(this.shareScopeMap, e, i, this.hooks.lifecycle.resolveShare) || {};
      if (s) {
       let t = a.directShare(s, l);
       if (t.lib) return a.addUseIn(t, r.options.name), t.lib;
       if (t.loading && !t.loaded) {
        let e = await t.loading;
        return t.loaded = !0, t.lib || (t.lib = e), a.addUseIn(t, r.options.name), e
       } {
        let o = (async () => {
         let e = await t.get();
         return a.addUseIn(t, r.options.name), t.loaded = !0, t.lib = e, e
        })();
        return this.setShared({
         pkgName: e,
         loaded: !1,
         shared: s,
         from: r.options.name,
         lib: null,
         loading: o,
         treeShaking: l ? t : void 0
        }), o
       }
      } {
       if (null == t ? void 0 : t.customShareInfo) return !1;
       let o = a.shouldUseTreeShaking(i.treeShaking),
        n = a.directShare(i, o),
        s = (async () => {
         let t = await n.get();
         n.lib = t, n.loaded = !0, a.addUseIn(n, r.options.name);
         let {
          shared: o,
          useTreesShaking: s
         } = a.getRegisteredShare(this.shareScopeMap, e, i, this.hooks.lifecycle.resolveShare) || {};
         if (o) {
          let e = a.directShare(o, s);
          e.lib = t, e.loaded = !0, o.from = i.from
         }
         return t
        })();
       return this.setShared({
        pkgName: e,
        loaded: !1,
        shared: i,
        from: r.options.name,
        lib: null,
        loading: s,
        treeShaking: o ? n : void 0
       }), s
      }
     }
     initializeSharing() {
      let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.DEFAULT_SCOPE,
       t = arguments.length > 1 ? arguments[1] : void 0,
       {
        host: r
       } = this,
       o = null == t ? void 0 : t.from,
       i = null == t ? void 0 : t.strategy,
       s = null == t ? void 0 : t.initScope,
       l = [];
      if ("build" !== o) {
       let {
        initTokens: t
       } = this;
       s || (s = []);
       let r = t[e];
       if (r || (r = t[e] = {
         from: this.host.name
        }), s.indexOf(r) >= 0) return l;
       s.push(r)
      }
      let u = this.shareScopeMap,
       c = r.options.name;
      u[e] || (u[e] = {});
      let d = u[e],
       f = (e, t) => {
        var r;
        let {
         version: o,
         eager: n
        } = t;
        d[e] = d[e] || {};
        let i = d[e],
         s = i[o] && a.directShare(i[o]),
         l = !!(s && ("eager" in s && s.eager || "shareConfig" in s && (null == (r = s.shareConfig) ? void 0 : r.eager)));
        (!s || "loaded-first" !== s.strategy && !s.loaded && (!n != !l ? n : c > i[o].from)) && (i[o] = t)
       },
       p = async e => {
        let t, {
         module: o
        } = await r.remoteHandler.getRemoteModuleAndOptions({
         id: e
        });
        try {
         t = await o.getEntry()
        } catch (o) {
         if (!(t = await r.remoteHandler.hooks.lifecycle.errorLoadRemote.emit({
           id: e,
           error: o,
           from: "runtime",
           lifecycle: "beforeLoadShare",
           origin: r
          }))) return
        } finally {
         (null == t ? void 0 : t.init) && !o.initing && (o.remoteEntryExports = t, await o.init(void 0, void 0, s))
        }
       };
      return Object.keys(r.options.shared).forEach(t => {
       r.options.shared[t].forEach(r => {
        r.scope.includes(e) && f(t, r)
       })
      }), ("version-first" === r.options.shareStrategy || "version-first" === i) && r.options.remotes.forEach(t => {
       t.shareScope === e && l.push(p(t.name))
      }), l
     }
     loadShareSync(e, t) {
      let {
       host: r
      } = this, n = a.getTargetSharedOptions({
       pkgName: e,
       extraOptions: t,
       shareInfos: r.options.shared
      });
      (null == n ? void 0 : n.scope) && n.scope.forEach(e => {
       this.initializeSharing(e, {
        strategy: n.strategy
       })
      });
      let {
       shared: s,
       useTreesShaking: l
      } = a.getRegisteredShare(this.shareScopeMap, e, n, this.hooks.lifecycle.resolveShare) || {};
      if (s) {
       if ("function" == typeof s.lib) return a.addUseIn(s, r.options.name), s.loaded || (s.loaded = !0, s.from === r.options.name && (n.loaded = !0)), s.lib;
       if ("function" == typeof s.get) {
        let t = s.get();
        if (!(t instanceof Promise)) return a.addUseIn(s, r.options.name), this.setShared({
         pkgName: e,
         loaded: !0,
         from: r.options.name,
         lib: t,
         shared: s
        }), t
       }
      }
      if (n.lib) return n.loaded || (n.loaded = !0), n.lib;
      if (n.get) {
       let a = n.get();
       return a instanceof Promise && o.error((null == t ? void 0 : t.from) === "build" ? d.RUNTIME_005 : d.RUNTIME_006, d.runtimeDescMap, {
        hostName: r.options.name,
        sharedPkgName: e
       }, void 0, i.optionsToMFContext(r.options)), n.lib = a, this.setShared({
        pkgName: e,
        loaded: !0,
        from: r.options.name,
        lib: n.lib,
        shared: n
       }), n.lib
      }
      o.error(d.RUNTIME_006, d.runtimeDescMap, {
       hostName: r.options.name,
       sharedPkgName: e
      }, void 0, i.optionsToMFContext(r.options))
     }
     initShareScopeMap(e, t) {
      let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
       {
        host: o
       } = this;
      this.shareScopeMap[e] = t, this.hooks.lifecycle.initContainerShareScopeMap.emit({
       shareScope: t,
       options: o.options,
       origin: o,
       scopeName: e,
       hostShareScopeMap: r.hostShareScopeMap
      })
     }
     setShared(e) {
      let {
       pkgName: t,
       shared: r,
       from: o,
       lib: n,
       loading: a,
       loaded: i,
       get: s,
       treeShaking: l
      } = e, {
       version: u,
       scope: c = "default",
       ...d
      } = r, f = Array.isArray(c) ? c : [c], p = e => {
       let t = (e, t, r) => {
         r && !e[t] && (e[t] = r)
        },
        r = l ? e.treeShaking : e;
       t(r, "loaded", i), t(r, "loading", a), t(r, "get", s)
      };
      f.forEach(e => {
       this.shareScopeMap[e] || (this.shareScopeMap[e] = {}), this.shareScopeMap[e][t] || (this.shareScopeMap[e][t] = {}), this.shareScopeMap[e][t][u] || (this.shareScopeMap[e][t][u] = {
        version: u,
        scope: [e],
        ...d,
        lib: n
       });
       let r = this.shareScopeMap[e][t][u];
       p(r), o && r.from !== o && (r.from = o)
      })
     }
     _setGlobalShareScopeMap(e) {
      let t = a.getGlobalShareScope(),
       r = e.id || e.name;
      r && !t[r] && (t[r] = this.shareScopeMap)
     }
     constructor(e) {
      this.hooks = new c.PluginSystem({
       beforeRegisterShare: new l.SyncWaterfallHook("beforeRegisterShare"),
       afterResolve: new u.AsyncWaterfallHook("afterResolve"),
       beforeLoadShare: new u.AsyncWaterfallHook("beforeLoadShare"),
       loadShare: new s.AsyncHook,
       resolveShare: new l.SyncWaterfallHook("resolveShare"),
       initContainerShareScopeMap: new l.SyncWaterfallHook("initContainerShareScopeMap")
      }), this.host = e, this.shareScopeMap = {}, this.initTokens = {}, this._setGlobalShareScopeMap(e.options)
     }
    }
   },
   91914(e, t, r) {
    var o = r(11757).__exportAll({});
    Object.defineProperty(t, "type_exports", {
     enumerable: !0,
     get: function() {
      return o
     }
    })
   },
   24330(e, t) {
    function r(e) {
     return {
      name: e.name,
      alias: e.alias,
      entry: "entry" in e ? e.entry : void 0,
      version: "version" in e ? e.version : void 0,
      type: e.type,
      entryGlobalName: e.entryGlobalName,
      shareScope: e.shareScope
     }
    }
    t.optionsToMFContext = function(e) {
     var t, o, n, a, i, s;
     let l = {};
     for (let [t, r] of Object.entries(e.shared)) {
      let e = r[0];
      e && (l[t] = {
       version: e.version,
       singleton: null == (n = e.shareConfig) ? void 0 : n.singleton,
       requiredVersion: (null == (a = e.shareConfig) ? void 0 : a.requiredVersion) !== !1 && (null == (i = e.shareConfig) ? void 0 : i.requiredVersion),
       eager: e.eager,
       strictVersion: null == (s = e.shareConfig) ? void 0 : s.strictVersion
      })
     }
     return {
      project: {
       name: e.name,
       mfRole: (null == (t = e.remotes) ? void 0 : t.length) > 0 ? "host" : "unknown"
      },
      mfConfig: {
       name: e.name,
       remotes: (null == (o = e.remotes) ? void 0 : o.map(r)) ?? [],
       shared: l
      }
     }
    }
   },
   47542(e, t, r) {
    r(39839), t.getBuilderId = function() {
     return "u" > typeof FEDERATION_BUILD_IDENTIFIER ? FEDERATION_BUILD_IDENTIFIER : ""
    }
   },
   63147(e, t, r) {
    let o = r(65706);
    t.AsyncHook = class extends o.SyncHook {
     emit() {
      let e;
      for (var t = arguments.length, r = Array(t), o = 0; o < t; o++) r[o] = arguments[o];
      let n = Array.from(this.listeners);
      if (n.length > 0) {
       let t = 0,
        o = e => !1 !== e && (t < n.length ? Promise.resolve(n[t++].apply(null, r)).then(o) : e);
       e = o()
      }
      return Promise.resolve(e)
     }
    }
   },
   63616(e, t, r) {
    let o = r(6365),
     n = r(88779),
     a = r(65706),
     i = r(51654);
    t.AsyncWaterfallHook = class extends a.SyncHook {
     emit(e) {
      n.isObject(e) || o.error(`The response data for the "${this.type}" hook must be an object.`);
      let t = Array.from(this.listeners);
      if (t.length > 0) {
       let r = 0,
        n = t => (o.warn(t), this.onerror(t), e),
        a = o => {
         if (i.checkReturnData(e, o)) {
          if (e = o, r < t.length) try {
           return Promise.resolve(t[r++](e)).then(a, n)
          } catch (e) {
           return n(e)
          }
         } else this.onerror(`A plugin returned an incorrect value for the "${this.type}" type.`);
         return e
        };
       return Promise.resolve(a(e))
      }
      return Promise.resolve(e)
     }
     constructor(e) {
      super(), this.onerror = o.error, this.type = e
     }
    }
   },
   69218(e, t, r) {
    r(65706), r(63147), r(51654), r(63616), r(14612)
   },
   14612(e, t, r) {
    let o = r(6365),
     n = r(88779);
    r(31255), t.PluginSystem = class {
     applyPlugin(e, t) {
      o.assert(n.isPlainObject(e), "Plugin configuration is invalid.");
      let r = e.name;
      if (o.assert(r, "A name must be provided by the plugin."), !this.registerPlugins[r]) {
       var a;
       this.registerPlugins[r] = e, null == (a = e.apply) || a.call(e, t), Object.keys(this.lifecycle).forEach(t => {
        let r = e[t];
        r && this.lifecycle[t].on(r)
       })
      }
     }
     removePlugin(e) {
      o.assert(e, "A name is required.");
      let t = this.registerPlugins[e];
      o.assert(t, `The plugin "${e}" is not registered.`), Object.keys(t).forEach(e => {
       "name" !== e && this.lifecycle[e].remove(t[e])
      })
     }
     constructor(e) {
      this.registerPlugins = {}, this.lifecycle = e, this.lifecycleKeys = Object.keys(e)
     }
    }
   },
   65706(e, t) {
    t.SyncHook = class {
     on(e) {
      "function" == typeof e && this.listeners.add(e)
     }
     once(e) {
      let t = this;
      this.on(function r() {
       for (var o = arguments.length, n = Array(o), a = 0; a < o; a++) n[a] = arguments[a];
       return t.remove(r), e.apply(null, n)
      })
     }
     emit() {
      let e;
      for (var t = arguments.length, r = Array(t), o = 0; o < t; o++) r[o] = arguments[o];
      return this.listeners.size > 0 && this.listeners.forEach(t => {
       e = t(...r)
      }), e
     }
     remove(e) {
      this.listeners.delete(e)
     }
     removeAll() {
      this.listeners.clear()
     }
     constructor(e) {
      this.type = "", this.listeners = new Set, e && (this.type = e)
     }
    }
   },
   51654(e, t, r) {
    let o = r(6365),
     n = r(88779),
     a = r(65706);

    function i(e, t) {
     if (!n.isObject(t)) return !1;
     if (e !== t) {
      for (let r in e)
       if (!(r in t)) return !1
     }
     return !0
    }
    t.SyncWaterfallHook = class extends a.SyncHook {
     emit(e) {
      for (let t of (n.isObject(e) || o.error(`The data for the "${this.type}" hook should be an object.`), this.listeners)) try {
       let r = t(e);
       if (i(e, r)) e = r;
       else {
        this.onerror(`A plugin returned an unacceptable value for the "${this.type}" type.`);
        break
       }
      } catch (e) {
       o.warn(e), this.onerror(e)
      }
      return e
     }
     constructor(e) {
      super(), this.onerror = o.error, this.type = e
     }
    }, t.checkReturnData = i
   },
   31255(e, t, r) {
    r(6365), r(88779), r(47542), r(9950), r(48108), r(52213), r(24330), r(39839)
   },
   52213(e, t, r) {
    let o = r(6365),
     n = r(76654),
     a = r(19195),
     i = r(39839),
     s = r(8583),
     l = ".then(callbacks[0]).catch(callbacks[1])";
    async function u(e) {
     let {
      entry: t,
      remoteEntryExports: r
     } = e;
     return new Promise((e, n) => {
      try {
       r ? e(r) : "u" > typeof FEDERATION_ALLOW_NEW_FUNCTION ? Function("callbacks", `import("${t}")${l}`)([e, n]) : import(t).then(e).catch(n)
      } catch (e) {
       o.error(`Failed to load ESM entry from "${t}". ${e instanceof Error?e.message:String(e)}`)
      }
     })
    }
    async function c(e) {
     let {
      entry: t,
      remoteEntryExports: r
     } = e;
     return new Promise((e, n) => {
      try {
       r ? e(r) : Function("callbacks", `System.import("${t}")${l}`)([e, n])
      } catch (e) {
       o.error(`Failed to load SystemJS entry from "${t}". ${e instanceof Error?e.message:String(e)}`)
      }
     })
    }

    function d(e, t, r) {
     let {
      remoteEntryKey: a,
      entryExports: i
     } = n.getRemoteEntryExports(e, t);
     return i || o.error(s.RUNTIME_001, s.runtimeDescMap, {
      remoteName: e,
      remoteEntryUrl: r,
      remoteEntryKey: a
     }), i
    }
    async function f(e) {
     let {
      name: t,
      globalName: r,
      entry: a,
      remoteInfo: l,
      loaderHook: u,
      getEntryUrl: c
     } = e, {
      entryExports: f
     } = n.getRemoteEntryExports(t, r);
     if (f) return f;
     let p = c ? c(a) : a;
     return (0, i.loadScript)(p, {
      attrs: {},
      createScriptHook: (e, t) => {
       let r = u.lifecycle.createScript.emit({
        url: e,
        attrs: t,
        remoteInfo: l
       });
       if (r && (r instanceof HTMLScriptElement || "script" in r || "timeout" in r)) return r
      }
     }).then(() => d(t, r, a), e => {
      let r = e instanceof Error ? e.message : String(e);
      o.error(s.RUNTIME_008, s.runtimeDescMap, {
       remoteName: t,
       resourceUrl: p
      }, r)
     })
    }
    async function p(e) {
     let {
      remoteInfo: t,
      remoteEntryExports: r,
      loaderHook: o,
      getEntryUrl: n
     } = e, {
      entry: a,
      entryGlobalName: i,
      name: s,
      type: l
     } = t;
     switch (l) {
      case "esm":
      case "module":
       return u({
        entry: a,
        remoteEntryExports: r
       });
      case "system":
       return c({
        entry: a,
        remoteEntryExports: r
       });
      default:
       return f({
        entry: a,
        globalName: i,
        name: s,
        remoteInfo: t,
        loaderHook: o,
        getEntryUrl: n
       })
     }
    }
    async function h(e) {
     let {
      remoteInfo: t,
      loaderHook: r
     } = e, {
      entry: a,
      entryGlobalName: s,
      name: l,
      type: u
     } = t, {
      entryExports: c
     } = n.getRemoteEntryExports(l, s);
     return c || (0, i.loadScriptNode)(a, {
      attrs: {
       name: l,
       globalName: s,
       type: u
      },
      loaderHook: {
       createScriptHook: function(e) {
        let o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
         n = r.lifecycle.createScript.emit({
          url: e,
          attrs: o,
          remoteInfo: t
         });
        if (n && "url" in n) return n
       }
      }
     }).then(() => d(l, s, a)).catch(e => {
      o.error(`Failed to load Node.js entry for remote "${l}" from "${a}". ${e instanceof Error?e.message:String(e)}`)
     })
    }

    function m(e) {
     let {
      entry: t,
      name: r
     } = e;
     return (0, i.composeKeyWithSeparator)(r, t)
    }
    async function g(e) {
     let {
      origin: t,
      remoteEntryExports: r,
      remoteInfo: o,
      getEntryUrl: a,
      _inErrorHandling: l = !1
     } = e, u = m(o);
     if (r) return r;
     if (!n.globalLoading[u]) {
      let e = t.remoteHandler.hooks.lifecycle.loadEntry,
       c = t.loaderHook;
      n.globalLoading[u] = e.emit({
       loaderHook: c,
       remoteInfo: o,
       remoteEntryExports: r
      }).then(e => e || (("u" > typeof ENV_TARGET ? "web" === ENV_TARGET : i.isBrowserEnvValue) ? p({
       remoteInfo: o,
       remoteEntryExports: r,
       loaderHook: c,
       getEntryUrl: a
      }) : h({
       remoteInfo: o,
       loaderHook: c
      }))).catch(async e => {
       let a = m(o),
        i = e instanceof Error && e.message.includes("ScriptExecutionError");
       if (e instanceof Error && e.message.includes(s.RUNTIME_008) && !i && !l) {
        let e = e => g({
          ...e,
          _inErrorHandling: !0
         }),
         i = await t.loaderHook.lifecycle.loadEntryError.emit({
          getRemoteEntry: e,
          origin: t,
          remoteInfo: o,
          remoteEntryExports: r,
          globalLoading: n.globalLoading,
          uniqueKey: a
         });
        if (i) return i
       }
       throw e
      })
     }
     return n.globalLoading[u]
    }

    function y(e) {
     return {
      ...e,
      entry: "entry" in e ? e.entry : "",
      type: e.type || a.DEFAULT_REMOTE_TYPE,
      entryGlobalName: e.entryGlobalName || e.name,
      shareScope: e.shareScope || a.DEFAULT_SCOPE
     }
    }
    t.getRemoteEntry = g, t.getRemoteEntryUniqueKey = m, t.getRemoteInfo = y
   },
   6365(e, t, r) {
    let o = r(39839),
     n = r(80711),
     a = "[ Federation Runtime ]",
     i = (0, o.createLogger)(a);

    function s(e, t, r, o, i) {
     if (void 0 !== t) return (0, n.logAndReport)(e, t, r ?? {}, e => {
      throw Error(`${a}: ${e}`)
     }, o, i);
     let s = e;
     if (s instanceof Error) throw s.message.startsWith(a) || (s.message = `${a}: ${s.message}`), s;
     throw Error(`${a}: ${s}`)
    }

    function l(e) {
     e instanceof Error && (e.message.startsWith(a) || (e.message = `${a}: ${e.message}`)), i.warn(e)
    }
    t.assert = function(e, t, r, o, n) {
     e || (void 0 !== r ? s(t, r, o, void 0, n) : s(t))
    }, t.error = s, t.logger = i, t.warn = l
   },
   9950(e, t) {
    function r(e, t) {
     for (let r of e) {
      let e = t.startsWith(r.name),
       o = t.replace(r.name, "");
      if (e) {
       if (o.startsWith("/")) return {
        pkgNameOrAlias: r.name,
        expose: o = `.${o}`,
        remote: r
       };
       else if ("" === o) return {
        pkgNameOrAlias: r.name,
        expose: ".",
        remote: r
       }
      }
      let n = r.alias && t.startsWith(r.alias),
       a = r.alias && t.replace(r.alias, "");
      if (r.alias && n) {
       if (a && a.startsWith("/")) return {
        pkgNameOrAlias: r.alias,
        expose: a = `.${a}`,
        remote: r
       };
       else if ("" === a) return {
        pkgNameOrAlias: r.alias,
        expose: ".",
        remote: r
       }
      }
     }
    }
    t.matchRemote = function(e, t) {
     for (let r of e)
      if (t === r.name || r.alias && t === r.alias) return r
    }, t.matchRemoteWithNameAndExpose = r
   },
   48108(e, t, r) {
    let o = r(76654);
    t.registerPlugins = function(e, t) {
     let r = o.getGlobalHostPlugins(),
      n = [t.hooks, t.remoteHandler.hooks, t.sharedHandler.hooks, t.snapshotHandler.hooks, t.loaderHook, t.bridgeHook];
     return r.length > 0 && r.forEach(t => {
      (null == e ? void 0 : e.find(e => e.name !== t.name)) && e.push(t)
     }), e && e.length > 0 && e.forEach(e => {
      n.forEach(r => {
       r.applyPlugin(e, t)
      })
     }), e
    }
   },
   94988(e, t, r) {
    let o = r(6365),
     n = r(9950),
     a = r(52213),
     i = r(39839);

    function s(e) {
     return {
      resourceCategory: "sync",
      share: !0,
      depsRemote: !0,
      prefetchInterface: !1,
      ...e
     }
    }

    function l(e, t) {
     return t.map(t => {
      let r = n.matchRemote(e, t.nameOrAlias);
      return o.assert(r, `Unable to preload ${t.nameOrAlias} as it is not included in ${!r&&(0,i.safeToString)({remoteInfo:r,remotes:e})}`), {
       remote: r,
       preloadConfig: s(t)
      }
     })
    }

    function u(e) {
     return e ? e.map(e => "." === e ? e : e.startsWith("./") ? e.replace("./", "") : e) : []
    }

    function c(e, t, r) {
     let o = !(arguments.length > 3) || void 0 === arguments[3] || arguments[3],
      {
       cssAssets: n,
       jsAssetsWithoutEntry: s,
       entryAssets: l
      } = r;
     if (t.options.inBrowser) {
      if (l.forEach(r => {
        let {
         moduleInfo: o
        } = r, n = t.moduleCache.get(e.name);
        n ? a.getRemoteEntry({
         origin: t,
         remoteInfo: o,
         remoteEntryExports: n.remoteEntryExports
        }) : a.getRemoteEntry({
         origin: t,
         remoteInfo: o,
         remoteEntryExports: void 0
        })
       }), o) {
       let r = {
        rel: "preload",
        as: "style"
       };
       n.forEach(o => {
        let {
         link: n,
         needAttach: a
        } = (0, i.createLink)({
         url: o,
         cb: () => {},
         attrs: r,
         createLinkHook: (r, o) => {
          let n = t.loaderHook.lifecycle.createLink.emit({
           url: r,
           attrs: o,
           remoteInfo: e
          });
          if (n instanceof HTMLLinkElement) return n
         }
        });
        a && document.head.appendChild(n)
       })
      } else {
       let r = {
        rel: "stylesheet",
        type: "text/css"
       };
       n.forEach(o => {
        let {
         link: n,
         needAttach: a
        } = (0, i.createLink)({
         url: o,
         cb: () => {},
         attrs: r,
         createLinkHook: (r, o) => {
          let n = t.loaderHook.lifecycle.createLink.emit({
           url: r,
           attrs: o,
           remoteInfo: e
          });
          if (n instanceof HTMLLinkElement) return n
         },
         needDeleteLink: !1
        });
        a && document.head.appendChild(n)
       })
      }
      if (o) {
       let r = {
        rel: "preload",
        as: "script"
       };
       s.forEach(o => {
        let {
         link: n,
         needAttach: a
        } = (0, i.createLink)({
         url: o,
         cb: () => {},
         attrs: r,
         createLinkHook: (r, o) => {
          let n = t.loaderHook.lifecycle.createLink.emit({
           url: r,
           attrs: o,
           remoteInfo: e
          });
          if (n instanceof HTMLLinkElement) return n
         }
        });
        a && document.head.appendChild(n)
       })
      } else {
       let r = {
        fetchpriority: "high",
        type: (null == e ? void 0 : e.type) === "module" ? "module" : "text/javascript"
       };
       s.forEach(o => {
        let {
         script: n,
         needAttach: a
        } = (0, i.createScript)({
         url: o,
         cb: () => {},
         attrs: r,
         createScriptHook: (r, o) => {
          let n = t.loaderHook.lifecycle.createScript.emit({
           url: r,
           attrs: o,
           remoteInfo: e
          });
          if (n instanceof HTMLScriptElement) return n
         },
         needDeleteScript: !0
        });
        a && document.head.appendChild(n)
       })
      }
     }
    }
    t.defaultPreloadArgs = s, t.formatPreloadArgs = l, t.normalizePreloadExposes = u, t.preloadAssets = c
   },
   39425(e, t) {
    function r(e, t) {
     return (e = Number(e) || e) > (t = Number(t) || t) ? 1 : e === t ? 0 : -1
    }

    function o(e, t) {
     let {
      preRelease: o
     } = e, {
      preRelease: n
     } = t;
     if (void 0 === o && n) return 1;
     if (o && void 0 === n) return -1;
     if (void 0 === o && void 0 === n) return 0;
     for (let e = 0, t = o.length; e <= t; e++) {
      let t = o[e],
       a = n[e];
      if (t !== a) {
       if (void 0 === t && void 0 === a) return 0;
       if (!t) return 1;
       if (!a) return -1;
       return r(t, a)
      }
     }
     return 0
    }

    function n(e, t) {
     return r(e.major, t.major) || r(e.minor, t.minor) || r(e.patch, t.patch) || o(e, t)
    }

    function a(e, t) {
     return e.version === t.version
    }
    t.compare = function(e, t) {
     switch (e.operator) {
      case "":
      case "=":
       return a(e, t);
      case ">":
       return 0 > n(e, t);
      case ">=":
       return a(e, t) || 0 > n(e, t);
      case "<":
       return n(e, t) > 0;
      case "<=":
       return a(e, t) || n(e, t) > 0;
      case void 0:
       return !0;
      default:
       return !1
     }
    }
   },
   96379(e, t) {
    let r = "[0-9A-Za-z-]+",
     o = `(?:\\+(${r}(?:\\.${r})*))`,
     n = "0|[1-9]\\d*",
     a = "[0-9]+",
     i = "\\d*[a-zA-Z-][a-zA-Z0-9-]*",
     s = `(?:${a}|${i})`,
     l = `(?:-?(${s}(?:\\.${s})*))`,
     u = `(?:${n}|${i})`,
     c = `(?:-(${u}(?:\\.${u})*))`,
     d = `${n}|x|X|\\*`,
     f = `[v=\\s]*(${d})(?:\\.(${d})(?:\\.(${d})(?:${c})?${o}?)?)?`,
     p = `^\\s*(${f})\\s+-\\s+(${f})\\s*$`,
     h = `[v=\\s]*${`(${a})\\.(${a})\\.(${a})`}${l}?${o}?`,
     m = "((?:<|>)?=?)",
     g = `(\\s*)${m}\\s*(${h}|${f})`,
     y = "(?:~>?)",
     E = `(\\s*)${y}\\s+`,
     S = "(?:\\^)",
     b = `(\\s*)${S}\\s+`,
     _ = "(<|>)?=?\\s*\\*",
     v = `^${S}${f}$`,
     I = `v?${`(${n})\\.(${n})\\.(${n})`}${c}?${o}?`,
     R = `^${y}${f}$`,
     T = `^${m}\\s*${f}$`,
     M = `^${m}\\s*(${I})$|^$`,
     N = "^\\s*>=\\s*0.0.0\\s*$";
    t.caret = v, t.caretTrim = b, t.comparator = M, t.comparatorTrim = g, t.gte0 = N, t.hyphenRange = p, t.star = _, t.tilde = R, t.tildeTrim = E, t.xRange = T
   },
   9272(e, t, r) {
    let o = r(90435),
     n = r(27601),
     a = r(39425);

    function i(e) {
     return o.pipe(n.parseCarets, n.parseTildes, n.parseXRanges, n.parseStar)(e)
    }

    function s(e) {
     return o.pipe(n.parseHyphen, n.parseComparatorTrim, n.parseTildeTrim, n.parseCaretTrim)(e.trim()).split(/\s+/).join(" ")
    }
    t.satisfy = function(e, t) {
     if (!e) return !1;
     let r = o.extractComparator(e);
     if (!r) return !1;
     let [, l, , u, c, d, f] = r, p = {
      operator: l,
      version: o.combineVersion(u, c, d, f),
      major: u,
      minor: c,
      patch: d,
      preRelease: null == f ? void 0 : f.split(".")
     };
     for (let e of t.split("||")) {
      let t = e.trim();
      if (!t || "*" === t || "x" === t) return !0;
      try {
       let e = s(t);
       if (!e.trim()) return !0;
       let r = e.split(" ").map(e => i(e)).join(" ");
       if (!r.trim()) return !0;
       let l = r.split(/\s+/).map(e => n.parseGTE0(e)).filter(Boolean);
       if (0 === l.length) continue;
       let u = !0;
       for (let e of l) {
        let t = o.extractComparator(e);
        if (!t) {
         u = !1;
         break
        }
        let [, r, , n, i, s, l] = t;
        if (!a.compare({
          operator: r,
          version: o.combineVersion(n, i, s, l),
          major: n,
          minor: i,
          patch: s,
          preRelease: null == l ? void 0 : l.split(".")
         }, p)) {
         u = !1;
         break
        }
       }
       if (u) return !0
      } catch (e) {
       console.error(`[semver] Error processing range part "${t}":`, e);
       continue
      }
     }
     return !1
    }
   },
   27601(e, t, r) {
    let o = r(96379),
     n = r(90435);

    function a(e) {
     return e.replace(n.parseRegex(o.hyphenRange), (e, t, r, o, a, i, s, l, u, c, d, f) => (t = n.isXVersion(r) ? "" : n.isXVersion(o) ? `>=${r}.0.0` : n.isXVersion(a) ? `>=${r}.${o}.0` : `>=${t}`, l = n.isXVersion(u) ? "" : n.isXVersion(c) ? `<${Number(u)+1}.0.0-0` : n.isXVersion(d) ? `<${u}.${Number(c)+1}.0-0` : f ? `<=${u}.${c}.${d}-${f}` : `<=${l}`, `${t} ${l}`.trim()))
    }

    function i(e) {
     return e.replace(n.parseRegex(o.comparatorTrim), "$1$2$3")
    }

    function s(e) {
     return e.replace(n.parseRegex(o.tildeTrim), "$1~")
    }

    function l(e) {
     return e.trim().split(/\s+/).map(e => e.replace(n.parseRegex(o.caret), (e, t, r, o, a) => {
      if (n.isXVersion(t)) return "";
      if (n.isXVersion(r)) return `>=${t}.0.0 <${Number(t)+1}.0.0-0`;
      if (n.isXVersion(o))
       if ("0" === t) return `>=${t}.${r}.0 <${t}.${Number(r)+1}.0-0`;
       else return `>=${t}.${r}.0 <${Number(t)+1}.0.0-0`;
      if (a)
       if ("0" !== t) return `>=${t}.${r}.${o}-${a} <${Number(t)+1}.0.0-0`;
       else if ("0" === r) return `>=${t}.${r}.${o}-${a} <${t}.${r}.${Number(o)+1}-0`;
      else return `>=${t}.${r}.${o}-${a} <${t}.${Number(r)+1}.0-0`;
      if ("0" === t)
       if ("0" === r) return `>=${t}.${r}.${o} <${t}.${r}.${Number(o)+1}-0`;
       else return `>=${t}.${r}.${o} <${t}.${Number(r)+1}.0-0`;
      return `>=${t}.${r}.${o} <${Number(t)+1}.0.0-0`
     })).join(" ")
    }

    function u(e) {
     return e.trim().split(/\s+/).map(e => e.replace(n.parseRegex(o.tilde), (e, t, r, o, a) => n.isXVersion(t) ? "" : n.isXVersion(r) ? `>=${t}.0.0 <${Number(t)+1}.0.0-0` : n.isXVersion(o) ? `>=${t}.${r}.0 <${t}.${Number(r)+1}.0-0` : a ? `>=${t}.${r}.${o}-${a} <${t}.${Number(r)+1}.0-0` : `>=${t}.${r}.${o} <${t}.${Number(r)+1}.0-0`)).join(" ")
    }

    function c(e) {
     return e.split(/\s+/).map(e => e.trim().replace(n.parseRegex(o.xRange), (e, t, r, o, a, i) => {
      let s = n.isXVersion(r),
       l = s || n.isXVersion(o),
       u = l || n.isXVersion(a);
      if ("=" === t && u && (t = ""), i = "", s)
       if (">" === t || "<" === t) return "<0.0.0-0";
       else return "*";
      return t && u ? (l && (o = 0), a = 0, ">" === t ? (t = ">=", l ? (r = Number(r) + 1, o = 0) : o = Number(o) + 1, a = 0) : "<=" === t && (t = "<", l ? r = Number(r) + 1 : o = Number(o) + 1), "<" === t && (i = "-0"), `${t+r}.${o}.${a}${i}`) : l ? `>=${r}.0.0${i} <${Number(r)+1}.0.0-0` : u ? `>=${r}.${o}.0${i} <${r}.${Number(o)+1}.0-0` : e
     })).join(" ")
    }

    function d(e) {
     return e.trim().replace(n.parseRegex(o.star), "")
    }

    function f(e) {
     return e.trim().replace(n.parseRegex(o.gte0), "")
    }
    t.parseCaretTrim = function(e) {
     return e.replace(n.parseRegex(o.caretTrim), "$1^")
    }, t.parseCarets = l, t.parseComparatorTrim = i, t.parseGTE0 = f, t.parseHyphen = a, t.parseStar = d, t.parseTildeTrim = s, t.parseTildes = u, t.parseXRanges = c
   },
   90435(e, t, r) {
    let o = r(96379);

    function n(e) {
     return new RegExp(e)
    }

    function a(e) {
     return !e || "x" === e.toLowerCase() || "*" === e
    }

    function i() {
     for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
     return e => t.reduce((e, t) => t(e), e)
    }

    function s(e) {
     return e.match(n(o.comparator))
    }
    t.combineVersion = function(e, t, r, o) {
     let n = `${e}.${t}.${r}`;
     return o ? `${n}-${o}` : n
    }, t.extractComparator = s, t.isXVersion = a, t.parseRegex = n, t.pipe = i
   },
   66266(e, t, r) {
    let o = r(6365),
     n = r(88779),
     a = r(76654),
     i = r(19195),
     s = r(9272),
     l = r(39839);

    function u(e, t, r, n) {
     var a, i;
     let s;
     return s = "get" in e ? e.get : "lib" in e ? () => Promise.resolve(e.lib) : () => Promise.resolve(() => {
      o.error(`Cannot get shared "${r}" from "${t}": neither "get" nor "lib" is provided in the share config.`)
     }), (null == (a = e.shareConfig) ? void 0 : a.eager) && (null == (i = e.treeShaking) ? void 0 : i.mode) && o.error(`Invalid shared config for "${r}" from "${t}": cannot use both "eager: true" and "treeShaking.mode" simultaneously. Choose one strategy.`), {
      deps: [],
      useIn: [],
      from: t,
      loading: null,
      ...e,
      shareConfig: {
       requiredVersion: `^${e.version}`,
       singleton: !1,
       eager: !1,
       strictVersion: !1,
       ...e.shareConfig
      },
      get: s,
      loaded: null != e && !!e.loaded || "lib" in e || void 0,
      version: e.version ?? "0",
      scope: Array.isArray(e.scope) ? e.scope : [e.scope ?? "default"],
      strategy: (e.strategy ?? n) || "version-first",
      treeShaking: e.treeShaking ? {
       ...e.treeShaking,
       mode: e.treeShaking.mode ?? "server-calc",
       status: e.treeShaking.status ?? l.TreeShakingStatus.UNKNOWN,
       useIn: []
      } : void 0
     }
    }

    function c(e, t) {
     let r = t.shared || {},
      o = t.name,
      a = Object.keys(r).reduce((e, a) => {
       let i = n.arrayOptions(r[a]);
       return e[a] = e[a] || [], i.forEach(r => {
        e[a].push(u(r, o, a, t.shareStrategy))
       }), e
      }, {}),
      i = {
       ...e.shared
      };
     return Object.keys(a).forEach(e => {
      i[e] ? a[e].forEach(t => {
       i[e].find(e => e.version === t.version) || i[e].push(t)
      }) : i[e] = a[e]
     }), {
      allShareInfos: i,
      newShareInfos: a
     }
    }

    function d(e, t) {
     if (!e) return !1;
     let {
      status: r,
      mode: o
     } = e;
     return r !== l.TreeShakingStatus.NO_USE && (r === l.TreeShakingStatus.CALCULATED || "runtime-infer" === o && (!t || g(e, t)))
    }

    function f(e, t) {
     let r = e => {
      if (!Number.isNaN(Number(e))) {
       let t = e.split("."),
        r = e;
       for (let e = 0; e < 3 - t.length; e++) r += ".0";
       return r
      }
      return e
     };
     return !!s.satisfy(r(e), `<=${r(t)}`)
    }
    let p = (e, t) => {
      let r = t || function(e, t) {
       return f(e, t)
      };
      return Object.keys(e).reduce((e, t) => !e || r(e, t) || "0" === e ? t : e, 0)
     },
     h = e => !!e.loaded || "function" == typeof e.lib,
     m = e => !!e.loading,
     g = (e, t) => {
      if (!e || !t) return !1;
      let {
       usedExports: r
      } = e;
      return !!r && !!t.every(e => r.includes(e))
     };

    function y(e, t, r, o) {
     let n = e[t][r],
      a = "",
      i = d(o),
      s = function(e, t) {
       return i ? !n[e].treeShaking || !!n[t].treeShaking && !h(n[e].treeShaking) && f(e, t) : !h(n[e]) && f(e, t)
      };
     if (i) {
      if (a = p(e[t][r], s)) return {
       version: a,
       useTreesShaking: i
      };
      i = !1
     }
     return {
      version: p(e[t][r], s),
      useTreesShaking: i
     }
    }
    let E = e => h(e) || m(e);

    function S(e, t, r, o) {
     let n = e[t][r],
      a = "",
      i = d(o),
      s = function(e, t) {
       if (i) {
        if (!n[e].treeShaking) return !0;
        if (!n[t].treeShaking) return !1;
        if (E(n[t].treeShaking))
         if (E(n[e].treeShaking)) return !!f(e, t);
         else return !0;
        if (E(n[e].treeShaking)) return !1
       }
       if (E(n[t]))
        if (E(n[e])) return !!f(e, t);
        else return !0;
       return !E(n[e]) && f(e, t)
      };
     if (i) {
      if (a = p(e[t][r], s)) return {
       version: a,
       useTreesShaking: i
      };
      i = !1
     }
     return {
      version: p(e[t][r], s),
      useTreesShaking: i
     }
    }

    function b(e) {
     return "loaded-first" === e ? S : y
    }

    function _(e, t, r, n) {
     if (!e) return;
     let {
      shareConfig: l,
      scope: u = i.DEFAULT_SCOPE,
      strategy: c,
      treeShaking: f
     } = r;
     for (let i of Array.isArray(u) ? u : [u])
      if (l && e[i] && e[i][t]) {
       let {
        requiredVersion: u
       } = l, {
        version: p,
        useTreesShaking: h
       } = b(c)(e, i, t, f), m = () => {
        let n = e[i][t][p];
        if (l.singleton) {
         if ("string" == typeof u && !s.satisfy(p, u)) {
          let e = `Version ${p} from ${p&&n.from} of shared singleton module ${t} does not satisfy the requirement of ${r.from} which needs ${u})`;
          l.strictVersion ? o.error(e) : o.warn(e)
         }
         return {
          shared: n,
          useTreesShaking: h
         }
        } {
         if (!1 === u || "*" === u || s.satisfy(p, u)) return {
          shared: n,
          useTreesShaking: h
         };
         let r = d(f);
         if (r) {
          for (let [o, n] of Object.entries(e[i][t]))
           if (d(n.treeShaking, null == f ? void 0 : f.usedExports) && s.satisfy(o, u)) return {
            shared: n,
            useTreesShaking: r
           }
         }
         for (let [r, o] of Object.entries(e[i][t]))
          if (s.satisfy(r, u)) return {
           shared: o,
           useTreesShaking: !1
          }
        }
       }, g = {
        shareScopeMap: e,
        scope: i,
        pkgName: t,
        version: p,
        GlobalFederation: a.Global.__FEDERATION__,
        shareInfo: r,
        resolver: m
       };
       return (n.emit(g) || g).resolver()
      }
    }

    function v() {
     return a.Global.__FEDERATION__.__SHARE__
    }

    function I(e) {
     let {
      pkgName: t,
      extraOptions: r,
      shareInfos: o
     } = e, n = e => {
      if (!e) return;
      let t = {};
      e.forEach(e => {
       t[e.version] = e
      });
      let r = function(e, r) {
       return !h(t[e]) && f(e, r)
      };
      return t[p(t, r)]
     }, a = (null == r ? void 0 : r.resolver) ?? n, i = e => null !== e && "object" == typeof e && !Array.isArray(e), s = function() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      let o = {};
      for (let e of t)
       if (e)
        for (let [t, r] of Object.entries(e)) {
         let e = o[t];
         i(e) && i(r) ? o[t] = s(e, r) : void 0 !== r && (o[t] = r)
        }
      return o
     };
     return s(a(o[t]), null == r ? void 0 : r.customShareInfo)
    }

    function R(e, t) {
     return t && e.treeShaking ? e.treeShaking : e
    }
    t.addUseIn = (e, t) => {
     e.useIn || (e.useIn = []), n.addUniqueItem(e.useIn, t)
    }, t.directShare = R, t.formatShareConfigs = c, t.getGlobalShareScope = v, t.getRegisteredShare = _, t.getTargetSharedOptions = I, t.shouldUseTreeShaking = d
   },
   88779(e, t, r) {
    let o = r(6365),
     n = r(39839);

    function a(e, t) {
     return -1 === e.findIndex(e => e === t) && e.push(t), e
    }

    function i(e) {
     return "version" in e && e.version ? `${e.name}:${e.version}` : "entry" in e && e.entry ? `${e.name}:${e.entry}` : `${e.name}`
    }

    function s(e) {
     return void 0 !== e.entry
    }

    function l(e) {
     return !e.entry.includes(".json")
    }
    async function u(e, t) {
     try {
      return await e()
     } catch (e) {
      t || o.warn(e);
      return
     }
    }

    function c(e) {
     return e && "object" == typeof e
    }
    let d = Object.prototype.toString;

    function f(e) {
     return "[object Object]" === d.call(e)
    }

    function p(e, t) {
     let r = /^(https?:)?\/\//i;
     return e.replace(r, "").replace(/\/$/, "") === t.replace(r, "").replace(/\/$/, "")
    }

    function h(e) {
     return Array.isArray(e) ? e : [e]
    }

    function m(e) {
     let t = {
      url: "",
      type: "global",
      globalName: ""
     };
     return n.isBrowserEnvValue || (0, n.isReactNativeEnv)() || !("ssrRemoteEntry" in e) ? "remoteEntry" in e ? {
      url: e.remoteEntry,
      type: e.remoteEntryType,
      globalName: e.globalName
     } : t : "ssrRemoteEntry" in e ? {
      url: e.ssrRemoteEntry || t.url,
      type: e.ssrRemoteEntryType || t.type,
      globalName: e.globalName
     } : t
    }
    let g = (e, t) => {
     let r;
     return r = e.endsWith("/") ? e.slice(0, -1) : e, t.startsWith(".") && (t = t.slice(1)), r += t
    };
    t.addUniqueItem = a, t.arrayOptions = h, t.getFMId = i, t.getRemoteEntryInfoFromSnapshot = m, t.isObject = c, t.isPlainObject = f, t.isPureRemoteEntry = l, t.isRemoteInfoWithEntry = s, t.isStaticResourcesEqual = p, t.objectToString = d, t.processModuleAlias = g, t.safeWrapper = u
   },
   10355(e, t) {
    var r = Object.create,
     o = Object.defineProperty,
     n = Object.getOwnPropertyDescriptor,
     a = Object.getOwnPropertyNames,
     i = Object.getPrototypeOf,
     s = Object.prototype.hasOwnProperty,
     l = (e, t, r, i) => {
      if (t && "object" == typeof t || "function" == typeof t)
       for (var l, u = a(t), c = 0, d = u.length; c < d; c++) l = u[c], s.call(e, l) || l === r || o(e, l, {
        get: (e => t[e]).bind(null, l),
        enumerable: !(i = n(t, l)) || i.enumerable
       });
      return e
     };
    t.__toESM = (e, t, n) => (n = null != e ? r(i(e)) : {}, l(!t && e && e.__esModule ? n : o(n, "default", {
     value: e,
     enumerable: !0
    }), e))
   },
   69848(e, t, r) {
    Object.defineProperties(t, {
     __esModule: {
      value: !0
     },
     [Symbol.toStringTag]: {
      value: "Module"
     }
    }), r(10355);
    let o = r(4568),
     n = r(34085),
     a = {
      ...n.helpers.global,
      getGlobalFederationInstance: o.getGlobalFederationInstance
     },
     i = n.helpers.share,
     s = n.helpers.utils;
    t.default = {
     global: a,
     share: i,
     utils: s
    }, t.global = a, t.share = i, t.utils = s
   },
   60911(e, t, r) {
    Object.defineProperty(t, Symbol.toStringTag, {
     value: "Module"
    }), r(10355);
    let o = r(4568),
     n = r(34085),
     a = r(8583);

    function i(e) {
     let t = new((0, n.getGlobalFederationConstructor)() || n.ModuleFederation)(e);
     return (0, n.setGlobalFederationInstance)(t), t
    }
    let s = null;

    function l(e) {
     let t = o.getGlobalFederationInstance(e.name, e.version);
     return t ? (t.initOptions(e), s || (s = t), t) : s = i(e)
    }

    function u() {
     for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
     return (0, n.assert)(s, a.RUNTIME_009, a.runtimeDescMap), s.loadRemote.apply(s, t)
    }

    function c() {
     for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
     return (0, n.assert)(s, a.RUNTIME_009, a.runtimeDescMap), s.loadShare.apply(s, t)
    }

    function d() {
     for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
     return (0, n.assert)(s, a.RUNTIME_009, a.runtimeDescMap), s.loadShareSync.apply(s, t)
    }

    function f() {
     for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
     return (0, n.assert)(s, a.RUNTIME_009, a.runtimeDescMap), s.preloadRemote.apply(s, t)
    }

    function p() {
     for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
     return (0, n.assert)(s, a.RUNTIME_009, a.runtimeDescMap), s.registerRemotes.apply(s, t)
    }

    function h() {
     for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
     return (0, n.assert)(s, a.RUNTIME_009, a.runtimeDescMap), s.registerPlugins.apply(s, t)
    }

    function m() {
     return s
    }

    function g() {
     for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
     return (0, n.assert)(s, a.RUNTIME_009, a.runtimeDescMap), s.registerShared.apply(s, t)
    }(0, n.setGlobalFederationConstructor)(n.ModuleFederation), Object.defineProperty(t, "Module", {
     enumerable: !0,
     get: function() {
      return n.Module
     }
    }), t.ModuleFederation = n.ModuleFederation, t.createInstance = i, t.getInstance = m, Object.defineProperty(t, "getRemoteEntry", {
     enumerable: !0,
     get: function() {
      return n.getRemoteEntry
     }
    }), Object.defineProperty(t, "getRemoteInfo", {
     enumerable: !0,
     get: function() {
      return n.getRemoteInfo
     }
    }), t.init = l, t.loadRemote = u, Object.defineProperty(t, "loadScript", {
     enumerable: !0,
     get: function() {
      return n.loadScript
     }
    }), Object.defineProperty(t, "loadScriptNode", {
     enumerable: !0,
     get: function() {
      return n.loadScriptNode
     }
    }), t.loadShare = c, t.loadShareSync = d, t.preloadRemote = f, Object.defineProperty(t, "registerGlobalPlugins", {
     enumerable: !0,
     get: function() {
      return n.registerGlobalPlugins
     }
    }), t.registerPlugins = h, t.registerRemotes = p, t.registerShared = g
   },
   4568(e, t, r) {
    r(10355);
    let o = r(34085);

    function n() {
     return "u" > typeof FEDERATION_BUILD_IDENTIFIER ? FEDERATION_BUILD_IDENTIFIER : ""
    }
    t.getGlobalFederationInstance = function(e, t) {
     let r = n();
     return o.CurrentGlobal.__FEDERATION__.__INSTANCES__.find(o => !!r && o.options.id === r || o.options.name === e && !o.options.version && !t || o.options.name === e && !!t && o.options.version === t)
    }
   },
   47587(e, t) {
    var r = Object.defineProperty;
    t.__exportAll = (e, t) => {
     let o = {};
     for (var n in e) r(o, n, {
      get: e[n],
      enumerable: !0
     });
     return t || r(o, Symbol.toStringTag, {
      value: "Module"
     }), o
    }
   },
   88977(e, t) {
    var r;
    let o = "federation-manifest.json",
     n = ".json",
     a = "FEDERATION_DEBUG",
     i = {
      AT: "@",
      HYPHEN: "-",
      SLASH: "/"
     },
     s = {
      [i.AT]: "scope_",
      [i.HYPHEN]: "_",
      [i.SLASH]: "__"
     },
     l = {
      [s[i.AT]]: i.AT,
      [s[i.HYPHEN]]: i.HYPHEN,
      [s[i.SLASH]]: i.SLASH
     },
     u = ":",
     c = "mf-manifest.json",
     d = "mf-stats.json",
     f = {
      NPM: "npm",
      APP: "app"
     },
     p = "__MF_DEVTOOLS_MODULE_INFO__",
     h = "ENCODE_NAME_PREFIX",
     m = ".federation",
     g = {
      identifier: "MFDataPrefetch",
      globalKey: "__PREFETCH__",
      library: "mf-data-prefetch",
      exportsKey: "__PREFETCH_EXPORTS__",
      fileName: "bootstrap.js"
     },
     y = ((r = {})[r.UNKNOWN = 1] = "UNKNOWN", r[r.CALCULATED = 2] = "CALCULATED", r[r.NO_USE = 0] = "NO_USE", r);
    t.BROWSER_LOG_KEY = a, t.ENCODE_NAME_PREFIX = h, t.EncodedNameTransformMap = l, t.FederationModuleManifest = o, t.MANIFEST_EXT = n, t.MFModuleType = f, t.MFPrefetchCommon = g, t.MODULE_DEVTOOL_IDENTIFIER = p, t.ManifestFileName = c, t.NameTransformMap = s, t.NameTransformSymbol = i, t.SEPARATOR = u, t.StatsFileName = d, t.TEMP_DIR = m, t.TreeShakingStatus = y
   },
   40396(e, t) {
    t.createModuleFederationConfig = e => e
   },
   53919(e, t, r) {
    let o = r(57256);
    async function n(e, t) {
     try {
      return await e()
     } catch (e) {
      t || o.warn(e);
      return
     }
    }

    function a(e, t) {
     let r = /^(https?:)?\/\//i;
     return e.replace(r, "").replace(/\/$/, "") === t.replace(r, "").replace(/\/$/, "")
    }

    function i(e) {
     let t, r = null,
      o = !0,
      i = 2e4,
      s = document.getElementsByTagName("script");
     for (let t = 0; t < s.length; t++) {
      let n = s[t],
       i = n.getAttribute("src");
      if (i && a(i, e.url)) {
       r = n, o = !1;
       break
      }
     }
     if (!r) {
      let t, o = e.attrs;
      (r = document.createElement("script")).type = (null == o ? void 0 : o.type) === "module" ? "module" : "text/javascript", e.createScriptHook && ((t = e.createScriptHook(e.url, e.attrs)) instanceof HTMLScriptElement ? r = t : "object" == typeof t && ("script" in t && t.script && (r = t.script), "timeout" in t && t.timeout && (i = t.timeout))), r.src || (r.src = e.url), o && !t && Object.keys(o).forEach(e => {
       r && ("async" === e || "defer" === e ? r[e] = o[e] : r.getAttribute(e) || r.setAttribute(e, o[e]))
      })
     }
     let l = null,
      u = "u" > typeof window ? t => {
       if (t.filename && a(t.filename, e.url)) {
        let r = Error(`ScriptExecutionError: Script "${e.url}" loaded but threw a runtime error during execution: ${t.message} (${t.filename}:${t.lineno}:${t.colno})`);
        r.name = "ScriptExecutionError", l = r
       }
      } : null;
     u && window.addEventListener("error", u);
     let c = async (o, a) => {
      clearTimeout(t), u && window.removeEventListener("error", u);
      let i = () => {
       if ((null == a ? void 0 : a.type) === "error") {
        let t = Error((null == a ? void 0 : a.isTimeout) ? `ScriptNetworkError: Script "${e.url}" timed out.` : `ScriptNetworkError: Failed to load script "${e.url}" - the script URL is unreachable or the server returned an error (network failure, 404, CORS, etc.)`);
        t.name = "ScriptNetworkError", (null == e ? void 0 : e.onErrorCallback) && (null == e || e.onErrorCallback(t))
       } else l ? (null == e ? void 0 : e.onErrorCallback) && (null == e || e.onErrorCallback(l)) : (null == e ? void 0 : e.cb) && (null == e || e.cb())
      };
      if (r && (r.onerror = null, r.onload = null, n(() => {
        let {
         needDeleteScript: t = !0
        } = e;
        t && (null == r ? void 0 : r.parentNode) && r.parentNode.removeChild(r)
       }), o && "function" == typeof o)) {
       let e = o(a);
       if (e instanceof Promise) {
        let t = await e;
        return i(), t
       }
       return i(), e
      }
      i()
     };
     return r.onerror = c.bind(null, r.onerror), r.onload = c.bind(null, r.onload), t = setTimeout(() => {
      c(null, {
       type: "error",
       isTimeout: !0
      })
     }, i), {
      script: r,
      needAttach: o
     }
    }

    function s(e, t) {
     let {
      attrs: r = {},
      createScriptHook: o
     } = t;
     return new Promise((t, n) => {
      let {
       script: a,
       needAttach: s
      } = i({
       url: e,
       cb: t,
       onErrorCallback: n,
       attrs: {
        fetchpriority: "high",
        ...r
       },
       createScriptHook: o,
       needDeleteScript: !0
      });
      s && document.head.appendChild(a)
     })
    }
    t.createLink = function(e) {
     let t = null,
      r = !0,
      o = document.getElementsByTagName("link");
     for (let n = 0; n < o.length; n++) {
      let i = o[n],
       s = i.getAttribute("href"),
       l = i.getAttribute("rel");
      if (s && a(s, e.url) && l === e.attrs.rel) {
       t = i, r = !1;
       break
      }
     }
     if (!t) {
      let r;
      (t = document.createElement("link")).setAttribute("href", e.url);
      let o = e.attrs;
      e.createLinkHook && (r = e.createLinkHook(e.url, o)) instanceof HTMLLinkElement && (t = r), o && !r && Object.keys(o).forEach(e => {
       t && !t.getAttribute(e) && t.setAttribute(e, o[e])
      })
     }
     let i = (r, o) => {
      let a = () => {
       (null == o ? void 0 : o.type) === "error" ? (null == e ? void 0 : e.onErrorCallback) && (null == e || e.onErrorCallback(o)) : (null == e ? void 0 : e.cb) && (null == e || e.cb())
      };
      if (t && (t.onerror = null, t.onload = null, n(() => {
        let {
         needDeleteLink: r = !0
        } = e;
        r && (null == t ? void 0 : t.parentNode) && t.parentNode.removeChild(t)
       }), r)) {
       let e = r(o);
       return a(), e
      }
      a()
     };
     return t.onerror = i.bind(null, t.onerror), t.onload = i.bind(null, t.onload), {
      link: t,
      needAttach: r
     }
    }, t.createScript = i, t.isStaticResourcesEqual = a, t.loadScript = s, t.safeWrapper = n
   },
   33054(e, t, r) {
    let o = r(88977),
     n = "u" > typeof ENV_TARGET ? "web" === ENV_TARGET : "u" > typeof window && void 0 !== window.document;

    function a() {
     return n
    }

    function i() {
     var e;
     return "u" > typeof navigator && (null == (e = navigator) ? void 0 : e.product) === "ReactNative"
    }

    function s() {
     try {
      if (a() && window.localStorage) return !!localStorage.getItem(o.BROWSER_LOG_KEY)
     } catch (e) {}
     return !1
    }

    function l() {
     return "u" > typeof process && process.env && process.env.FEDERATION_DEBUG ? !!process.env.FEDERATION_DEBUG : !!("u" > typeof FEDERATION_DEBUG && FEDERATION_DEBUG) || s()
    }
    t.getProcessEnv = function() {
     return "u" > typeof process && process.env ? process.env : {}
    }, t.isBrowserEnv = a, t.isBrowserEnvValue = n, t.isDebugMode = l, t.isReactNativeEnv = i
   },
   38027(e, t, r) {
    let o = r(88977),
     n = (e, t) => {
      if (!e) return t;
      let r = (e => {
       if ("." === e) return "";
       if (e.startsWith("./")) return e.replace("./", "");
       if (e.startsWith("/")) {
        let t = e.slice(1);
        return t.endsWith("/") ? t.slice(0, -1) : t
       }
       return e
      })(e);
      return r ? r.endsWith("/") ? `${r}${t}` : `${r}/${t}` : t
     };

    function a(e) {
     return e.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/")
    }

    function i(e) {
     return !!("remoteEntry" in e && e.remoteEntry.includes(o.MANIFEST_EXT))
    }

    function s(e) {
     if (!e) return {
      statsFileName: o.StatsFileName,
      manifestFileName: o.ManifestFileName
     };
     let t = "boolean" == typeof e ? "" : e.filePath || "",
      r = "boolean" == typeof e ? "" : e.fileName || "",
      a = ".json",
      i = e => e.endsWith(a) ? e : `${e}${a}`,
      s = (e, t) => e.replace(a, `${t}${a}`),
      l = r ? i(r) : o.ManifestFileName;
     return {
      statsFileName: n(t, r ? s(l, "-stats") : o.StatsFileName),
      manifestFileName: n(t, l)
     }
    }
    t.generateSnapshotFromManifest = function(e) {
     var t, r, o;
     let i, s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      {
       remotes: l = {},
       overrides: u = {},
       version: c
      } = s,
      d = () => "publicPath" in e.metaData ? ("auto" === e.metaData.publicPath || "" === e.metaData.publicPath) && c ? a(c) : e.metaData.publicPath : e.metaData.getPublicPath,
      f = Object.keys(u),
      p = {};
     Object.keys(l).length || (p = (null == (t = e.remotes) ? void 0 : t.reduce((e, t) => {
      let r, o = t.federationContainerName;
      return r = f.includes(o) ? u[o] : "version" in t ? t.version : t.entry, e[o] = {
       matchedVersion: r
      }, e
     }, {})) || {}), Object.keys(l).forEach(e => p[e] = {
      matchedVersion: f.includes(e) ? u[e] : l[e]
     });
     let {
      remoteEntry: {
       path: h,
       name: m,
       type: g
      },
      types: y = {
       path: "",
       name: "",
       zip: "",
       api: ""
      },
      buildInfo: {
       buildVersion: E
      },
      globalName: S,
      ssrRemoteEntry: b
     } = e.metaData, {
      exposes: _
     } = e, v = {
      version: c || "",
      buildVersion: E,
      globalName: S,
      remoteEntry: n(h, m),
      remoteEntryType: g,
      remoteTypes: n(y.path, y.name),
      remoteTypesZip: y.zip || "",
      remoteTypesAPI: y.api || "",
      remotesInfo: p,
      shared: null == e ? void 0 : e.shared.map(e => ({
       assets: e.assets,
       sharedName: e.name,
       version: e.version,
       usedExports: e.referenceExports || []
      })),
      modules: null == _ ? void 0 : _.map(e => ({
       moduleName: e.name,
       modulePath: e.path,
       assets: e.assets
      }))
     };
     if (null == (r = e.metaData) ? void 0 : r.prefetchInterface) {
      let t = e.metaData.prefetchInterface;
      v = {
       ...v,
       prefetchInterface: t
      }
     }
     if (null == (o = e.metaData) ? void 0 : o.prefetchEntry) {
      let {
       path: t,
       name: r,
       type: o
      } = e.metaData.prefetchEntry;
      v = {
       ...v,
       prefetchEntry: n(t, r),
       prefetchEntryType: o
      }
     }
     if ("publicPath" in e.metaData ? (i = {
       ...v,
       publicPath: d()
      }, "string" == typeof e.metaData.ssrPublicPath && (i.ssrPublicPath = e.metaData.ssrPublicPath)) : i = {
       ...v,
       getPublicPath: d()
      }, b) {
      let e = n(b.path, b.name);
      i.ssrRemoteEntry = e, i.ssrRemoteEntryType = b.type || "commonjs-module"
     }
     return i
    }, t.getManifestFileName = s, t.inferAutoPublicPath = a, t.isManifestProvider = i, t.simpleJoinRemoteEntry = n
   },
   39839(e, t, r) {
    Object.defineProperty(t, Symbol.toStringTag, {
     value: "Module"
    });
    let o = r(88977),
     n = r(93124),
     a = r(74197),
     i = r(24366),
     s = r(42504),
     l = r(19208),
     u = r(5837),
     c = r(33054),
     d = r(57256),
     f = r(38027),
     p = r(52933),
     h = r(53919),
     m = r(14133),
     g = r(29284),
     y = r(40396);
    t.BROWSER_LOG_KEY = o.BROWSER_LOG_KEY, t.ENCODE_NAME_PREFIX = o.ENCODE_NAME_PREFIX, t.EncodedNameTransformMap = o.EncodedNameTransformMap, t.FederationModuleManifest = o.FederationModuleManifest, t.MANIFEST_EXT = o.MANIFEST_EXT, t.MFModuleType = o.MFModuleType, t.MFPrefetchCommon = o.MFPrefetchCommon, t.MODULE_DEVTOOL_IDENTIFIER = o.MODULE_DEVTOOL_IDENTIFIER, t.ManifestFileName = o.ManifestFileName, t.NameTransformMap = o.NameTransformMap, t.NameTransformSymbol = o.NameTransformSymbol, t.SEPARATOR = o.SEPARATOR, t.StatsFileName = o.StatsFileName, t.TEMP_DIR = o.TEMP_DIR, t.TreeShakingStatus = o.TreeShakingStatus, t.assert = d.assert, t.bindLoggerToCompiler = p.bindLoggerToCompiler, t.composeKeyWithSeparator = d.composeKeyWithSeparator, Object.defineProperty(t, "consumeSharedPlugin", {
     enumerable: !0,
     get: function() {
      return l.ConsumeSharedPlugin_exports
     }
    }), Object.defineProperty(t, "containerPlugin", {
     enumerable: !0,
     get: function() {
      return n.ContainerPlugin_exports
     }
    }), Object.defineProperty(t, "containerReferencePlugin", {
     enumerable: !0,
     get: function() {
      return a.ContainerReferencePlugin_exports
     }
    }), t.createInfrastructureLogger = p.createInfrastructureLogger, t.createLink = h.createLink, t.createLogger = p.createLogger, t.createModuleFederationConfig = y.createModuleFederationConfig, t.createScript = h.createScript, t.createScriptNode = m.createScriptNode, t.decodeName = d.decodeName, t.encodeName = d.encodeName, t.error = d.error, t.generateExposeFilename = d.generateExposeFilename, t.generateShareFilename = d.generateShareFilename, t.generateSnapshotFromManifest = f.generateSnapshotFromManifest, t.getManifestFileName = f.getManifestFileName, t.getProcessEnv = c.getProcessEnv, t.getResourceUrl = d.getResourceUrl, t.inferAutoPublicPath = f.inferAutoPublicPath, t.infrastructureLogger = p.infrastructureLogger, t.isBrowserEnv = c.isBrowserEnv, t.isBrowserEnvValue = c.isBrowserEnvValue, t.isDebugMode = c.isDebugMode, t.isManifestProvider = f.isManifestProvider, t.isReactNativeEnv = c.isReactNativeEnv, t.isRequiredVersion = d.isRequiredVersion, t.isStaticResourcesEqual = h.isStaticResourcesEqual, t.loadScript = h.loadScript, t.loadScriptNode = m.loadScriptNode, t.logger = p.logger, Object.defineProperty(t, "moduleFederationPlugin", {
     enumerable: !0,
     get: function() {
      return i.ModuleFederationPlugin_exports
     }
    }), t.normalizeOptions = g.normalizeOptions, t.parseEntry = d.parseEntry, Object.defineProperty(t, "provideSharedPlugin", {
     enumerable: !0,
     get: function() {
      return u.ProvideSharedPlugin_exports
     }
    }), t.safeToString = d.safeToString, t.safeWrapper = h.safeWrapper, Object.defineProperty(t, "sharePlugin", {
     enumerable: !0,
     get: function() {
      return s.SharePlugin_exports
     }
    }), t.simpleJoinRemoteEntry = f.simpleJoinRemoteEntry, t.warn = d.warn
   },
   52933(e, t, r) {
    let o = r(33054),
     n = "[ Module Federation ]",
     a = console,
     i = ["logger.ts", "logger.js", "captureStackTrace", "Logger.emit", "Logger.log", "Logger.info", "Logger.warn", "Logger.error", "Logger.debug"];

    function s() {
     try {
      let e = Error().stack;
      if (!e) return;
      let [, ...t] = e.split("\n"), r = t.filter(e => !i.some(t => e.includes(t)));
      if (!r.length) return;
      return `Stack trace:
${r.slice(0,5).join("\n")}`
     } catch {
      return
     }
    }
    var l = class {
     setPrefix(e) {
      this.prefix = e
     }
     setDelegate(e) {
      this.delegate = e ?? a
     }
     emit(e, t) {
      let r = this.delegate,
       n = o.isDebugMode() ? s() : void 0,
       i = n ? [...t, n] : t,
       l = (() => {
        switch (e) {
         case "log":
          return ["log", "info"];
         case "info":
          return ["info", "log"];
         case "warn":
          return ["warn", "info", "log"];
         case "error":
          return ["error", "warn", "log"];
         default:
          return ["debug", "log"]
        }
       })();
      for (let e of l) {
       let t = r[e];
       if ("function" == typeof t) return void t.call(r, this.prefix, ...i)
      }
      for (let e of l) {
       let t = a[e];
       if ("function" == typeof t) return void t.call(a, this.prefix, ...i)
      }
     }
     log() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      this.emit("log", t)
     }
     warn() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      this.emit("warn", t)
     }
     error() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      this.emit("error", t)
     }
     success() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      this.emit("info", t)
     }
     info() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      this.emit("info", t)
     }
     ready() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      this.emit("info", t)
     }
     debug() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      o.isDebugMode() && this.emit("debug", t)
     }
     constructor(e, t = a) {
      this.prefix = e, this.delegate = t ?? a
     }
    };

    function u(e) {
     return new l(e)
    }

    function c(e) {
     let t = new l(e);
     return Object.defineProperty(t, "__mf_infrastructure_logger__", {
      value: !0,
      enumerable: !1,
      configurable: !1
     }), t
    }

    function d(e, t, r) {
     if (e.__mf_infrastructure_logger__ && (null == t ? void 0 : t.getInfrastructureLogger)) try {
      let o = t.getInfrastructureLogger(r);
      o && "object" == typeof o && ("function" == typeof o.log || "function" == typeof o.info || "function" == typeof o.warn || "function" == typeof o.error) && e.setDelegate(o)
     } catch {
      e.setDelegate(void 0)
     }
    }
    let f = u(n),
     p = c(n);
    t.bindLoggerToCompiler = d, t.createInfrastructureLogger = c, t.createLogger = u, t.infrastructureLogger = p, t.logger = f
   },
   14133(__unused_rspack_module, exports) {
    let sdkImportCache = new Map;

    function importNodeModule(e) {
     if (!e) throw Error("import specifier is required");
     if (sdkImportCache.has(e)) return sdkImportCache.get(e);
     let t = Function("name", "return import(name)")(e).then(e => e).catch(t => {
      throw console.error(`Error importing module ${e}:`, t), sdkImportCache.delete(e), t
     });
     return sdkImportCache.set(e, t), t
    }
    let loadNodeFetch = async () => {
     let e = await importNodeModule("node-fetch");
     return e.default || e
    }, lazyLoaderHookFetch = async (e, t, r) => {
     let o = (e, t) => r.lifecycle.fetch.emit(e, t),
      n = await o(e, t || {});
     return n && n instanceof Response ? n : ("u" < typeof fetch ? await loadNodeFetch() : fetch)(e, t || {})
    }, createScriptNode = "u" < typeof ENV_TARGET || "web" !== ENV_TARGET ? (url, cb, attrs, loaderHook) => {
     let urlObj;
     if (null == loaderHook ? void 0 : loaderHook.createScriptHook) {
      let hookResult = loaderHook.createScriptHook(url);
      hookResult && "object" == typeof hookResult && "url" in hookResult && (url = hookResult.url)
     }
     try {
      urlObj = new URL(url)
     } catch (e) {
      console.error("Error constructing URL:", e), cb(Error(`Invalid URL: ${e}`));
      return
     }
     let getFetch = async () => (null == loaderHook ? void 0 : loaderHook.fetch) ? (e, t) => lazyLoaderHookFetch(e, t, loaderHook) : "u" < typeof fetch ? loadNodeFetch() : fetch, handleScriptFetch = async (f, urlObj) => {
      try {
       var _vm_constants;
       let requireFn, res = await f(urlObj.href),
        data = await res.text(),
        [path, vm] = await Promise.all([importNodeModule("path"), importNodeModule("vm")]),
        scriptContext = {
         exports: {},
         module: {
          exports: {}
         }
        },
        urlDirname = urlObj.pathname.split("/").slice(0, -1).join("/"),
        filename = path.basename(urlObj.pathname),
        script = new vm.Script(`(function(exports, module, require, __dirname, __filename) {${data}
})`, {
         filename,
         importModuleDynamically: (null == (_vm_constants = vm.constants) ? void 0 : _vm_constants.USE_MAIN_CONTEXT_DEFAULT_LOADER) ?? importNodeModule
        });
       requireFn = eval("require"), script.runInThisContext()(scriptContext.exports, scriptContext.module, requireFn, urlDirname, filename);
       let exportedInterface = scriptContext.module.exports || scriptContext.exports;
       if (attrs && exportedInterface && attrs.globalName) return void cb(void 0, exportedInterface[attrs.globalName] || exportedInterface);
       cb(void 0, exportedInterface)
      } catch (e) {
       cb(e instanceof Error ? e : Error(`Script execution error: ${e}`))
      }
     };
     getFetch().then(async e => {
      if ((null == attrs ? void 0 : attrs.type) === "esm" || (null == attrs ? void 0 : attrs.type) === "module") return loadModule(urlObj.href, {
       fetch: e,
       vm: await importNodeModule("vm")
      }).then(async e => {
       await e.evaluate(), cb(void 0, e.namespace)
      }).catch(e => {
       cb(e instanceof Error ? e : Error(`Script execution error: ${e}`))
      });
      handleScriptFetch(e, urlObj)
     }).catch(e => {
      cb(e)
     })
    } : (e, t, r, o) => {
     t(Error("createScriptNode is disabled in non-Node.js environment"))
    }, loadScriptNode = "u" < typeof ENV_TARGET || "web" !== ENV_TARGET ? (e, t) => new Promise((r, o) => {
     createScriptNode(e, (e, n) => {
      if (e) o(e);
      else {
       var a, i;
       let e = (null == t || null == (a = t.attrs) ? void 0 : a.globalName) || `__FEDERATION_${null==t||null==(i=t.attrs)?void 0:i.name}:custom__`;
       r(globalThis[e] = n)
      }
     }, t.attrs, t.loaderHook)
    }) : (e, t) => {
     throw Error("loadScriptNode is disabled in non-Node.js environment")
    }, esmModuleCache = new Map;
    async function loadModule(e, t) {
     if (esmModuleCache.has(e)) return esmModuleCache.get(e);
     let {
      fetch: r,
      vm: o
     } = t, n = await (await r(e)).text(), a = new o.SourceTextModule(n, {
      importModuleDynamically: async (r, o) => loadModule(new URL(r, e).href, t)
     });
     return esmModuleCache.set(e, a), await a.link(async r => {
      let o = new URL(r, e).href;
      return await loadModule(o, t)
     }), a
    }
    exports.createScriptNode = createScriptNode, exports.loadScriptNode = loadScriptNode
   },
   29284(e, t) {
    t.normalizeOptions = function(e, t, r) {
     return function(o) {
      if (!1 === o) return !1;
      if (void 0 === o)
       if (e) return t;
       else return !1;
      if (!0 === o) return t;
      if (o && "object" == typeof o) return {
       ...t,
       ...o
      };
      throw Error(`Unexpected type for \`${r}\`, expect boolean/undefined/object, got: ${typeof o}`)
     }
    }
   },
   19208(e, t, r) {
    var o = r(47587).__exportAll({});
    Object.defineProperty(t, "ConsumeSharedPlugin_exports", {
     enumerable: !0,
     get: function() {
      return o
     }
    })
   },
   93124(e, t, r) {
    var o = r(47587).__exportAll({});
    Object.defineProperty(t, "ContainerPlugin_exports", {
     enumerable: !0,
     get: function() {
      return o
     }
    })
   },
   74197(e, t, r) {
    var o = r(47587).__exportAll({});
    Object.defineProperty(t, "ContainerReferencePlugin_exports", {
     enumerable: !0,
     get: function() {
      return o
     }
    })
   },
   24366(e, t, r) {
    var o = r(47587).__exportAll({});
    Object.defineProperty(t, "ModuleFederationPlugin_exports", {
     enumerable: !0,
     get: function() {
      return o
     }
    })
   },
   5837(e, t, r) {
    var o = r(47587).__exportAll({});
    Object.defineProperty(t, "ProvideSharedPlugin_exports", {
     enumerable: !0,
     get: function() {
      return o
     }
    })
   },
   42504(e, t, r) {
    var o = r(47587).__exportAll({});
    Object.defineProperty(t, "SharePlugin_exports", {
     enumerable: !0,
     get: function() {
      return o
     }
    })
   },
   57256(e, t, r) {
    let o = r(88977),
     n = r(33054),
     a = "[ Federation Runtime ]",
     i = function(e, t) {
      let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : o.SEPARATOR,
       a = e.split(r),
       i = "development" === n.getProcessEnv().NODE_ENV && t,
       s = "*",
       l = e => e.startsWith("http") || e.includes(o.MANIFEST_EXT);
      if (a.length >= 2) {
       let [t, ...o] = a;
       e.startsWith(r) && (t = a.slice(0, 2).join(r), o = [i || a.slice(2).join(r)]);
       let n = i || o.join(r);
       return l(n) ? {
        name: t,
        entry: n
       } : {
        name: t,
        version: n || s
       }
      }
      if (1 === a.length) {
       let [e] = a;
       return i && l(i) ? {
        name: e,
        entry: i
       } : {
        name: e,
        version: i || s
       }
      }
      throw `Invalid entry value: ${e}`
     },
     s = function() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      return t.length ? t.reduce((e, t) => t ? e ? `${e}${o.SEPARATOR}${t}` : t : e, "") : ""
     },
     l = function(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
       r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      try {
       let n = r ? ".js" : "";
       return `${t}${e.replace(RegExp(`${o.NameTransformSymbol.AT}`,"g"),o.NameTransformMap[o.NameTransformSymbol.AT]).replace(RegExp(`${o.NameTransformSymbol.HYPHEN}`,"g"),o.NameTransformMap[o.NameTransformSymbol.HYPHEN]).replace(RegExp(`${o.NameTransformSymbol.SLASH}`,"g"),o.NameTransformMap[o.NameTransformSymbol.SLASH])}${n}`
      } catch (e) {
       throw e
      }
     },
     u = function(e, t, r) {
      try {
       let n = e;
       if (t) {
        if (!n.startsWith(t)) return n;
        n = n.replace(RegExp(t, "g"), "")
       }
       return n = n.replace(RegExp(`${o.NameTransformMap[o.NameTransformSymbol.AT]}`, "g"), o.EncodedNameTransformMap[o.NameTransformMap[o.NameTransformSymbol.AT]]).replace(RegExp(`${o.NameTransformMap[o.NameTransformSymbol.SLASH]}`, "g"), o.EncodedNameTransformMap[o.NameTransformMap[o.NameTransformSymbol.SLASH]]).replace(RegExp(`${o.NameTransformMap[o.NameTransformSymbol.HYPHEN]}`, "g"), o.EncodedNameTransformMap[o.NameTransformMap[o.NameTransformSymbol.HYPHEN]]), r && (n = n.replace(".js", "")), n
      } catch (e) {
       throw e
      }
     },
     c = (e, t) => {
      if (!e) return "";
      let r = e;
      return "." === r && (r = "default_export"), r.startsWith("./") && (r = r.replace("./", "")), l(r, "__federation_expose_", t)
     },
     d = (e, t) => e ? l(e, "__federation_shared_", t) : "",
     f = (e, t) => {
      if ("getPublicPath" in e) {
       let r;
       return r = e.getPublicPath.startsWith("function") ? Function("return " + e.getPublicPath)()() : Function(e.getPublicPath)(), `${r}${t}`
      }
      return "publicPath" in e ? !n.isBrowserEnv() && !n.isReactNativeEnv() && "ssrPublicPath" in e && "string" == typeof e.ssrPublicPath ? `${e.ssrPublicPath}${t}` : `${e.publicPath}${t}` : (console.warn("Cannot get resource URL. If in debug mode, please ignore.", e, t), "")
     },
     p = e => {
      throw Error(`${a}: ${e}`)
     },
     h = e => {
      console.warn(`${a}: ${e}`)
     };

    function m(e) {
     try {
      return JSON.stringify(e, null, 2)
     } catch (e) {
      return ""
     }
    }
    let g = /^([\d^=v<>~]|[*xX]$)/;

    function y(e) {
     return g.test(e)
    }
    t.assert = (e, t) => {
     e || p(t)
    }, t.composeKeyWithSeparator = s, t.decodeName = u, t.encodeName = l, t.error = p, t.generateExposeFilename = c, t.generateShareFilename = d, t.getResourceUrl = f, t.isRequiredVersion = y, t.parseEntry = i, t.safeToString = m, t.warn = h
   },
   84707(e, t) {
    var r = Object.create,
     o = Object.defineProperty,
     n = Object.getOwnPropertyDescriptor,
     a = Object.getOwnPropertyNames,
     i = Object.getPrototypeOf,
     s = Object.prototype.hasOwnProperty,
     l = (e, t, r, i) => {
      if (t && "object" == typeof t || "function" == typeof t)
       for (var l, u = a(t), c = 0, d = u.length; c < d; c++) l = u[c], s.call(e, l) || l === r || o(e, l, {
        get: (e => t[e]).bind(null, l),
        enumerable: !(i = n(t, l)) || i.enumerable
       });
      return e
     };
    t.__toESM = (e, t, n) => (n = null != e ? r(i(e)) : {}, l(!t && e && e.__esModule ? n : o(n, "default", {
     value: e,
     enumerable: !0
    }), e))
   },
   34373(e, t) {
    t.attachShareScopeMap = function(e) {
     e.S && !e.federation.hasAttachShareScopeMap && e.federation.instance && e.federation.instance.shareScopeMap && (e.S = e.federation.instance.shareScopeMap, e.federation.hasAttachShareScopeMap = !0)
    }
   },
   34897(e, t) {
    Object.defineProperty(t, Symbol.toStringTag, {
     value: "Module"
    }), t.FEDERATION_SUPPORTED_TYPES = ["script"]
   },
   78212(e, t, r) {
    let o = r(34373),
     n = r(68992),
     a = r(28353),
     i = r(84841),
     s = r(36609);
    t.consumes = function(e) {
     n.updateConsumeOptions(e);
     let {
      chunkId: t,
      promises: r,
      installedModules: l,
      webpackRequire: u,
      chunkMapping: c,
      moduleToHandlerMapping: d
     } = e;
     o.attachShareScopeMap(u), u.o(c, t) && c[t].forEach(e => {
      if (u.o(l, e)) return r.push(l[e]);
      let t = t => {
        l[e] = 0, u.m[e] = r => {
         var o;
         delete u.c[e];
         let n = t(),
          {
           shareInfo: a
          } = d[e];
         if ((null == a || null == (o = a.shareConfig) ? void 0 : o.layer) && n && "object" == typeof n) try {
          n.hasOwnProperty("layer") && void 0 !== n.layer || (n.layer = a.shareConfig.layer)
         } catch (e) {}
         r.exports = n
        }
       },
       o = t => {
        delete l[e], u.m[e] = r => {
         throw delete u.c[e], t
        }
       };
      try {
       let n = u.federation.instance;
       if (!n) throw Error("Federation instance not found!");
       let {
        shareKey: c,
        getter: f,
        shareInfo: p,
        treeShakingGetter: h
       } = d[e], m = a.getUsedExports(u, c), g = {
        ...p
       };
       Array.isArray(g.scope) && Array.isArray(g.scope[0]) && (g.scope = g.scope[0]), m && (g.treeShaking = {
        usedExports: m,
        useIn: [n.options.name]
       });
       let y = n.loadShare(c, {
        customShareInfo: g
       }).then(e => {
        if (!1 === e) {
         if ("function" != typeof f) throw Error(s.getShortErrorMsg(i.RUNTIME_012, {
          [i.RUNTIME_012]: 'The getter for the shared module is not a function. This may be caused by setting "shared.import: false" without the host providing the corresponding lib.'
         }, {
          shareKey: c
         }));
         return (null == h ? void 0 : h()) || f()
        }
        return e
       });
       y.then ? r.push(l[e] = y.then(t).catch(o)) : t(y)
      } catch (e) {
       o(e)
      }
     })
    }
   },
   84841(e, t) {
    t.RUNTIME_012 = "RUNTIME-012"
   },
   36609(e, t) {
    let r = e => `View the docs to see how to solve: https://module-federation.io/guide/troubleshooting/${e.split("-")[0].toLowerCase()}#${e.toLowerCase()}`;
    t.getShortErrorMsg = (e, t, o, n) => {
     let a = [`${[t[e]]} #${e}`];
     return o && a.push(`args: ${JSON.stringify(o)}`), a.push(r(e)), n && a.push(`Original Error Message:
 ${n}`), a.join("\n")
    }
   },
   94199(e, t) {
    t.getSharedFallbackGetter = e => {
     let {
      shareKey: t,
      factory: r,
      version: o,
      webpackRequire: n,
      libraryType: a = "global"
     } = e, {
      runtime: i,
      instance: s,
      bundlerRuntime: l,
      sharedFallback: u
     } = n.federation;
     if (!u) return r;
     let c = u[t];
     if (!c) return r;
     let d = o ? c.find(e => e[1] === o) : c[0];
     if (!d) throw Error(`No fallback item found for shareKey: ${t} and version: ${o}`);
     return () => i.getRemoteEntry({
      origin: n.federation.instance,
      remoteInfo: {
       name: d[2],
       entry: `${n.p}${d[0]}`,
       type: a,
       entryGlobalName: d[2],
       shareScope: "default"
      }
     }).then(e => {
      if (!e) throw Error(`Failed to load fallback entry for shareKey: ${t} and version: ${o}`);
      return e.init(n.federation.instance, l).then(() => e.get())
     })
    }
   },
   28353(e, t) {
    t.getUsedExports = function(e, t) {
     let r = e.federation.usedExports;
     if (r) return r[t]
    }
   },
   7455(e, t, r) {
    Object.defineProperties(t, {
     __esModule: {
      value: !0
     },
     [Symbol.toStringTag]: {
      value: "Module"
     }
    });
    let o = r(84707),
     n = r(34373),
     a = r(34246),
     i = r(78212),
     s = r(16985),
     l = r(42855),
     u = r(23424),
     c = r(61443),
     d = r(94199),
     f = r(60911),
     p = {
      runtime: f = o.__toESM(f),
      instance: void 0,
      initOptions: void 0,
      bundlerRuntime: {
       remotes: a.remotes,
       consumes: i.consumes,
       I: s.initializeSharing,
       S: {},
       installInitialConsumes: l.installInitialConsumes,
       initContainerEntry: u.initContainerEntry,
       init: c.init,
       getSharedFallbackGetter: d.getSharedFallbackGetter
      },
      attachShareScopeMap: n.attachShareScopeMap,
      bundlerRuntimeOptions: {}
     },
     h = p.instance,
     m = p.initOptions,
     g = p.bundlerRuntime,
     y = p.bundlerRuntimeOptions;
    t.attachShareScopeMap = n.attachShareScopeMap, t.bundlerRuntime = g, t.bundlerRuntimeOptions = y, t.default = p, t.initOptions = m, t.instance = h, Object.defineProperty(t, "runtime", {
     enumerable: !0,
     get: function() {
      return f
     }
    })
   },
   61443(e, t, r) {
    let o = r(84707),
     n = r(60911),
     a = r(69848);
    a = o.__toESM(a), t.init = function(e) {
     var t;
     let {
      webpackRequire: o
     } = e, {
      initOptions: i,
      runtime: s,
      sharedFallback: l,
      bundlerRuntime: u,
      libraryType: c
     } = o.federation;
     if (!i) throw Error("initOptions is required!");
     let d = function() {
      return {
       name: "tree-shake-plugin",
       beforeInit(e) {
        let {
         userOptions: t,
         origin: i,
         options: s
        } = e, d = t.version || s.version;
        if (!l) return e;
        let f = t.shared || {},
         p = [];
        Object.keys(f).forEach(e => {
         (Array.isArray(f[e]) ? f[e] : [f[e]]).forEach(t => {
          if (p.push([e, t]), "get" in t) {
           var r;
           (r = t).treeShaking || (r.treeShaking = {}), t.treeShaking.get = t.get, t.get = u.getSharedFallbackGetter({
            shareKey: e,
            factory: t.get,
            webpackRequire: o,
            libraryType: c,
            version: t.version
           })
          }
         })
        });
        let h = a.default.global.getGlobalSnapshotInfoByModuleInfo({
         name: i.name,
         version: d
        });
        if (!h || !("shared" in h)) return e;
        Object.keys(s.shared || {}).forEach(e => {
         s.shared[e].forEach(t => {
          p.push([e, t])
         })
        });
        let m = (e, t) => {
         let o = h.shared.find(t => t.sharedName === e);
         if (!o) return;
         let {
          treeShaking: a
         } = t;
         if (!a) return;
         let {
          secondarySharedTreeShakingName: s,
          secondarySharedTreeShakingEntry: l,
          treeShakingStatus: u
         } = o;
         a.status !== u && (a.status = u, l && c && s && (a.get = async () => {
          let e = await (0, n.getRemoteEntry)({
           origin: i,
           remoteInfo: {
            name: s,
            entry: l,
            type: c,
            entryGlobalName: s,
            shareScope: "default"
           }
          });
          return await e.init(i, r.federation.bundlerRuntime), e.get()
         }))
        };
        return p.forEach(e => {
         let [t, r] = e;
         m(t, r)
        }), e
       }
      }
     };
     return (t = i).plugins || (t.plugins = []), i.plugins.push(d()), s.init(i)
    }
   },
   23424(e, t) {
    t.initContainerEntry = function(e) {
     let {
      webpackRequire: t,
      shareScope: r,
      initScope: o,
      shareScopeKey: n,
      remoteEntryInitOptions: a
     } = e;
     if (!t.S || !t.federation || !t.federation.instance || !t.federation.initOptions) return;
     let i = t.federation.instance;
     i.initOptions({
      name: t.federation.initOptions.name,
      remotes: [],
      ...a
     });
     let s = null == a ? void 0 : a.shareScopeKeys,
      l = null == a ? void 0 : a.shareScopeMap;
     if (n && "string" != typeof n) n.forEach(e => {
      if (!s || !l) return void i.initShareScopeMap(e, r, {
       hostShareScopeMap: (null == a ? void 0 : a.shareScopeMap) || {}
      });
      l[e] || (l[e] = {});
      let t = l[e];
      i.initShareScopeMap(e, t, {
       hostShareScopeMap: (null == a ? void 0 : a.shareScopeMap) || {}
      })
     });
     else {
      let e = n || "default";
      Array.isArray(s) ? s.forEach(e => {
       l[e] || (l[e] = {});
       let t = l[e];
       i.initShareScopeMap(e, t, {
        hostShareScopeMap: (null == a ? void 0 : a.shareScopeMap) || {}
       })
      }) : i.initShareScopeMap(e, r, {
       hostShareScopeMap: (null == a ? void 0 : a.shareScopeMap) || {}
      })
     }
     return (t.federation.attachShareScopeMap && t.federation.attachShareScopeMap(t), "function" == typeof t.federation.prefetch && t.federation.prefetch(), Array.isArray(n)) ? t.federation.initOptions.shared ? t.I(n, o) : Promise.all(n.map(e => t.I(e, o))).then(() => !0) : t.I(n || "default", o)
    }
   },
   16985(e, t, r) {
    let o = r(34373),
     n = r(34897);
    t.initializeSharing = function(e) {
     let {
      shareScopeName: t,
      webpackRequire: r,
      initPromises: a,
      initTokens: i,
      initScope: s
     } = e, l = Array.isArray(t) ? t : [t];
     var u = [],
      c = function(e) {
       s || (s = []);
       let l = r.federation.instance;
       var u = i[e];
       if (u || (u = i[e] = {
         from: l.name
        }), s.indexOf(u) >= 0) return;
       s.push(u);
       let c = a[e];
       if (c) return c;
       var d = e => "u" > typeof console && console.warn && console.warn(e),
        f = o => {
         var n = e => d("Initialization of sharing external failed: " + e);
         try {
          var a = r(o);
          if (!a) return;
          var i = o => o && o.init && o.init(r.S[e], s, {
           shareScopeMap: r.S || {},
           shareScopeKeys: t
          });
          if (a.then) return p.push(a.then(i, n));
          var l = i(a);
          if (l && "boolean" != typeof l && l.then) return p.push(l.catch(n))
         } catch (e) {
          n(e)
         }
        };
       let p = l.initializeSharing(e, {
        strategy: l.options.shareStrategy,
        initScope: s,
        from: "build"
       });
       o.attachShareScopeMap(r);
       let h = r.federation.bundlerRuntimeOptions.remotes;
       return (h && Object.keys(h.idToRemoteMap).forEach(e => {
        let t = h.idToRemoteMap[e],
         r = h.idToExternalAndNameMapping[e][2];
        if (t.length > 1) f(r);
        else if (1 === t.length) {
         let e = t[0];
         n.FEDERATION_SUPPORTED_TYPES.includes(e.externalType) || f(r)
        }
       }), p.length) ? a[e] = Promise.all(p).then(() => a[e] = !0) : a[e] = !0
      };
     return l.forEach(e => {
      u.push(c(e))
     }), Promise.all(u).then(() => !0)
    }
   },
   42855(e, t, r) {
    let o = r(68992),
     n = r(28353);

    function a(e) {
     let {
      moduleId: t,
      moduleToHandlerMapping: r,
      webpackRequire: o,
      asyncLoad: a
     } = e, i = o.federation.instance;
     if (!i) throw Error("Federation instance not found!");
     let {
      shareKey: s,
      shareInfo: l
     } = r[t];
     try {
      let e = n.getUsedExports(o, s),
       t = {
        ...l
       };
      if (e && (t.treeShaking = {
        usedExports: e,
        useIn: [i.options.name]
       }), a) return i.loadShare(s, {
       customShareInfo: t
      });
      return i.loadShareSync(s, {
       customShareInfo: t
      })
     } catch (e) {
      throw console.error('loadShareSync failed! The function should not be called unless you set "eager:true". If you do not set it, and encounter this issue, you can check whether an async boundary is implemented.'), console.error("The original error message is as follows: "), e
     }
    }
    t.installInitialConsumes = function(e) {
     o.updateConsumeOptions(e);
     let {
      moduleToHandlerMapping: t,
      webpackRequire: r,
      installedModules: n,
      initialConsumes: i,
      asyncLoad: s
     } = e, l = [];
     i.forEach(e => {
      let o = () => a({
       moduleId: e,
       moduleToHandlerMapping: t,
       webpackRequire: r,
       asyncLoad: s
      });
      l.push([e, o])
     });
     let u = (e, o) => {
      r.m[e] = a => {
       var i;
       n[e] = 0, delete r.c[e];
       let s = o();
       if ("function" != typeof s) throw Error(`Shared module is not available for eager consumption: ${e}`);
       let l = s(),
        {
         shareInfo: u
        } = t[e];
       if ((null == u || null == (i = u.shareConfig) ? void 0 : i.layer) && l && "object" == typeof l) try {
        l.hasOwnProperty("layer") && void 0 !== l.layer || (l.layer = u.shareConfig.layer)
       } catch (e) {}
       a.exports = l
      }
     };
     if (s) return Promise.all(l.map(async e => {
      let [t, r] = e, o = await r();
      u(t, () => o)
     }));
     l.forEach(e => {
      let [t, r] = e;
      u(t, r)
     })
    }
   },
   34246(e, t, r) {
    r(84707);
    let o = r(34373),
     n = r(34897),
     a = r(68992),
     i = r(39839);
    t.remotes = function(e) {
     a.updateRemoteOptions(e);
     let {
      chunkId: t,
      promises: r,
      webpackRequire: s,
      chunkMapping: l,
      idToExternalAndNameMapping: u,
      idToRemoteMap: c
     } = e;
     o.attachShareScopeMap(s), s.o(l, t) && l[t].forEach(e => {
      let t = s.R;
      t || (t = []);
      let o = u[e],
       a = c[e] || [];
      if (t.indexOf(o) >= 0) return;
      if (t.push(o), o.p) return r.push(o.p);
      let l = t => {
        t || (t = Error("Container missing")), "string" == typeof t.message && (t.message += `
while loading "${o[1]}" from ${o[2]}`), s.m[e] = () => {
         throw t
        }, o.p = 0
       },
       d = (e, t, n, a, i, s) => {
        try {
         let u = e(t, n);
         if (!u || !u.then) return i(u, a, s);
         {
          let e = u.then(e => i(e, a), l);
          if (!s) return e;
          r.push(o.p = e)
         }
        } catch (e) {
         l(e)
        }
       },
       f = (e, t, r) => e ? d(s.I, o[0], 0, e, p, r) : l();
      var p = (e, r, n) => d(r.get, o[1], t, 0, h, n),
       h = t => {
        o.p = 1, s.m[e] = e => {
         e.exports = t()
        }
       };
      let m = () => {
       try {
        let e = (0, i.decodeName)(a[0].name, i.ENCODE_NAME_PREFIX) + o[1].slice(1),
         t = s.federation.instance,
         r = () => s.federation.instance.loadRemote(e, {
          loadFactory: !1,
          from: "build"
         });
        if ("version-first" === t.options.shareStrategy) {
         let e = Array.isArray(o[0]) ? o[0] : [o[0]];
         return Promise.all(e.map(e => t.sharedHandler.initializeSharing(e))).then(() => r())
        }
        return r()
       } catch (e) {
        l(e)
       }
      };
      1 === a.length && n.FEDERATION_SUPPORTED_TYPES.includes(a[0].externalType) && a[0].name ? d(m, o[2], 0, 0, h, 1) : d(s, o[2], 0, 0, f, 1)
     })
    }
   },
   68992(e, t) {
    function r(e) {
     var t, r, o, n, a;
     let {
      webpackRequire: i,
      idToExternalAndNameMapping: s = {},
      idToRemoteMap: l = {},
      chunkMapping: u = {}
     } = e, {
      remotesLoadingData: c
     } = i, d = null == (o = i.federation) || null == (r = o.bundlerRuntimeOptions) || null == (t = r.remotes) ? void 0 : t.remoteInfos;
     if (!c || c._updated || !d) return;
     let {
      chunkMapping: f,
      moduleIdToRemoteDataMapping: p
     } = c;
     if (f && p) {
      for (let [e, t] of Object.entries(p))
       if (s[e] || (s[e] = [t.shareScope, t.name, t.externalModuleId]), !l[e] && d[t.remoteName]) {
        let r = d[t.remoteName];
        (n = l)[a = e] || (n[a] = []), r.forEach(t => {
         l[e].includes(t) || l[e].push(t)
        })
       } u && Object.entries(f).forEach(e => {
       let [t, r] = e;
       u[t] || (u[t] = []), r.forEach(e => {
        u[t].includes(e) || u[t].push(e)
       })
      }), c._updated = 1
     }
    }
    t.updateConsumeOptions = function(e) {
     let {
      webpackRequire: t,
      moduleToHandlerMapping: r
     } = e, {
      consumesLoadingData: o,
      initializeSharingData: n
     } = t, {
      sharedFallback: a,
      bundlerRuntime: i,
      libraryType: s
     } = t.federation;
     if (o && !o._updated) {
      let {
       moduleIdToConsumeDataMapping: n = {},
       initialConsumes: l = [],
       chunkMapping: u = {}
      } = o;
      if (Object.entries(n).forEach(e => {
        let [o, n] = e;
        r[o] || (r[o] = {
         getter: a ? null == i ? void 0 : i.getSharedFallbackGetter({
          shareKey: n.shareKey,
          factory: n.fallback,
          webpackRequire: t,
          libraryType: s
         }) : n.fallback,
         treeShakingGetter: a ? n.fallback : void 0,
         shareInfo: {
          shareConfig: {
           requiredVersion: n.requiredVersion,
           strictVersion: n.strictVersion,
           singleton: n.singleton,
           eager: n.eager,
           layer: n.layer
          },
          scope: Array.isArray(n.shareScope) ? n.shareScope : [n.shareScope || "default"],
          treeShaking: a ? {
           get: n.fallback,
           mode: n.treeShakingMode
          } : void 0
         },
         shareKey: n.shareKey
        })
       }), "initialConsumes" in e) {
       let {
        initialConsumes: t = []
       } = e;
       l.forEach(e => {
        t.includes(e) || t.push(e)
       })
      }
      if ("chunkMapping" in e) {
       let {
        chunkMapping: t = {}
       } = e;
       Object.entries(u).forEach(e => {
        let [r, o] = e;
        t[r] || (t[r] = []), o.forEach(e => {
         t[r].includes(e) || t[r].push(e)
        })
       })
      }
      o._updated = 1
     }
     if (n && !n._updated) {
      let {
       federation: e
      } = t;
      if (!e.instance || !n.scopeToSharingDataMapping) return;
      let r = {};
      for (let [e, t] of Object.entries(n.scopeToSharingDataMapping))
       for (let o of t)
        if ("object" == typeof o && null !== o) {
         let {
          name: t,
          version: n,
          factory: a,
          eager: i,
          singleton: s,
          requiredVersion: l,
          strictVersion: u
         } = o, c = {
          requiredVersion: `^${n}`
         }, d = function(e) {
          return void 0 !== e
         };
         d(s) && (c.singleton = s), d(l) && (c.requiredVersion = l), d(i) && (c.eager = i), d(u) && (c.strictVersion = u);
         let f = {
          version: n,
          scope: [e],
          shareConfig: c,
          get: a
         };
         r[t] ? r[t].push(f) : r[t] = [f]
        } e.instance.registerShared(r), n._updated = 1
     }
    }, t.updateRemoteOptions = r
   },
   39758(e, t, r) {
    "use strict";
    var o = r(18624);

    function n() {
     let e = new o.X2("shaparak-channel"),
      t = window.location.search.substring(1).slice(7);
     e.postMessage(t), e.close(), window.close()
    }
    window.addEventListener("load", () => {
     n()
    })
   },
   58114(e, t, r) {
    "use strict";
    var o, n, a, i, s, l, u, c, d, f, p, h, m = r(7455),
     g = r.n(m);
    let y = [].filter(e => {
      let {
       plugin: t
      } = e;
      return t
     }).map(e => {
      let {
       plugin: t,
       params: r
      } = e;
      return t(r)
     }),
     E = {},
     S = "web",
     b = "version-first",
     _, v = "var",
     I = r;
    if ((I.initializeSharingData || I.initializeExposesData) && I.federation) {
     let e = (e, t, r) => {
       e && e[t] && (e[t] = r)
      },
      t = (e, t, r) => {
       var o, n, a, i, s, l;
       let u = r();
       Array.isArray(u) ? (null != (a = (o = e)[n = t]) || (o[n] = []), e[t].push(...u)) : "object" == typeof u && null !== u && (null != (l = (i = e)[s = t]) || (i[s] = {}), Object.assign(e[t], u))
      },
      r = (e, t, r) => {
       var o, n, a;
       null != (a = (o = e)[n = t]) || (o[n] = r())
      },
      m = null != (o = null == (l = I.remotesLoadingData) ? void 0 : l.chunkMapping) ? o : {},
      R = null != (n = null == (u = I.remotesLoadingData) ? void 0 : u.moduleIdToRemoteDataMapping) ? n : {},
      T = null != (a = null == (c = I.initializeSharingData) ? void 0 : c.scopeToSharingDataMapping) ? a : {},
      M = null != (i = null == (d = I.consumesLoadingData) ? void 0 : d.chunkMapping) ? i : {},
      N = null != (s = null == (f = I.consumesLoadingData) ? void 0 : f.moduleIdToConsumeDataMapping) ? s : {},
      O = {},
      A = [],
      k = {},
      P = null == (p = I.initializeExposesData) ? void 0 : p.shareScope;
     for (let e in g()) I.federation[e] = g()[e];
     r(I.federation, "libraryType", () => v), r(I.federation, "sharedFallback", () => _);
     let w = I.federation.sharedFallback;
     r(I.federation, "consumesLoadingModuleToHandlerMapping", () => {
      let e = {};
      for (let [r, o] of Object.entries(N)) {
       var t;
       e[r] = {
        getter: w ? null == (t = I.federation.bundlerRuntime) ? void 0 : t.getSharedFallbackGetter({
         shareKey: o.shareKey,
         factory: o.fallback,
         webpackRequire: I,
         libraryType: I.federation.libraryType
        }) : o.fallback,
        treeShakingGetter: w ? o.fallback : void 0,
        shareInfo: {
         shareConfig: {
          fixedDependencies: !1,
          requiredVersion: o.requiredVersion,
          strictVersion: o.strictVersion,
          singleton: o.singleton,
          eager: o.eager
         },
         scope: [o.shareScope]
        },
        shareKey: o.shareKey,
        treeShaking: I.federation.sharedFallback ? {
         get: o.fallback,
         mode: o.treeShakingMode
        } : void 0
       }
      }
      return e
     }), r(I.federation, "initOptions", () => ({})), r(I.federation.initOptions, "name", () => S), r(I.federation.initOptions, "shareStrategy", () => b), r(I.federation.initOptions, "shared", () => {
      let e = {};
      for (let [t, r] of Object.entries(T))
       for (let o of r)
        if ("object" == typeof o && null !== o) {
         let {
          name: r,
          version: n,
          factory: a,
          eager: i,
          singleton: s,
          requiredVersion: l,
          strictVersion: u,
          treeShakingMode: c
         } = o, d = {}, f = function(e) {
          return void 0 !== e
         };
         f(s) && (d.singleton = s), f(l) && (d.requiredVersion = l), f(i) && (d.eager = i), f(u) && (d.strictVersion = u);
         let p = {
          version: n,
          scope: [t],
          shareConfig: d,
          get: a,
          treeShaking: c ? {
           mode: c
          } : void 0
         };
         e[r] ? e[r].push(p) : e[r] = [p]
        } return e
     }), t(I.federation.initOptions, "remotes", () => Object.values(E).flat().filter(e => "script" === e.externalType)), t(I.federation.initOptions, "plugins", () => y), r(I.federation, "bundlerRuntimeOptions", () => ({})), r(I.federation.bundlerRuntimeOptions, "remotes", () => ({})), r(I.federation.bundlerRuntimeOptions.remotes, "chunkMapping", () => m), r(I.federation.bundlerRuntimeOptions.remotes, "remoteInfos", () => E), r(I.federation.bundlerRuntimeOptions.remotes, "idToExternalAndNameMapping", () => {
      let e = {};
      for (let [t, r] of Object.entries(R)) e[t] = [r.shareScope, r.name, r.externalModuleId, r.remoteName];
      return e
     }), r(I.federation.bundlerRuntimeOptions.remotes, "webpackRequire", () => I), t(I.federation.bundlerRuntimeOptions.remotes, "idToRemoteMap", () => {
      let e = {};
      for (let [t, r] of Object.entries(R)) {
       let o = E[r.remoteName];
       o && (e[t] = o)
      }
      return e
     }), e(I, "S", I.federation.bundlerRuntime.S), I.federation.attachShareScopeMap && I.federation.attachShareScopeMap(I), e(I.f, "remotes", (e, t) => I.federation.bundlerRuntime.remotes({
      chunkId: e,
      promises: t,
      chunkMapping: m,
      idToExternalAndNameMapping: I.federation.bundlerRuntimeOptions.remotes.idToExternalAndNameMapping,
      idToRemoteMap: I.federation.bundlerRuntimeOptions.remotes.idToRemoteMap,
      webpackRequire: I
     })), e(I.f, "consumes", (e, t) => I.federation.bundlerRuntime.consumes({
      chunkId: e,
      promises: t,
      chunkMapping: M,
      moduleToHandlerMapping: I.federation.consumesLoadingModuleToHandlerMapping,
      installedModules: O,
      webpackRequire: I
     })), e(I, "I", (e, t) => I.federation.bundlerRuntime.I({
      shareScopeName: e,
      initScope: t,
      initPromises: A,
      initTokens: k,
      webpackRequire: I
     })), e(I, "initContainer", (e, t, r) => I.federation.bundlerRuntime.initContainerEntry({
      shareScope: e,
      initScope: t,
      remoteEntryInitOptions: r,
      shareScopeKey: P,
      webpackRequire: I
     })), e(I, "getContainer", (e, t) => {
      var r = I.initializeExposesData.moduleMap;
      return I.R = t, t = Object.prototype.hasOwnProperty.call(r, e) ? r[e]() : Promise.resolve().then(() => {
       throw Error('Module "' + e + '" does not exist in container.')
      }), I.R = void 0, t
     }), I.federation.instance = I.federation.bundlerRuntime.init({
      webpackRequire: I
     }), (null == (h = I.consumesLoadingData) ? void 0 : h.initialConsumes) && I.federation.bundlerRuntime.installInitialConsumes({
      webpackRequire: I,
      installedModules: O,
      initialConsumes: I.consumesLoadingData.initialConsumes,
      moduleToHandlerMapping: I.federation.consumesLoadingModuleToHandlerMapping
     })
    }
   },
   40643() {}
  },
  __webpack_module_cache__ = {};

 function __webpack_require__(e) {
  var t = __webpack_module_cache__[e];
  if (void 0 !== t) return t.exports;
  var r = __webpack_module_cache__[e] = {
   exports: {}
  };
  return __webpack_modules__[e](r, r.exports, __webpack_require__), r.exports
 }
 __webpack_require__.m = __webpack_modules__, __webpack_require__.c = __webpack_module_cache__, __webpack_require__.x = () => {
  var e = __webpack_require__.O(void 0, ["9783", "9535", "8370", "6089", "9768"], () => __webpack_require__(39758));
  return __webpack_require__.O(e)
 }, __webpack_require__.n = e => {
  var t = e && e.__esModule ? () => e.default : () => e;
  return __webpack_require__.d(t, {
   a: t
  }), t
 }, __webpack_require__.d = (e, t, r) => {
  var o = (t, r) => {
   for (var o in t) __webpack_require__.o(t, o) && !__webpack_require__.o(e, o) && Object.defineProperty(e, o, {
    enumerable: !0,
    [r]: t[o]
   })
  };
  o(t, "get"), o(r, "value")
 }, __webpack_require__.f = {}, __webpack_require__.e = e => Promise.all(Object.keys(__webpack_require__.f).reduce((t, r) => (__webpack_require__.f[r](e, t), t), [])), __webpack_require__.u = e => "" + e + ".javascript", __webpack_require__.g = (() => {
  if ("object" == typeof globalThis) return globalThis;
  try {
   return this || Function("return this")()
  } catch (e) {
   if ("object" == typeof window) return window
  }
 })(), __webpack_require__.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), (() => {
  var e = {},
   t = "web:";
  __webpack_require__.l = function(r, o, n, a) {
   if (e[r]) return void e[r].push(o);
   if (void 0 !== n)
    for (var i, s, l = document.getElementsByTagName("script"), u = 0; u < l.length; u++) {
     var c = l[u];
     if (c.getAttribute("src") == r || c.getAttribute("data-rspack") == t + n) {
      i = c;
      break
     }
    }
   i || (s = !0, (i = document.createElement("script")).timeout = 120, __webpack_require__.nc && i.setAttribute("nonce", __webpack_require__.nc), i.setAttribute("data-rspack", t + n), i.src = r), e[r] = [o];
   var d = function(t, o) {
     i.onerror = i.onload = null, clearTimeout(f);
     var n = e[r];
     if (delete e[r], i.parentNode && i.parentNode.removeChild(i), n && n.forEach(function(e) {
       return e(o)
      }), t) return t(o)
    },
    f = setTimeout(d.bind(null, void 0, {
     type: "timeout",
     target: i
    }), 12e4);
   i.onerror = d.bind(null, i.onerror), i.onload = d.bind(null, i.onload), s && document.head.appendChild(i)
  }
 })(), __webpack_require__.r = e => {
  "u" > typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
   value: "Module"
  }), Object.defineProperty(e, "__esModule", {
   value: !0
  })
 }, __webpack_require__.federation || (__webpack_require__.federation = {
  chunkMatcher: function(e) {
   return !0
  },
  rootOutputDir: "../../"
 }), (() => {
  var e = [];
  __webpack_require__.O = (t, r, o, n) => {
   if (r) {
    n = n || 0;
    for (var a = e.length; a > 0 && e[a - 1][2] > n; a--) e[a] = e[a - 1];
    e[a] = [r, o, n];
    return
   }
   for (var i = 1 / 0, a = 0; a < e.length; a++) {
    for (var r = e[a][0], o = e[a][1], n = e[a][2], s = !0, l = 0; l < r.length; l++)(!1 & n || i >= n) && Object.keys(__webpack_require__.O).every(e => __webpack_require__.O[e](r[l])) ? r.splice(l--, 1) : (s = !1, n < i && (i = n));
    if (s) {
     e.splice(a--, 1);
     var u = o();
     void 0 !== u && (t = u)
    }
   }
   return t
  }
 })(), __webpack_require__.p = "/", __webpack_require__.S = {}, __webpack_require__.initializeSharingData = {
  scopeToSharingDataMapping: {
   default: [{
    name: "@bale/gol-logger",
    version: "0.5.15",
    factory: () => () => __webpack_require__(73964),
    eager: 1,
    treeShakingMode: null
   }, {
    name: "@emotion/react",
    version: "11.14.0",
    factory: () => () => __webpack_require__(43874),
    eager: 1,
    treeShakingMode: null,
    singleton: 1,
    requiredVersion: "^11.11.1"
   }, {
    name: "@emotion/styled",
    version: "11.14.0",
    factory: () => () => __webpack_require__(59514),
    eager: 1,
    treeShakingMode: null,
    singleton: 1,
    requiredVersion: "^11.11.1"
   }, {
    name: "react-dom",
    version: "19.2.8",
    factory: () => () => __webpack_require__(39623),
    eager: 1,
    treeShakingMode: null,
    singleton: 1,
    requiredVersion: "^19"
   }, {
    name: "react-router-dom",
    version: "6.11.1",
    factory: () => () => __webpack_require__(16673),
    eager: 1,
    treeShakingMode: null,
    singleton: 1,
    requiredVersion: "^6.11.1"
   }, {
    name: "react-router-dom",
    version: "6.11.1",
    factory: () => () => __webpack_require__(99434),
    eager: 1,
    treeShakingMode: null,
    singleton: 1,
    requiredVersion: "^6.11.1"
   }, {
    name: "react-router-dom",
    version: "6.11.1",
    factory: () => () => __webpack_require__(57743),
    eager: 1,
    treeShakingMode: null,
    singleton: 1,
    requiredVersion: "^6.11.1"
   }, {
    name: "react-router-dom",
    version: "6.11.1",
    factory: () => () => __webpack_require__(70185),
    eager: 1,
    treeShakingMode: null,
    singleton: 1,
    requiredVersion: "^6.11.1"
   }, {
    name: "react",
    version: "19.2.8",
    factory: () => () => __webpack_require__(50005),
    eager: 1,
    treeShakingMode: null,
    singleton: 1,
    requiredVersion: "^19"
   }]
  },
  uniqueName: "web"
 }, __webpack_require__.I = __webpack_require__.I || function() {
  throw Error("should have __webpack_require__.I")
 }, __webpack_require__.consumesLoadingData = {
  chunkMapping: {
   9768: ["27263", "35117"]
  },
  moduleIdToConsumeDataMapping: {
   27263: {
    shareScope: "default",
    shareKey: "@emotion/react",
    import: "@emotion/react",
    requiredVersion: "^11.11.1",
    strictVersion: !1,
    singleton: !0,
    eager: !0,
    fallback: () => () => __webpack_require__(43874),
    treeShakingMode: null
   },
   35117: {
    shareScope: "default",
    shareKey: "react",
    import: "react",
    requiredVersion: "^19",
    strictVersion: !1,
    singleton: !0,
    eager: !0,
    fallback: () => () => __webpack_require__(50005),
    treeShakingMode: null
   }
  },
  initialConsumes: ["27263", "35117"]
 }, __webpack_require__.f.consumes = __webpack_require__.f.consumes || function() {
  throw Error("should have __webpack_require__.f.consumes")
 }, (() => {
  var e = {
   2933: 0
  };
  __webpack_require__.f.j = function(t, r) {
   var o = __webpack_require__.o(e, t) ? e[t] : void 0;
   if (0 !== o)
    if (o) r.push(o[2]);
    else {
     var n = new Promise((r, n) => o = e[t] = [r, n]);
     r.push(o[2] = n);
     var a = __webpack_require__.p + __webpack_require__.u(t),
      i = Error(),
      s = function(r) {
       if (__webpack_require__.o(e, t) && (0 !== (o = e[t]) && (e[t] = void 0), o)) {
        var n = r && ("load" === r.type ? "missing" : r.type),
         a = r && r.target && r.target.src;
        i.message = "Loading chunk " + t + " failed.\n(" + n + ": " + a + ")", i.name = "ChunkLoadError", i.type = n, i.request = a, o[1](i)
       }
      };
     __webpack_require__.l(a, s, "chunk-" + t, t)
    }
  }, __webpack_require__.O.j = t => 0 === e[t];
  var t = (t, r) => {
    var o, n, a = r[0],
     i = r[1],
     s = r[2],
     l = 0;
    if (a.some(t => 0 !== e[t])) {
     for (o in i) __webpack_require__.o(i, o) && (__webpack_require__.m[o] = i[o]);
     if (s) var u = s(__webpack_require__)
    }
    for (t && t(r); l < a.length; l++) n = a[l], __webpack_require__.o(e, n) && e[n] && e[n][0](), e[n] = 0;
    return __webpack_require__.O(u)
   },
   r = self.rspackChunkweb = self.rspackChunkweb || [];
  r.forEach(t.bind(null, 0)), r.push = t.bind(null, r.push.bind(r))
 })(), (() => {
  var e = __webpack_require__.x,
   t = !1;
  __webpack_require__.x = function() {
   if (t || (t = !0, __webpack_require__(58114)), "function" == typeof e) return e();
   console.warn("[MF] Invalid prevStartup")
  }
 })();
 var __webpack_exports__ = __webpack_require__.x()
})();
//# sourceMappingURL=hub.3036ac76a0.js.map