"""Check the native GUI's login screen and dark mode, then screenshot both."""
import os
import subprocess
import sys

os.environ["DISPLAY"] = ":99"
sys.path.insert(0, "/home/user/bale-client")

from baleclient.client import BaleClient
from baleclient.tkgui import NativeApp

# no session -> the login screen must be what comes up
app = NativeApp(BaleClient(session_path="/tmp/definitely-missing.json"), demo=False)


def shot_login():
    subprocess.run(["import", "-window", "root", "/home/user/native-login.png"])
    print("login screen captured; step =", app.step)


def then_demo():
    app.login_frame.pack_forget()
    app.demo = True
    from baleclient.webui import DemoBackend
    app.demo_backend = DemoBackend(app.client)
    app._show_main()


def open_and_shot():
    app._open_chat("u:1545969305")
    app.root.after(500, app._toggle_theme)


def shot_dark():
    subprocess.run(["import", "-window", "root", "/home/user/native-dark.png"])
    app.root.quit()


app.root.after(1500, shot_login)
app.root.after(2400, then_demo)
app.root.after(3600, open_and_shot)
app.root.after(7000, shot_dark)
app.root.mainloop()
print("done")
