"""Exercise reactions + the member list in the native GUI and screenshot them."""
import os
import subprocess
import sys

os.environ["DISPLAY"] = ":99"
sys.path.insert(0, "/home/user/bale-client")

from baleclient.client import BaleClient
from baleclient.tkgui import NativeApp

app = NativeApp(BaleClient(session_path="/tmp/none.json"), demo=True)


def step1():
    app._open_chat("u:1545969305")


def step2():
    msgs = app.messages.get("u:1545969305", [])
    target = next((m for m in msgs if not (m.get("media") or {})), msgs[0])
    app._toggle_reaction(target, "\U0001f525")
    print("reacted to", target.get("text", "")[:20])


def step3():
    subprocess.run(["import", "-window", "root", "/home/user/native-react.png"])


def step4():
    app._open_chat("g:255637216")


def step5():
    app._show_members()


def step6():
    subprocess.run(["import", "-window", "root", "/home/user/native-members.png"])
    app.root.quit()


for delay, fn in ((1500, step1), (2800, step2), (3600, step3),
                  (4600, step4), (5600, step5), (6800, step6)):
    app.root.after(delay, fn)
app.root.mainloop()
print("done")
