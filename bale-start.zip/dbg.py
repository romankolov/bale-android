import os, sys
os.environ["DISPLAY"] = ":99"
sys.path.insert(0, "/home/user/bale-client")
from baleclient.client import BaleClient
from baleclient.tkgui import NativeApp
app = NativeApp(BaleClient(session_path="/tmp/none.json"), demo=True)

def go():
    app._open_chat("u:1545969305")
    app.root.after(400, toggle)

def toggle():
    app._toggle_theme()
    app.root.after(400, report)

def report():
    print("dark:", app.dark, "side:", app.c["side"])
    for w in app.main_frame.winfo_children():
        print(" child", w.winfo_class(), w.cget("bg") if "bg" in w.keys() else "-",
              "geom", w.winfo_geometry())
    app.root.quit()

app.root.after(1500, go)
app.root.mainloop()
