"""Drive the tk app programmatically by invoking its own callbacks."""
import os
import subprocess
import sys

os.environ["DISPLAY"] = ":99"
sys.path.insert(0, "/home/user/bale-client")

from baleclient.client import BaleClient
from baleclient.tkgui import NativeApp

app = NativeApp(BaleClient(session_path="/tmp/none.json"), demo=True)


def step1():
    app._open_chat("u:1545969305")


def step2():
    app.entry.insert("1.0", "این یک پیام آزمایشی از کلاینت پایتونی است")
    app._composer_send()


def step3():
    subprocess.run(["import", "-window", "root", "/home/user/native-chat.png"])
    app.root.quit()


app.root.after(1800, step1)
app.root.after(3200, step2)
app.root.after(5200, step3)
app.root.mainloop()
print("screenshotted")
